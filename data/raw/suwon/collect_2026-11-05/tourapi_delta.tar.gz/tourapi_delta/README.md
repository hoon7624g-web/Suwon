# suwon — TourAPI 변경분 원응답 (2026-11-05 수집)

저장소: `/home/user/hoon7624g-web/suwon` · 데이터: `data/suwon/` · 목록 기준일 2026-11-05 · 법정동 코드 lDongRegnCd=41 / lDongSignguCd=111,113,115,117

이 폴더는 한국관광공사 TourAPI 원응답만 담는다. 장소·행사·번역 데이터는 만들거나 고치지 않았다. 값은 사이트 저장소에서 아래 병합 도구로 오프라인 반영한다(새 장소는 draft, 공개·검수 값은 사람이 정한다).

## 차이 (사이트 places.json·events.json 기준)

| 구분 | 수 |
|---|---|
| 새 항목(places.json에 없음) | 5 (숙박 5) |
| tourapi_overrides skip·hold로 빼 둔 항목 | 0 |
| 바뀐 항목(목록 modifiedtime > places.json) | 39 (공개 39) |
| 사라진 항목(사이트에 있으나 지금 목록에 없음, 보고만) | 4 (detailCommon2 빈 응답으로 삭제 확인 4) |
| 새 행사(1월 1일 이후, events.json에 없음) | 0 |
| 바뀐 행사(modifiedtime > checked_at) | 0 |
| 무장애 정보 새로 생길 공개 장소 | 2 |
| 반려동물 정보 새로 생길 공개 장소 | 0 |
| 고캠핑 야영장(지역 1곳 중 사이트에 없는 곳) | 0 |
| 새 항목의 외국어 공식 이름(언어별) | en 0, ja 0, zh-hans 0, zh-hant 0, de 0, fr 0, es 0, ru 0 |
| 관광사진 갤러리 메타데이터 | 853장 (이미지 파일은 받지 않음) |
| 원응답 파일 | 310 |

자세한 목록은 `diff.json`(new·changed·gone은 contenttypeid별, events_new·events_changed, barrier_free·pet·gocamping·foreign_names_for_new_items·photo_gallery). 외국어 이름은 그 저장소 `tools/en_content.py`의 match_en 규칙(좌표 150m·유형·이름 근거)으로 찾은 보고용 후보다 — names.json에는 새 장소가 공개된 뒤 `en_content.py names`가 넣는다.

## 원응답 위치와 이름

`cache/tourapi/` 는 저장소의 `data/cache/tourapi/` 와 같은 구조·이름이다(`pipeline/tourapi.py` `_cache_path`: 오퍼레이션-sha1(base_url·op·인자)[:16].json, 파일 날짜 = 받은 날 → checked_at). 목록·행사 목록은 이 저장소 도구와 같은 호출 인자로 다시 받아 옛 묶음의 같은 이름 파일을 대신한다.

| 폴더/오퍼레이션 | 파일 |
|---|---|
| barrier_free/areaBasedList | 9 |
| barrier_free/detailCommon | 2 |
| barrier_free/detailWithTour | 6 |
| chsservice2/areaBasedList | 5 |
| chtservice2/areaBasedList | 5 |
| engservice2/areaBasedList | 5 |
| freservice2/areaBasedList | 5 |
| gerservice2/areaBasedList | 5 |
| jpnservice2/areaBasedList | 5 |
| korpettourservice2/areaBasedList | 14 |
| korservice2/areaBasedList | 28 |
| korservice2/detailCommon | 44 |
| korservice2/detailImage | 44 |
| korservice2/detailInfo | 44 |
| korservice2/detailIntro | 44 |
| korservice2/ldongCode | 2 |
| korservice2/searchFestival | 4 |
| photo_gallery/gallerySearchList | 29 |
| russervice2/areaBasedList | 5 |
| spnservice2/areaBasedList | 5 |

고캠핑 전국 목록(basedList 32쪽)은 한 벌만 `../_shared/cache/tourapi/gocamping/` 에 있다.

## 병합 순서 (저장소에서, 호출 0회)

```bash
cd /home/user/hoon7624g-web/suwon
# 1) 옛 원응답 묶음을 캐시로: tourapi_recollect 먼저, 그다음 tourapi는 없는 파일만(파일 날짜 유지)
python /home/user/work/tourapi_delta/scripts/apply_delta.py --repo /home/user/hoon7624g-web/suwon --city suwon --slug suwon --oldraw          # 미리보기: 1)+2)에서 몇 개가 복원·복사되는지
python /home/user/work/tourapi_delta/scripts/apply_delta.py --repo /home/user/hoon7624g-web/suwon --city suwon --slug suwon --oldraw --apply  # 쓰기
#   (--oldraw: 이 저장소는 data/raw가 희소 체크아웃에서 빠져 있다. `git sparse-checkout add /data/raw/` 로 꺼냈으면 --oldraw 없이 저장소 묶음을 쓴다 — 외국어 묶음까지 들어 있어 더 완전하다)
# 2) (위 스크립트가 함) 이 폴더의 원응답을 덮어쓰기 복사 — 같은 이름이면 새 응답이 이긴다
#    cp -a /home/user/work/tourapi_delta/out/suwon/cache/tourapi/. data/cache/tourapi/
#    cp -a /home/user/work/tourapi_delta/out/_shared/cache/tourapi/. data/cache/tourapi/
python tools/tourapi_bulk.py --data data/suwon --offline --events --details --add-new
python tools/tourapi_bulk.py --data data/suwon --offline --gallery
python tools/tourapi_bulk.py --data data/suwon --offline --barrier-free
python tools/tourapi_bulk.py --data data/suwon --offline --courses     # 여행코스 → tourapi_courses.json
python tools/harvest_merge.py --data data/suwon --pet --camping           # 미리보기(reports/harvest_merge.md)
python tools/harvest_merge.py --data data/suwon --pet --camping --apply
python tools/en_content.py names --data data/suwon --lang en --offline    # 외국어 공식 이름(언어마다)
```

- 옛 묶음 + 이 폴더로 places.json의 contentid 682곳 가운데 상세가 빠진 곳: detailCommon 0 · detailIntro 0 · detailInfo 0 · detailImage 0 (빠진 곳은 TourAPI에서 지워진 항목 — gone).
- `--barrier-free`: 공개 장소 681곳 가운데 무장애 목록에 있는 144곳 — 모두 캐시에 있다. 목록에 없는 공개 장소는 캐시가 없어 오류 목록에만 남는다(무장애 정보가 없는 곳).
- 도구 출력의 live_calls가 0이어야 한다. 0이 아니면 캐시가 모자란 것이니 `RESUME.md`의 남은 일을 먼저 한다.
- 행사 목록 캐시 키에는 그해 1월 1일(`20260101`)이 들어간다. 2027년에 병합하면 행사 목록을 다시 받아야 한다.
- `--details`는 places.json의 모든 장소 상세를 읽는다. 캐시가 없는 장소는 오류 목록에 남을 뿐 멈추지 않는다.
- 사라진 항목(gone)은 보고만 한다. 내리기·보관은 사람이 정한다.

## 추가 수집 (2026-11-05 오후) — 두루누비 · 관광사진 갤러리 · 다른 한국관광공사 서비스

### 두루누비(코리아둘레길) — 코스 0개가 이 지역(sigun에 '수원')을 지난다
- 공급자 전국 목록: 코스 174·길 4 (모두 걷기 DNWW; 서비스 설명의 284코스 중 지금 API가 내주는 수). 원응답은 `../_shared/cache/tourapi/durunubi/` (tools/tourapi_harvest.py --service durunubi 와 같은 이름).
- 이전 수집: 없음 — 모두 처음 받는 코스 · 새 0 · 바뀜 0 · 같음 0 · 공급자에서 사라짐 0
- 병합 도구는 아직 없다(사이트 데이터에는 강릉 courses.json 한 코스만 두루누비 출처). 값은 원응답 그대로 쓰고, crsContents·crsSummary 같은 설명 문장은 원문이라 옮기지 않는다(링크·우리 문장).

### 관광사진 갤러리(PhotoGalleryService1) — 지금 853장, 옛 묶음에 없던 25장
- 그중 옛 묶음 날짜(20261024) 뒤에 올라온 사진 22장, 그 전 사진인데 지금 저장소 키워드가 늘어 처음 잡힌 것 3장. 옛 묶음에만 있던 것 0장. 이미 places.json에 붙은 사진 76장.
- 키워드는 이 저장소 `tools/tourapi_harvest.py` harvest_photo 그대로(군산·해남은 대구 계열 규칙). 원응답 `cache/tourapi/photo_gallery/gallerySearchList-*.json`(메타데이터만, 이미지 파일 없음). 사진마다 저작권 필드는 없고 서비스 설명이 '공공누리 제1유형, 자유 다운로드·활용'이다. 목록은 `diff.json` photo_gallery_delta.new_photos.
- 병합: `python tools/harvest_merge.py --data data/suwon --photos` (미리보기) → `--apply` → `python tools/image_sizes.py --data data/suwon` → `--photos --apply` 한 번 더.

### 다른 한국관광공사 서비스(탐색 1~2회씩) — 이 키로는 쓸 수 없음
오디(Odii)·웰니스·의료관광·관광공모전 사진 수상작·관광 동영상·기초지자체 중심 관광지·지역별 관광 자원 수요/수요 강도/다양성 9개 서비스 모두 `HTTP 403 resultCode=30 등록되지 않은 서비스키` — data.go.kr 활용신청(개발계정 자동승인)이 먼저다. KorService2 detailPetTour2·searchStay2는 되지만 이미 쓰는 반려동물 서비스·숙박 목록과 같은 내용이라 받지 않았다. 자세한 것은 /home/user/work/tourapi_delta/RESUME.md.
