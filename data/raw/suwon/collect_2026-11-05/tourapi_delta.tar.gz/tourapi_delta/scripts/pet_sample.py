#!/usr/bin/env python3
"""KorService2 detailPetTour2가 반려동물 서비스(KorPetTourService2) 목록 밖 장소에도 값을 주는지 표본으로 본다."""
import json, os, sys, random
from pathlib import Path
WORK = Path("/home/user/work/tourapi_delta")
sys.path.insert(0, str(WORK / "scripts"))
import extra  # noqa: E402  (driver.setup·장부 패치)
T, retry = extra.T, extra.retry
api = T.TourAPI(os.environ["TOURAPI_KEY"], base_url=extra.B + "KorService2", op_suffix="2", mobile_app="TravelSite",
                cache_dir=extra.CACHE / "_probe_korservice2", max_calls=1000)
res = {}
for slug, city in (("gunsan", "gunsan"), ("busan", "busan")):
    pet = {str(i["contentid"]) for i in json.loads((WORK / "state" / slug / "pet.json").read_text())["list"]}
    pl = json.loads((WORK / "sandbox" / slug / "data" / city / "places.json").read_text())
    cand = sorted(str(p["tourapi"]["contentid"]) for p in pl if p.get("status") == "published" and (p.get("tourapi") or {}).get("contentid"))
    outside = [c for c in cand if c not in pet]
    inside = [c for c in cand if c in pet]
    random.Random(7).shuffle(outside); random.Random(7).shuffle(inside)
    r = {"outside_checked": 0, "outside_with_values": 0, "inside_checked": 0, "inside_with_values": 0}
    for group, ids in (("outside", outside[:20]), ("inside", inside[:5])):
        for c in ids:
            try:
                it = retry(api.call, "detailPetTour", contentId=c)
            except T.TourAPIError as err:
                r.setdefault("errors", []).append(T.redact(str(err), api.service_key)[:120]); continue
            r[f"{group}_checked"] += 1
            if it and any(str(v or "").strip() for k, v in it[0].items() if k != "contentid"):
                r[f"{group}_with_values"] += 1
    res[slug] = r
    print(slug, r, flush=True)
(WORK / "state" / "pet_sample.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
