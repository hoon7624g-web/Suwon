#!/usr/bin/env python3
"""목록(state/<slug>/lists.json)과 사이트 데이터(places·events·tourapi_courses, 저장소 사본)를 비교해 차이를 만들고,
옛 원응답 묶음 색인(state/<slug>/oldindex.json)으로 상세 호출 계획을 세운다(호출 없음).

state/<slug>/diff.json            : 새·바뀜·사라짐(유형별), 새·바뀐 행사
state/<slug>/new_items.json       : 새 장소 항목(외국어 이름 찾기용)
state/<slug>/plan_<level>.json    : [[contentid, contenttypeid, [ops]], ...]
    events      — 행사 목록의 새·묵은 상세(detailIntro 15·detailCommon): tools/tourapi_bulk.py --events 가 읽는 것
    new         — 새 장소·새 코스: detailCommon·detailIntro·detailInfo·detailImage(옛 캐시에 없거나 수정일보다 묵은 것)
    changed_pub — 바뀐 공개 장소
    rest        — 바뀐 비공개 장소, 옛 캐시에 상세가 없는 기존 장소(공개 먼저), 행사 detailInfo·detailImage
"""
from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
SB = WORK / "sandbox"
KOR = "https://apis.data.go.kr/B551011/KorService2"
TYPES = {"12": "관광지", "14": "문화시설", "15": "행사", "25": "여행코스", "28": "레포츠", "32": "숙박", "38": "쇼핑",
         "39": "음식점"}


def cache_name(op: str, params: dict, base=KOR) -> str:
    """pipeline.tourapi.TourAPI._cache_path 와 같은 이름(20개 저장소 모두 같은 식)."""
    k = json.dumps([base, op, sorted(params.items())], ensure_ascii=False)
    return f"{op}-{hashlib.sha1(k.encode('utf-8')).hexdigest()[:16]}.json"


def op_params(op: str, cid: str, ctype: str) -> dict:
    return {"common": ("detailCommon", {"contentId": cid}),
            "intro": ("detailIntro", {"contentId": cid, "contentTypeId": ctype}),
            "info": ("detailInfo", {"contentId": cid, "contentTypeId": ctype}),
            "image": ("detailImage", {"contentId": cid, "imageYN": "Y", "numOfRows": 20, "pageNo": 1})}[op]


def load(slug: str):
    data = next(d for d in (SB / slug / "data").iterdir() if d.is_dir() and d.name != "cache")
    pl = json.loads((data / "places.json").read_text("utf-8"))
    pl = pl if isinstance(pl, list) else pl.get("places", [])
    ev = json.loads((data / "events.json").read_text("utf-8")) if (data / "events.json").exists() else []
    ev = ev if isinstance(ev, list) else ev.get("events", [])
    tc = json.loads((data / "tourapi_courses.json").read_text("utf-8")) if (data / "tourapi_courses.json").exists() else {}
    tc = tc.get("courses", []) if isinstance(tc, dict) else tc
    ov = json.loads((data / "tourapi_overrides.json").read_text("utf-8")) if (data / "tourapi_overrides.json").exists() else {}
    return pl, ev, tc, ov


def missing_ops(old_files: dict, cid: str, ctype: str, mtime: str, ops) -> list[str]:
    """ops whose cache file is not in the old bundle, or older than the item's modifiedtime."""
    out = []
    for op in ops:
        if op in ("intro", "info") and not ctype:
            continue
        name = cache_name(*op_params(op, cid, ctype))
        f = old_files.get(name)
        if not f or (mtime and f.get("ts", "") < mtime):
            out.append(op)
    return out


def main() -> None:
    summary = {}
    for st in sorted(STATE.iterdir()):
        slug = st.name
        if not (st / "lists.json").exists():
            continue
        L = json.loads((st / "lists.json").read_text("utf-8"))
        old = json.loads((st / "oldindex.json").read_text("utf-8")) if (st / "oldindex.json").exists() else {"files": {}, "list_mtime": {}}
        old_files = old["files"]
        old_list = old["list_mtime"]
        places, events, tcourses, ov = load(slug)
        skip = {str(x) for x in ov.get("skip") or []}
        hold = {str(x) for x in (ov.get("hold") or {})}
        P = defaultdict(list)
        for p in places:
            cid = str((p.get("tourapi") or {}).get("contentid") or "")
            if cid:
                P[cid].append(p)
        cur = {}
        for it in L["items"]:
            cur[str(it["contentid"])] = it
        courses = {str(it["contentid"]): it for it in L["courses"]}
        fest = {str(it["contentid"]): it for it in L["festivals"]}
        E = {}
        for e in events:
            for k in ("contentid", "tourapi_contentid"):
                if e.get(k):
                    E[str(e[k])] = e
        TC = {str(c.get("contentid")): c for c in tcourses if c.get("contentid")}

        def pub(cid):
            return any(p.get("status") == "published" and not p.get("duplicate_of") for p in P.get(cid, []))

        new, changed, gone = defaultdict(list), defaultdict(list), defaultdict(list)
        new_overridden = []
        for cid, it in cur.items():
            t = str(it.get("contenttypeid"))
            if cid not in P:
                row = {"contentid": cid, "title": it.get("title"), "addr1": it.get("addr1", ""),
                       "modifiedtime": it.get("modifiedtime"), "createdtime": it.get("createdtime"),
                       "district": it.get("ldong_signgu_name", ""), "in_last_harvest_list": cid in old_list,
                       "photo_type": it.get("cpyrhtDivCd", "")}
                if cid in skip or cid in hold:
                    row["override"] = "skip" if cid in skip else "hold"
                    new_overridden.append(row)
                else:
                    new[t].append(row)
            else:
                pm = max(str((p.get("tourapi") or {}).get("modifiedtime") or "") for p in P[cid])
                if str(it.get("modifiedtime") or "") > pm:
                    changed[t].append({"contentid": cid, "title": it.get("title"), "site_names": [p.get("name") for p in P[cid]],
                                       "site_status": sorted({p.get("status") for p in P[cid]}),
                                       "site_modifiedtime": pm, "modifiedtime": it.get("modifiedtime"),
                                       "list_contenttypeid": t,
                                       "site_contenttypeid": str((P[cid][0].get("tourapi") or {}).get("contenttypeid") or "")})
        for cid, it in courses.items():
            if cid not in TC:
                new["25"].append({"contentid": cid, "title": it.get("title"), "modifiedtime": it.get("modifiedtime"),
                                  "in_last_harvest_list": cid in old_list, "district": it.get("ldong_signgu_name", "")})
            elif str(it.get("modifiedtime") or "") > str(TC[cid].get("modifiedtime") or ""):
                changed["25"].append({"contentid": cid, "title": it.get("title"), "site_modifiedtime": TC[cid].get("modifiedtime"),
                                      "modifiedtime": it.get("modifiedtime")})
        listed_all = set(cur) | set(courses) | set(fest)
        for cid, ps in P.items():
            if cid not in listed_all and L["complete"].get("list") is True:
                p = ps[0]
                t = str((p.get("tourapi") or {}).get("contenttypeid") or "?")
                gone[t].append({"contentid": cid, "names": [x.get("name") for x in ps],
                                "status": sorted({x.get("status") for x in ps}),
                                "duplicate_of": [x.get("duplicate_of") for x in ps if x.get("duplicate_of")],
                                "in_last_harvest_list": cid in old_list})
        ev_new, ev_changed = [], []
        for cid, it in fest.items():
            row = {"contentid": cid, "title": it.get("title"), "eventstartdate": it.get("eventstartdate"),
                   "eventenddate": it.get("eventenddate"), "modifiedtime": it.get("modifiedtime"),
                   "district": it.get("ldong_signgu_name", "")}
            if cid not in E:
                ev_new.append(row)
            else:
                ck = str(E[cid].get("checked_at") or "").replace("-", "")
                if ck and str(it.get("modifiedtime") or "")[:8] > ck:
                    row["site_checked_at"] = E[cid].get("checked_at")
                    ev_changed.append(row)
        diff = {"slug": slug, "list_date": L["date"], "regn": L["regn"], "signgu": L["signgu"],
                "scope": L["scope"], "list_complete": L["complete"],
                "current": {"places_list": len(cur), "by_type": dict(Counter(str(i.get("contenttypeid")) for i in cur.values())),
                            "courses": len(courses), "festivals_from_0101": len(fest)},
                "site": {"places": len(places), "with_contentid": len(P),
                         "published": sum(1 for p in places if p.get("status") == "published"),
                         "events": len(events), "tourapi_courses": len(TC)},
                "new": {t: v for t, v in sorted(new.items())},
                "changed": {t: v for t, v in sorted(changed.items())},
                "gone": {t: v for t, v in sorted(gone.items())},
                "new_overridden": new_overridden,
                "events_new": sorted(ev_new, key=lambda r: r.get("eventstartdate") or ""),
                "events_changed": ev_changed,
                "type_names": TYPES}
        (st / "diff.json").write_text(json.dumps(diff, ensure_ascii=False, indent=1), "utf-8")
        new_items = [cur[r["contentid"]] for t, rows in new.items() if t != "25" for r in rows]
        (st / "new_items.json").write_text(json.dumps(new_items, ensure_ascii=False), "utf-8")

        # ---- plans
        ALL = ("common", "intro", "info", "image")
        plans = {"events": [], "new": [], "changed_pub": [], "rest": [], "rest_pub": [], "rest_draft": [], "rest_misc": []}
        seen = set()

        def add(level, cid, ctype, mtime, ops):
            m = missing_ops(old_files, cid, ctype, mtime, ops)
            m = [o for o in m if (cid, ctype, o) not in seen]
            if m:
                seen.update((cid, ctype, o) for o in m)
                plans[level].append([cid, ctype, m])

        for r in sorted(fest.values(), key=lambda i: (str(i["contentid"]) in E, -(int(str(i.get("eventstartdate") or 0)) if str(i.get("eventstartdate") or "").isdigit() else 0))):
            add("events", str(r["contentid"]), "15", str(r.get("modifiedtime") or ""), ("intro", "common"))
        for t in ("12", "14", "28", "32", "39", "38", "25"):
            for r in new.get(t, []):
                add("new", r["contentid"], t, str(r.get("modifiedtime") or ""), ALL)
        for t, rows in changed.items():
            if t == "25":
                continue
            for r in rows:
                if "published" in r["site_status"]:
                    for ct in dict.fromkeys([r["site_contenttypeid"] or t, t]):
                        add("changed_pub", r["contentid"], ct, str(r.get("modifiedtime") or ""), ALL)
        for r in changed.get("25", []):
            add("changed_pub", r["contentid"], "25", str(r.get("modifiedtime") or ""), ("common", "intro", "info"))
        for t, rows in changed.items():
            if t == "25":
                continue
            for r in rows:
                for ct in dict.fromkeys([r["site_contenttypeid"] or t, t]):
                    add("rest_draft", r["contentid"], ct, str(r.get("modifiedtime") or ""), ALL)
        # existing places whose details the old bundle lacks, current list items only: published -> rest_pub,
        # the others -> rest_draft
        exist = sorted(((cid, ps) for cid, ps in P.items() if cid in cur), key=lambda x: x[0])
        for cid, ps in exist:
            ct = str((ps[0].get("tourapi") or {}).get("contenttypeid") or cur[cid].get("contenttypeid") or "")
            add("rest_pub" if pub(cid) else "rest_draft", cid, ct, str(cur[cid].get("modifiedtime") or ""), ALL)
        for r in new_overridden:
            it = cur[r["contentid"]]
            add("rest_misc", r["contentid"], str(it.get("contenttypeid")), str(it.get("modifiedtime") or ""), ALL)
        for cid, it in fest.items():
            add("rest_misc", cid, "15", str(it.get("modifiedtime") or ""), ("info", "image"))
        for lv, pl in plans.items():
            (st / f"plan_{lv}.json").write_text(json.dumps(pl, ensure_ascii=False), "utf-8")
        summary[slug] = {"cur": len(cur), "new": {t: len(v) for t, v in new.items()}, "chg": sum(len(v) for v in changed.values()),
                         "chg_pub": sum(1 for v in changed.values() for r in v if "published" in r.get("site_status", [])),
                         "gone": sum(len(v) for v in gone.values()), "ev_new": len(ev_new), "ev_chg": len(ev_changed),
                         "ovr": len(new_overridden),
                         "plan": {lv: sum(len(x[2]) for x in pl) for lv, pl in plans.items()}}
    for s, v in summary.items():
        print(s, json.dumps(v, ensure_ascii=False))
    tot = Counter()
    for v in summary.values():
        for lv, n in v["plan"].items():
            tot[lv] += n
    print("plan calls (all ops):", dict(tot))


if __name__ == "__main__":
    main()
