#!/usr/bin/env python3
"""RESUME.md 를 장부(state/ledger.json)·닫힌 오퍼레이션(state/closed.json)·남은 계획(state/remaining.json)으로 다시 쓴다."""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"


def jl(p, d):
    return json.loads(p.read_text("utf-8")) if p.exists() else d


def main() -> None:
    ledger = jl(STATE / "ledger.json", {})
    closed = jl(STATE / "closed.json", {})
    rem = jl(STATE / "remaining.json", {})
    files = Counter()
    for f in (WORK / "cache" / "tourapi").rglob("*.json"):
        rel = f.relative_to(WORK / "cache" / "tourapi")
        folder = rel.parts[0] if len(rel.parts) > 1 else "(뿌리)"
        files[(folder, f.name.split("-")[0])] += 1
    L = ["# RESUME — TourAPI 변경분 수집 (20개 사이트)\n",
         "작업 폴더: `/home/user/work/tourapi_delta` · 시작 2026-11-05 · 저장소는 읽기만 했다(수정·커밋·푸시 없음).\n",
         "## 지금 상태\n",
         "- (a) 20곳 목록·차이, (b) 행사, (c) 새 항목 상세, (d) 바뀐 공개 장소 상세: **끝**.",
         "- 무장애·반려동물 목록과 '공개 장소인데 사이트에 그 정보가 없는 곳'의 상세, 고캠핑 전국 목록, 8개 언어 목록, "
         "군산·해남 관광사진 갤러리: **끝**.",
         "- (e) 나머지: 옛 원응답 묶음에 상세가 없는 기존 장소(rest_pub 공개 / rest_draft 비공개·바뀐 비공개), "
         "행사 detailInfo·detailImage(rest_misc), 사라진 항목 확인(gone_check/, 사이트 캐시와 분리), "
         "새 항목과 짝지은 외국어 서비스 상세 — " + ("**끝**." if not rem else "아래 '남은 일'.") + "\n",
         "- 호출 한도: 운영자는 '한도 무한'이라 했고 KorService2(목록·상세)·외국어·반려동물·관광사진·고캠핑은 한도 응답이 없었다. "
         "다만 **KorWithService2.detailWithTour2는 약 1,000회에서 공급자 한도 응답**(아래)을 냈다. 받은 공급자 메시지(키 가림)는 "
         "state/closed.json에 남는다.\n",
         "## 호출 수(장부, 2026-11-05) — 네트워크 끊김 재시도도 1회로 셈(실제 공급자 집계보다 조금 많다)\n",
         "| 서비스.오퍼레이션 | 호출 |", "|---|---|"]
    for day, d in sorted(ledger.items()):
        if day.startswith("_"):
            continue
        for k, v in sorted(d.items()):
            L.append(f"| {k} ({day}) | {v} |")
    L.append("")
    cl = {d: v for d, v in closed.items() if not d.startswith("_") and v}
    L.append("## 공급자 한도로 닫힌 오퍼레이션\n")
    if cl:
        for d, v in cl.items():
            for k, m in v.items():
                L.append(f"- {d} {k}: {m}")
    else:
        L.append("- 없음(공급자 한도 응답을 받지 않았다)")
    L.append("")
    L.append("## 남은 일 (캐시에 아직 없는 상세 호출, 사이트·단계·오퍼레이션별)\n")
    if rem:
        L.append("| 사이트 | 단계 | detailCommon | detailIntro | detailInfo | detailImage |")
        L.append("|---|---|---|---|---|---|")
        tot = Counter()
        for s, r in rem.items():
            for lv, c in r.items():
                L.append(f"| {s} | {lv} | {c.get('detailCommon', 0)} | {c.get('detailIntro', 0)} | "
                         f"{c.get('detailInfo', 0)} | {c.get('detailImage', 0)} |")
                for k, v in c.items():
                    tot[k] += v
        L.append(f"| **합계** | | {tot['detailCommon']} | {tot['detailIntro']} | {tot['detailInfo']} | {tot['detailImage']} |")
        L.append("\n공개 장소(rest_pub) 먼저.")
    else:
        L.append("- 없음")
    bfc = jl(STATE / "bf_coverage.json", {})
    left = {s: v["in_list_missing"] for s, v in bfc.items() if v.get("in_list_missing")}
    L.append("\n### 무장애 상세 채우기(bffill)\n")
    if not left:
        L.append("- 11-05 21:42 KST KorWithService2.detailWithTour 한도(resultCode=22)로 멈췄다가 11-06 00:11 KST 재개. "
                 "jeju 189·gangneung 46·sejong 44·gunsan 60개 contentid(군산 61곳 중 두 곳이 한 contentid) = 339개, "
                 "detailWithTour2·detailCommon2 각 348회(네트워크 재시도 포함), 한도 응답 없음. 20곳 모두 무장애 목록 안 공개 장소의 캐시 빠짐 0.")
    if left:
        L.append("무장애 목록에 있는 공개 장소인데 캐시에 detailWithTour2가 없는 곳(사이트에는 이미 무장애 사실이 있다 — "
                 "`--barrier-free` 오프라인 실행이 빠짐없이 돌게 하려는 것): "
                 + ", ".join(f"{s} {n}" for s, n in left.items()) + f" — 합계 {sum(left.values())}곳(+값이 있으면 같은 서비스 detailCommon2).")
        L.append("```bash\ncd /home/user/work/tourapi_delta\nK=/tmp/claude-0/-home-user/ff6555e3-ee41-5b25-8f10-42343f844468/scratchpad/.datakey   # 내용 출력 금지\nTOURAPI_KEY=\"$(cat $K)\" scripts/bffill_pool.sh   # 00:10 KST 뒤(코디네이터가 알려 줌). 오늘은 KorWithService2를 다시 부르지 않는다. 이미 받은 것은 건너뜀\n```")
    else:
        L.append("- 끝.")
    L.append("""
선택(하지 않음 — 병합 도구가 쓰지 않는다):
- areaBasedSyncList2(showflag) — 하네스 수집기의 보고용 목록. 병합 도구는 쓰지 않는다.
- 외국어 서비스 상세(detailCommon2 …)와 searchFestival2 — 번역 준비용. 이름 찾기(names)에는 목록만 쓴다.

## 추가 수집 (2026-11-05 오후)

- 두루누비: courseList 2쪽·routeList 1쪽(전국 코스 174·길 4, 모두 걷기) → `out/_shared/cache/tourapi/durunubi/`.
  사이트별로 sigun에 지역 이름이 든 코스를 `out/<slug>/diff.json` durunubi·README 표로 냈다. 옛 묶음이 있는 곳(대구·부산·여수·전주·춘천)은
  새·바뀜·같음으로 비교했다. `python3 scripts/orchestrate.py run durunubi --sites busan` (한 번이면 20곳 공통).
- 관광사진 갤러리(18곳 새로 받기, 군산·해남은 앞서 받음): 각 저장소 harvest_photo 키워드 그대로(`run photo2`).
  옛 묶음과 비교한 새 사진은 `state/<slug>/photo_diff.json` → `out/<slug>/diff.json` photo_gallery_delta. 메타데이터만.
- 다른 한국관광공사 서비스(data.go.kr 목록에서 한국관광공사 OpenAPI 28개를 찾음; 이미 쓰는 것·다른 작업자 몫 제외). 서비스마다 1~2회 탐색:

| 서비스(목록 번호) | 결과 | 주는 것 | 이용 조건(서비스 설명) | 받을지 |
|---|---|---|---|---|
| Odii 관광지 오디오 가이드(15101971) | 403 resultCode=30 등록되지 않은 서비스키 | 관광지·이야기(음성·대본·사진), 위치 기반 | 이용허락 제한 없음, 무료 제공 | 장소 단위 — 활용신청 뒤 |
| WellnessTursmService 웰니스(15144030) | 403 =30 | contentId·주소·상세(공통·소개·반복·이미지) | 제한 없음, '저작권에 구애 없이 활용 가능한 정보만', 사진 Type1·3 | 장소 단위 — 활용신청 뒤 |
| MdclTursmService 의료관광(15143913) | 403 =30 | contentId·주소·의료관광 상세 | 제한 없음, 같은 문구 | 장소 단위 — 활용신청 뒤 |
| PhokoAwrdService 관광공모전 사진 수상작(15145706) | 403 =30 | 제목·촬영일·촬영지·키워드·이미지, lDongRegnCd | 제한 없음, 홍보물·잡지 등 활용 가능 | 사진 단위 — 활용신청 뒤 |
| VideoService 관광 동영상(15162188) | 403 =30 | 콘텐츠명·촬영장소·썸네일·URL, 법정동 코드 | 제한 없음 | 영상 단위 — 활용신청 뒤 |
| LocgoHubTarService1 기초지자체 중심 관광지(15128559) | 403 =30 | 시군구별 중심 관광지 순위(Tmap 내비 집계) | 제한 없음 | 지역 통계 — 탐색만 |
| AreaTarResDemService 관광 자원 수요(15152138) | 403 =30 | 시군구 지표(데이터랩 관광수요지수) | 제한 없음 | 지역 통계 — 탐색만 |
| AreaTarDemDsService 관광 수요 강도(15151868) | 403 =30 | 시군구 지표 | 제한 없음 | 지역 통계 — 탐색만 |
| AreaTarDivService 관광 다양성(15151365) | 403 =30 | 시군구 지표 | 제한 없음 | 지역 통계 — 탐색만 |
| KorService2 detailPetTour2 | 정상 | 반려동물 동반 정보(contentId) | 국문 관광정보와 같음 | 받지 않음 — 표본 50곳에서 KorPetTourService2 목록 밖 장소는 값 0 |
| KorService2 searchStay2 | 정상(부산 118) | 숙박 목록 | 같음 | 받지 않음 — areaBasedList 숙박(32)과 같은 내용 |

  모든 서비스의 트래픽은 개발계정 1,000건(목록 페이지 표기). 9개 서비스는 운영자가 data.go.kr에서 활용신청(개발 자동승인)한 뒤
  `TOURAPI_KEY="$(cat $K)" python3 scripts/extra.py probe` 로 다시 탐색하고, 장소·영상·사진 단위 서비스만 사이트별로 모은다.

## 이어서 하는 명령

키는 같은 명령 안에서만 환경 변수로 넣는다(출력·저장 금지).

```bash
cd /home/user/work/tourapi_delta
K=/tmp/claude-0/-home-user/ff6555e3-ee41-5b25-8f10-42343f844468/scratchpad/.datakey   # 키 파일(내용을 출력하지 말 것)
# 0) 새 컨테이너라면: 같은 폴더가 남아 있으면 그대로, 없으면 scripts/만 있으면 된다(캐시는 cache/tourapi/)
python3 scripts/orchestrate.py setup                 # 저장소 사본 다시(places 등이 바뀌었으면) — 호출 없음
python3 scripts/diffplan.py                          # 차이·계획 다시 — 호출 없음(목록을 다시 받으려면 아래 1))
# 1) (다음 날 새로 비교하려면) 목록부터: cache/tourapi의 목록 파일을 지워야 새로 받는다
#    find cache/tourapi -maxdepth 1 \\( -name 'areaBasedList-*' -o -name 'searchFestival-*' \\) -delete
#    TOURAPI_KEY="$(cat $K)" python3 scripts/orchestrate.py run lists --jobs 4 && python3 scripts/diffplan.py
# 2) 남은 상세(캐시에 있는 것은 다시 부르지 않는다). 공급자 한도 응답이 오면 그 오퍼레이션만 닫히고 장부에 남는다
for lv in changed_pub rest_pub rest_misc rest_draft; do
  DELTA_CAP=100000 TOURAPI_KEY="$(cat $K)" python3 scripts/orchestrate.py run kdetail --level $lv --jobs 4
done
# 3) 남은 수, 사이트별 내보내기, 이 파일
python3 scripts/remaining.py && python3 scripts/export.py && python3 scripts/resume_md.py
```

- `state/closed.json`의 그날 항목이 남아 있으면 그 오퍼레이션은 건너뛴다(날짜가 바뀌면 자동으로 열림).
- 장부 상한은 `DELTA_CAP`(기본 1000, 장부가 재시도까지 세므로 공급자 응답을 보려면 크게 둔다).
- 행사 목록 캐시 키에는 올해 1월 1일(`20260101`)이 들어간다. 2027년에는 행사 목록을 새로 받는다.

## 검증(2026-11-05, 작업 폴더 안 사본에서 — 저장소는 건드리지 않음)

- 부산(대구 계열): apply_delta --oldraw --apply 뒤 `tourapi_bulk.py --offline --events --details --add-new` → live_calls 0,
  새 장소 4·새 행사 4 추가, 상세 2,154곳 오류 0. `--courses`·`harvest_merge --pet --camping`·`en_content names --lang ja --offline`
  모두 live_calls 0.
- 군산(군산 계열): 같은 순서 → live_calls 0, `--gallery` 끝까지 돎. `--barrier-free`는 무장애 캐시가 없는 공개 장소를 오류 목록에
  남긴다(위 bffill 61곳 + 무장애 목록 밖 장소 — 원래 무장애 정보가 없는 곳).

## 사이트에 반영하는 법

`out/<slug>/README.md` — 저장소마다 명령이 다르다. 공통 순서:
`python3 /home/user/work/tourapi_delta/scripts/apply_delta.py --repo <저장소> --city <도시> --slug <slug> [--oldraw] --apply`
(옛 묶음 → 캐시, 그 위에 out/<slug>/cache/tourapi와 out/_shared 덮어쓰기) 다음 `tools/tourapi_bulk.py --offline …`.
희소 체크아웃 저장소(17곳)는 data/raw가 꺼내져 있지 않다 — `git sparse-checkout add /data/raw/` 또는 `--oldraw`
(작업 폴더 oldraw/<slug>: KorService2·무장애·반려동물·고캠핑·관광사진 묶음만).

## 캐시 파일 수(전역 cache/tourapi, 폴더·오퍼레이션별)
""")
    L.append("| 폴더 | 오퍼레이션 | 파일 |\n|---|---|---|")
    for (a, b), n in sorted(files.items()):
        L.append(f"| {a} | {b} | {n} |")
    (WORK / "RESUME.md").write_text("\n".join(L) + "\n", "utf-8")
    print("RESUME.md", len(L), "lines")


if __name__ == "__main__":
    main()
