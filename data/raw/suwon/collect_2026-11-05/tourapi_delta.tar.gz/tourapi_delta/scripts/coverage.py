#!/usr/bin/env python3
"""옛 묶음(oldraw 색인) + 이번 캐시로 사이트 places.json의 상세·무장애 상세가 얼마나 갖춰졌는지(호출 없음).
state/coverage.json, state/bf_coverage.json"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from diffplan import cache_name, load, op_params  # noqa: E402

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
C = WORK / "cache" / "tourapi"
BF = "https://apis.data.go.kr/B551011/KorWithService2"


def main() -> None:
    cov, bfc = {}, {}
    for st in sorted(STATE.iterdir()):
        if not (st / "oldindex.json").exists() or not (st / "diff.json").exists():
            continue
        old = set(json.loads((st / "oldindex.json").read_text("utf-8"))["files"])
        places, *_ = load(st.name)
        miss = {"common": 0, "intro": 0, "info": 0, "image": 0}
        n, ex = 0, []
        for p in places:
            t = p.get("tourapi") or {}
            cid = str(t.get("contentid") or "")
            if not cid:
                continue
            n += 1
            ct = str(t.get("contenttypeid") or "")
            m = [op for op in miss if cache_name(*op_params(op, cid, ct)) not in old
                 and not (C / cache_name(*op_params(op, cid, ct))).exists()]
            for op in m:
                miss[op] += 1
            if m:
                ex.append([cid, p.get("name"), p.get("status"), m])
        cov[st.name] = {"places_with_cid": n, "missing": miss, "missing_places": ex}
        bf = json.loads((st / "bf.json").read_text("utf-8")) if (st / "bf.json").exists() else {"list": []}
        ids = {str(i["contentid"]) for i in bf["list"]}
        pubs = [str(p["tourapi"]["contentid"]) for p in places if p.get("status") == "published"
                and not p.get("duplicate_of") and (p.get("tourapi") or {}).get("contentid")]

        def has(c):
            nm = cache_name("detailWithTour", {"contentId": c}, BF)
            return f"barrier_free/{nm}" in old or (C / "barrier_free" / nm).exists()
        inl = [c for c in pubs if c in ids]
        bfc[st.name] = {"published_with_cid": len(pubs), "published_in_bf_list": len(inl),
                        "in_list_missing": sum(1 for c in inl if not has(c)),
                        "outside_list_without_cache": sum(1 for c in pubs if c not in ids and not has(c))}
        print(st.name, n, miss, bfc[st.name])
    (STATE / "coverage.json").write_text(json.dumps(cov, ensure_ascii=False, indent=1), "utf-8")
    (STATE / "bf_coverage.json").write_text(json.dumps(bfc, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    main()
