#!/usr/bin/env python3
"""남은 상세 계획을 조각(기본 100건)으로 나눠 동시에 몇 개(기본 4)만 돌린다. 캐시에 있는 호출은 계획에서 뺀다.

    TOURAPI_KEY=... DELTA_CAP=100000 python3 pool.py --levels changed_pub,rest_pub,rest_misc,rest_draft --workers 4
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from diffplan import cache_name, op_params  # noqa: E402
from orchestrate import SITES  # noqa: E402

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
CACHE = WORK / "cache" / "tourapi"


def todo(slug: str, level: str) -> list:
    p = STATE / slug / f"plan_{level}.json"
    if not p.exists():
        return []
    out = []
    for cid, ctype, ops in json.loads(p.read_text("utf-8")):
        left = [op for op in ops if not (CACHE / cache_name(*op_params(op, str(cid), str(ctype)))).exists()]
        if left:
            out.append([cid, ctype, left])
    return out


def run(task) -> str:
    slug, level, n, path = task
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    p = subprocess.run([sys.executable, str(WORK / "scripts" / "driver.py"), "--slug", slug, "--repo", SITES[slug][0],
                        "--phase", "kdetail", "--plan", str(path), "--tag", f"{level}_{n:03d}"], env=env, capture_output=True,
                       text=True, timeout=7200)
    line = (p.stdout.strip().splitlines() or [""])[-1] or json.dumps({"slug": slug, "rc": p.returncode, "stderr": p.stderr[-500:]})
    with open(STATE / "runs.log", "a", encoding="utf-8") as fh:
        fh.write(line + "\n")
    return line


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--levels", default="changed_pub,rest_pub,rest_misc,rest_draft")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--chunk", type=int, default=100)
    a = ap.parse_args()
    tasks = []
    for level in a.levels.split(","):
        for slug in SITES:
            items = todo(slug, level)
            for i in range(0, len(items), a.chunk):
                path = STATE / slug / "chunks" / f"{level}_{i // a.chunk:03d}.json"
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(items[i:i + a.chunk], ensure_ascii=False), "utf-8")
                tasks.append((slug, level, i // a.chunk, path))
    print(f"{len(tasks)} chunks", flush=True)
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        for line in ex.map(run, tasks):
            print(line[:300], flush=True)


if __name__ == "__main__":
    main()
