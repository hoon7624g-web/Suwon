#!/bin/bash
# 저장소에 커밋된 옛 TourAPI 원응답 묶음(data/raw/<city>/tourapi*/)을 내 작업 폴더로만 받아 온다(저장소는 건드리지 않음).
set -u
W=/home/user/work/tourapi_delta
declare -A R=( [sejong]=sejong:sejong [yeongju]=yeougju:yeongju [gangneung]=gangneung:gangneung [jeju]=jeju:jeju [yeosu]=yeosu:yeosu
 [jeonju]=jeonju:jeonju [chuncheon]=chuncheon:chuncheon [yongin]=yongin:yongin [gyeongju]=gyeongju:gyeongju [busan]=busan:busan
 [suwon]=suwon:suwon [sokcho]=sokcho:sokcho [danyang]=danyang:danyang [mokpo]=mokpo:mokpo [incheon]=incheon:incheon
 [gapyeong]=gapyeong:gapyeong [jongno]=jongno:jongno )
for slug in "${!R[@]}"; do
  repo=${R[$slug]%%:*}; city=${R[$slug]##*:}
  m=$W/mirror/$slug
  [ -d $m/.git ] || git clone --filter=blob:none --no-checkout --depth 1 -q https://github.com/hoon7624g-web/$repo $m || { echo "FAIL clone $slug"; continue; }
  git -C $m ls-tree -r HEAD --format='%(objectname) %(path)' -- data/raw/$city | grep -E "tourapi(_recollect)?/(korservice2|barrier_free|korpettourservice2|gocamping|photo_gallery)\.tar\.gz|tourapi(_recollect)?/manifest\.json" | while read sha path; do
    dst=$W/oldraw/$slug/${path#data/raw/$city/}
    mkdir -p $(dirname $dst)
    [ -s $dst ] || git -C $m cat-file blob $sha > $dst
  done
  echo "OK $slug $(find $W/oldraw/$slug -type f | wc -l) files"
done
for pair in gunsan:gunsan:gunsan daegu:Daegu:daegu haenam:haenam:haenam; do
  slug=${pair%%:*}; rest=${pair#*:}; repo=${rest%%:*}; city=${rest##*:}
  for v in tourapi tourapi_recollect; do
    src=/home/user/$repo/data/raw/$city/$v
    [ -d $src ] || continue
    mkdir -p $W/oldraw/$slug/$v
    for f in korservice2.tar.gz barrier_free.tar.gz korpettourservice2.tar.gz gocamping.tar.gz photo_gallery.tar.gz manifest.json; do [ -f $src/$f ] && cp -p $src/$f $W/oldraw/$slug/$v/; done
  done
  echo "OK $slug $(find $W/oldraw/$slug -type f | wc -l) files"
done
