#!/usr/bin/env python3
"""한국관광공사 다른 data.go.kr 서비스: 탐색(probe, 서비스마다 1~2회)과, 장소·행사 단위 사실을 주는 서비스의 20곳 수집.

    TOURAPI_KEY=... python3 extra.py probe
    TOURAPI_KEY=... python3 extra.py collect --svc wellness|medical|odii|phoko|video [--jobs 3]

pipeline.tourapi 클라이언트(부산 저장소, 이름 규칙은 20곳 모두 같음)로 부르고, 응답은 전역 캐시
cache/tourapi/<서비스 소문자>/<op>-<sha1 16>.json 에 둔다(키는 환경 변수로만). 장부·닫힘은 driver.py 와 같다.
이 서비스들을 읽는 사이트 도구는 아직 없다 — 폴더 이름은 tools/tourapi_harvest.py 관례(서비스 이름 소문자)를 따른다.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")
sys.path.insert(0, str(WORK / "scripts"))
import driver  # noqa: E402

T = driver.setup(Path("/home/user/busan"))
from tools.tourapi_bulk import retry  # noqa: E402  (부산 저장소의 네트워크 재시도)

B = "https://apis.data.go.kr/B551011/"
CACHE = WORK / "cache" / "tourapi"
STATE = WORK / "state"
SUFFIX = {"LocgoHubTarService1": "1"}


def client(svc: str, suffix: str = "") -> "T.TourAPI":
    return T.TourAPI(os.environ["TOURAPI_KEY"], base_url=B + svc, op_suffix=SUFFIX.get(svc, suffix),
                     mobile_app="TravelSite", cache_dir=CACHE / svc.lower(), max_calls=100000)


def raw_of(api, op, params) -> dict:
    p = {k: v for k, v in params.items() if v not in (None, "")}
    path = api._cache_path(op, p)
    return json.loads(path.read_text("utf-8")) if path.exists() else {}


def total(d: dict):
    try:
        return int(d["response"]["body"]["totalCount"])
    except (KeyError, TypeError, ValueError):
        return None


PROBES = [  # (service, catalog id, op, params, what it gives)
    ("Odii", "15101971", "themeBasedList", {"langCode": "ko", "numOfRows": 2, "pageNo": 1}),
    ("Odii", "15101971", "storyBasedList", {"langCode": "ko", "numOfRows": 2, "pageNo": 1}),
    ("WellnessTursmService", "15144030", "areaBasedList", {"langDivCd": "KOR", "numOfRows": 2, "pageNo": 1}),
    ("WellnessTursmService", "15144030", "areaBasedList", {"langDivCd": "KOR", "numOfRows": 2, "pageNo": 1, "lDongRegnCd": "26"}),
    ("MdclTursmService", "15143913", "areaBasedList", {"langDivCd": "KOR", "numOfRows": 2, "pageNo": 1}),
    ("MdclTursmService", "15143913", "areaBasedList", {"langDivCd": "KOR", "numOfRows": 2, "pageNo": 1, "lDongRegnCd": "26"}),
    ("PhokoAwrdService", "15145706", "phokoAwrdList", {"numOfRows": 2, "pageNo": 1}),
    ("PhokoAwrdService", "15145706", "phokoAwrdList", {"numOfRows": 2, "pageNo": 1, "lDongRegnCd": "26"}),
    ("VideoService", "15162188", "videoList", {"numOfRows": 2, "pageNo": 1}),
    ("VideoService", "15162188", "videoList", {"numOfRows": 2, "pageNo": 1, "lDongRegnCd": "26"}),
    ("LocgoHubTarService1", "15128559", "areaBasedList", {"numOfRows": 2, "pageNo": 1, "baseYm": "202609", "areaCd": "52", "signguCd": "52130"}),
    ("AreaTarResDemService", "15152138", "areaTarSvcDemList", {"numOfRows": 2, "pageNo": 1, "baseYm": "202609", "areaCd": "52", "signguCd": "52130"}),
    ("AreaTarDemDsService", "15151868", "areaTarSjrnDsList", {"numOfRows": 2, "pageNo": 1, "baseYm": "202609", "areaCd": "52", "signguCd": "52130"}),
    ("AreaTarDivService", "15151365", "areaTouDivList", {"numOfRows": 2, "pageNo": 1, "baseYm": "202609", "areaCd": "52", "signguCd": "52130"}),
]


def probe() -> None:
    out = []
    for svc, cid, op, params in PROBES:
        api = client(svc)
        row = {"service": svc, "catalog": f"https://www.data.go.kr/data/{cid}/openapi.do", "op": op, "params": params}
        try:
            items = retry(api.call, op, **params)
            d = raw_of(api, op, params)
            row.update({"ok": True, "totalCount": total(d), "fields": sorted(items[0].keys()) if items else [],
                        "sample": {k: str(v)[:80] for k, v in (items[0] if items else {}).items()}})
        except T.TourAPIError as err:
            row.update({"ok": False, "error": T.redact(str(err), api.service_key)[:300]})
        out.append(row)
        print(json.dumps({k: row.get(k) for k in ("service", "op", "ok", "totalCount", "error")}, ensure_ascii=False), flush=True)
    (STATE / "extra_probe.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), "utf-8")
    with open(STATE / "extra_touched.txt", "a", encoding="utf-8") as fh:
        fh.writelines(t + "\n" for t in sorted(driver.TOUCHED))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    a = ap.parse_args()
    if a.cmd == "probe":
        probe()


def probe_kor2() -> None:
    """KorService2의 사이트들이 아직 안 쓰는 오퍼레이션 두 개(detailPetTour2·searchStay2) 1회씩."""
    api = T.TourAPI(os.environ["TOURAPI_KEY"], base_url=B + "KorService2", op_suffix="2", mobile_app="TravelSite",
                    cache_dir=CACHE / "_probe_korservice2", max_calls=100)
    out = []
    for op, params in (("detailPetTour", {"contentId": "2930927"}),
                       ("searchStay", {"numOfRows": 2, "pageNo": 1, "lDongRegnCd": "26", "arrange": "A"})):
        row = {"service": "KorService2", "op": op + "2", "params": params}
        try:
            items = retry(api.call, op, **params)
            row.update({"ok": True, "totalCount": total(raw_of(api, op, params)),
                        "fields": sorted(items[0].keys()) if items else []})
        except T.TourAPIError as err:
            row.update({"ok": False, "error": T.redact(str(err), api.service_key)[:300]})
        out.append(row)
        print(json.dumps(row, ensure_ascii=False)[:400], flush=True)
    prev = json.loads((STATE / "extra_probe.json").read_text("utf-8"))
    prev = [r for r in prev if r.get("service") != "KorService2"] + out
    (STATE / "extra_probe.json").write_text(json.dumps(prev, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__" and sys.argv[1:2] == ["probe_kor2"]:
    probe_kor2()
