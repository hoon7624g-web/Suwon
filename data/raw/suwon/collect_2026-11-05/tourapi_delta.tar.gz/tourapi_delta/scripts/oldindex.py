#!/usr/bin/env python3
"""옛 원응답 묶음(oldraw/<slug>/tourapi_recollect, tourapi)의 파일 목록과 옛 목록 응답의 modifiedtime을 색인한다.
병합 때 순서와 같게: tourapi_recollect가 먼저, tourapi는 없는 파일만."""
import json, tarfile, datetime as dt, sys
from pathlib import Path
W = Path("/home/user/work/tourapi_delta")
for sd in sorted((W / "oldraw").iterdir()):
    files, lists = {}, {}
    for variant in ("tourapi_recollect", "tourapi"):
        for arc in sorted((sd / variant).glob("*.tar.gz")) if (sd / variant).exists() else []:
            with tarfile.open(arc, "r:gz") as tar:
                for m in tar.getmembers():
                    if not m.isfile() or not m.name.endswith(".json") or m.name in files:
                        continue
                    kst = dt.datetime.fromtimestamp(m.mtime, dt.timezone(dt.timedelta(hours=9)))
                    files[m.name] = {"date": kst.date().isoformat(), "ts": kst.strftime("%Y%m%d%H%M%S"), "src": f"{variant}/{arc.name}"}
                    base = m.name.rsplit("/", 1)[-1]
                    if base.startswith(("areaBasedList-", "searchFestival-")) and "/" not in m.name:
                        try:
                            d = json.loads(tar.extractfile(m).read())
                            it = d["response"]["body"]["items"]
                            it = it.get("item", []) if isinstance(it, dict) else []
                            it = it if isinstance(it, list) else [it]
                        except Exception:
                            it = []
                        for i in it:
                            cid = str(i.get("contentid"))
                            mt = str(i.get("modifiedtime") or "")
                            if mt > lists.get(cid, ""):
                                lists[cid] = mt
    (W / "state" / sd.name).mkdir(parents=True, exist_ok=True)
    (W / "state" / sd.name / "oldindex.json").write_text(json.dumps({"files": files, "list_mtime": lists}, ensure_ascii=False), "utf-8")
    dates = sorted({v["date"] for v in files.values()})
    print(sd.name, len(files), "files", len(lists), "listed ids", "dates", dates[:1], dates[-1:])
