#!/usr/bin/env python3
"""두루누비·관광사진 갤러리 차이(호출 없음). state/<slug>/durunubi.json, state/<slug>/photo_diff.json

두루누비: 오늘 받은 전국 courseList·routeList 가운데 sigun(코스가 지나는 시·군)에 사이트 지역 이름이 든 코스.
          옛 원응답 묶음(data/raw/<city>/tourapi/durunubi.tar.gz — 대구·부산·여수·전주·춘천만 있음)의 같은 코스와 비교:
          new(옛 묶음에 없음) · changed(modifiedtime이 더 새로움) · same · gone(옛 묶음에만). 묶음이 없는 사이트는 '이전 수집 없음'.
관광사진: 오늘 받은 gallerySearchList(사이트 도구와 같은 키워드)의 galContentId를 옛 묶음 photo_gallery와 places.json
          images.gallery_id(이미 붙인 사진)와 비교.
"""
from __future__ import annotations

import json
import tarfile
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
CACHE = WORK / "cache" / "tourapi"
SB = WORK / "sandbox"
KEEP = ("crsIdx", "routeIdx", "crsKorNm", "crsDstnc", "crsTotlRqrmHour", "crsLevel", "crsCycle", "sigun", "brdDiv",
        "createdtime", "modifiedtime")


def items(d: dict) -> list[dict]:
    try:
        it = d["response"]["body"]["items"]
    except (KeyError, TypeError):
        return []
    it = it.get("item", []) if isinstance(it, dict) else []
    return it if isinstance(it, list) else [it]


def tar_items(path: Path, prefix: str) -> list[dict]:
    out = []
    if not path.exists():
        return out
    with tarfile.open(path, "r:gz") as tar:
        for m in tar.getmembers():
            if m.isfile() and m.name.rsplit("/", 1)[-1].startswith(prefix):
                try:
                    out += items(json.loads(tar.extractfile(m).read()))
                except ValueError:
                    pass
    return out


def main() -> None:
    sys_path = str(WORK / "scripts")
    import sys
    sys.path.insert(0, sys_path)
    from orchestrate import SITES
    cur_courses = {}
    for f in sorted((CACHE / "durunubi").glob("courseList-*.json")):
        for it in items(json.loads(f.read_text("utf-8"))):
            cur_courses[it["crsIdx"]] = it
    routes = {}
    for f in sorted((CACHE / "durunubi").glob("routeList-*.json")):
        for it in items(json.loads(f.read_text("utf-8"))):
            routes[it["routeIdx"]] = it
    for slug, (repo, city) in SITES.items():
        site = json.loads((SB / slug / "data" / city / "site.json").read_text("utf-8"))
        short = site.get("region") or ""
        old_path = next((p for p in (WORK / "oldraw" / slug).glob("tourapi*/durunubi.tar.gz")), None) if (WORK / "oldraw" / slug).exists() else None
        old = {it["crsIdx"]: it for it in tar_items(old_path, "courseList-")} if old_path else None
        mine = [c for c in cur_courses.values() if short and short in str(c.get("sigun") or "")]
        rows = []
        for c in sorted(mine, key=lambda c: c.get("crsKorNm", "")):
            r = {k: c.get(k) for k in KEEP}
            r["routeNm"] = (routes.get(c.get("routeIdx")) or {}).get("themeNm", "")
            if old is None:
                r["status"] = "이전 수집 없음"
            elif c["crsIdx"] not in old:
                r["status"] = "new"
            elif str(c.get("modifiedtime") or "") > str(old[c["crsIdx"]].get("modifiedtime") or ""):
                r["status"] = "changed"
            else:
                r["status"] = "same"
            rows.append(r)
        gone = []
        if old is not None:
            gone = [{k: o.get(k) for k in KEEP} for k, o in old.items()
                    if short in str(o.get("sigun") or "") and k not in cur_courses]
        dur = {"region_word": short, "previous_bundle": str(old_path.relative_to(WORK)) if old_path else None,
               "nationwide": {"courses": len(cur_courses), "routes": len(routes)},
               "courses": rows, "gone_from_provider": gone,
               "counts": {s: sum(1 for r in rows if r["status"] == s) for s in ("new", "changed", "same", "이전 수집 없음")}}
        (STATE / slug / "durunubi.json").write_text(json.dumps(dur, ensure_ascii=False, indent=1), "utf-8")

        # photos
        touched = set()
        for f in (STATE / slug).glob("touched_photo*.txt"):
            touched.update(x.strip() for x in f.read_text("utf-8").splitlines() if x.strip().startswith("photo_gallery/"))
        cur = {}
        for rel in touched:
            for it in items(json.loads((CACHE / rel).read_text("utf-8"))):
                cur[str(it.get("galContentId"))] = it
        old_ids, bundle_day = set(), ""
        for p in (WORK / "oldraw" / slug).glob("tourapi*/photo_gallery.tar.gz") if (WORK / "oldraw" / slug).exists() else []:
            old_ids |= {str(it.get("galContentId")) for it in tar_items(p, "gallerySearchList-")}
            with tarfile.open(p, "r:gz") as tar:
                import datetime as dt
                days = [dt.datetime.fromtimestamp(m.mtime, dt.timezone(dt.timedelta(hours=9))).strftime("%Y%m%d")
                        for m in tar.getmembers() if m.isfile()]
                bundle_day = max([bundle_day, *days])
        places = json.loads((SB / slug / "data" / city / "places.json").read_text("utf-8"))
        places = places if isinstance(places, list) else places.get("places", [])
        used = {str(im.get("gallery_id")) for p in places for im in (p.get("images") or []) if im.get("gallery_id")}
        new = [cur[g] for g in sorted(cur) if g not in old_ids]
        pd = {"keywords_files": len(touched), "now": len(cur), "in_last_bundle": len(old_ids & set(cur)),
              "last_bundle_total": len(old_ids), "new_since_last_harvest": len(new),
              "gone_since_last_harvest": len(old_ids - set(cur)) if old_ids else 0,
              "already_on_places": len(used & set(cur)), "last_bundle_day": bundle_day,
              "new_created_after_bundle": sum(1 for it in new if str(it.get("galCreatedtime") or "")[:8] > bundle_day),
              "new_older_photos_by_more_keywords": sum(1 for it in new if str(it.get("galCreatedtime") or "")[:8] <= bundle_day),
              "new_photos": new,
              "licence": "PhotoGalleryService1(포토코리아) — 서비스 설명: 공공누리 제1유형, 자유 다운로드·활용(출처 표시). "
                         "항목마다 따로 붙은 저작권 필드는 없다(galUseFlag가 오면 원응답에 있음)."}
        (STATE / slug / "photo_diff.json").write_text(json.dumps(pd, ensure_ascii=False, indent=1), "utf-8")
        print(slug, dur["counts"], len(gone), "| photos now", pd["now"], "bundle", pd["last_bundle_total"],
              "new", pd["new_since_last_harvest"], "(after bundle", pd["new_created_after_bundle"], "older", pd["new_older_photos_by_more_keywords"], ") on places", pd["already_on_places"])


if __name__ == "__main__":
    main()
