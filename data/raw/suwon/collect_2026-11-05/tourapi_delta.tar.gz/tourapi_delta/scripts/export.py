#!/usr/bin/env python3
"""state/ -> out/<slug>/ : diff.json, README.md, cache/tourapi/(그 사이트가 쓴 원응답만, 파일 날짜 유지).
고캠핑 전국 목록은 한 벌만 out/_shared/cache/tourapi/gocamping/ 에 둔다. 호출 없음."""
from __future__ import annotations

import json
import re
import shutil
from collections import Counter
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
CACHE = WORK / "cache" / "tourapi"
OUT = WORK / "out"
SB = WORK / "sandbox"
sys_path = str(WORK / "scripts")
import sys  # noqa: E402
sys.path.insert(0, sys_path)
from orchestrate import SITES  # noqa: E402

METRO_DO = {"daegu": "대구광역시", "busan": "부산광역시", "incheon": "인천광역시", "jeju": "제주특별자치도",
            "sejong": "세종특별자치시"}
TYPES = {"12": "관광지", "14": "문화시설", "15": "행사", "25": "여행코스", "28": "레포츠", "32": "숙박", "38": "쇼핑",
         "39": "음식점"}
FAMILY_GUNSAN = {"gunsan", "haenam"}


def jl(p: Path, default=None):
    return json.loads(p.read_text("utf-8")) if p.exists() else default


def norm(s) -> str:
    return re.sub(r"[^0-9a-z가-힣]", "", str(s or "").lower())


def metres(a, b) -> float:
    import math
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * 6371000 * math.asin(math.sqrt(h))


def camps_all() -> list[dict]:
    out = {}
    for f in sorted((CACHE / "gocamping").glob("basedList-*.json")):
        it = jl(f)["response"]["body"]["items"]
        it = it.get("item", []) if isinstance(it, dict) else []
        for i in (it if isinstance(it, list) else [it]):
            out[str(i.get("contentId"))] = i
    return list(out.values())


def camp_report(slug: str, site: dict, places: list[dict], camps: list[dict]) -> dict:
    loc = site.get("locality") or ""
    if slug in METRO_DO:
        area = [c for c in camps if c.get("doNm") == METRO_DO[slug]]
    else:
        area = [c for c in camps if (c.get("sigunguNm") or "").startswith(loc)]
    have_ids = set()
    for p in places:
        if str(p.get("id", "")).startswith("gocamping-"):
            have_ids.add(str(p["id"]).split("-", 1)[1])
        for v in (p.get("fact_sources") or {}).values():
            if isinstance(v, dict) and "고캠핑" in str(v.get("provider", "")) and v.get("contentid"):
                have_ids.add(str(v["contentid"]))
    located = [p for p in places if (p.get("geo") or {}).get("lat") and not p.get("duplicate_of")]
    lacking, matched = [], []
    for c in area:
        cid = str(c.get("contentId"))
        if cid in have_ids:
            matched.append(cid)
            continue
        hit = None
        try:
            g = (float(c["mapY"]), float(c["mapX"]))
            ck = norm(c.get("facltNm"))
            for p in located:
                pk = norm(p.get("name"))
                if ck and pk and (ck in pk or pk in ck) and metres(g, (p["geo"]["lat"], p["geo"]["lng"])) <= 300:
                    hit = p
                    break
        except (KeyError, TypeError, ValueError):
            pass
        if hit:
            matched.append(cid)
        else:
            lacking.append({"contentId": cid, "facltNm": c.get("facltNm"), "induty": c.get("induty"),
                            "addr1": c.get("addr1"), "sigunguNm": c.get("sigunguNm"), "tel": c.get("tel", "")})
    return {"area_rule": f"doNm == {METRO_DO[slug]}" if slug in METRO_DO else f"sigunguNm 시작 '{loc}'",
            "in_area": len(area), "already_in_site": len(matched), "lacking": lacking}


def touched(slug: str) -> set[str]:
    """이 사이트 단계들이 읽거나 받은 캐시 파일 + 이 사이트 상세 계획(plan_*.json)의 호출 가운데 캐시에 있는 것
    (중간에 멈춘 작업자는 touched 목록을 못 남기므로 계획으로 다시 모은다)."""
    from diffplan import cache_name, op_params
    out = set()
    for f in (STATE / slug).glob("touched_*.txt"):
        out.update(x.strip() for x in f.read_text("utf-8").splitlines() if x.strip())
    for f in (STATE / slug).glob("plan_*.json"):
        for cid, ctype, ops in json.loads(f.read_text("utf-8")):
            for op in ops:
                name = cache_name(*op_params(op, str(cid), str(ctype)))
                if (CACHE / name).exists():
                    out.add(name)
    return {t for t in out if not t.startswith(("gocamping/", "durunubi/"))}


def main() -> None:
    camps = camps_all()
    shared = OUT / "_shared" / "cache" / "tourapi" / "gocamping"
    shared.mkdir(parents=True, exist_ok=True)
    for f in sorted((CACHE / "gocamping").glob("*.json")):
        shutil.copy2(f, shared / f.name)
    dshared = OUT / "_shared" / "cache" / "tourapi" / "durunubi"
    dshared.mkdir(parents=True, exist_ok=True)
    for f in sorted((CACHE / "durunubi").glob("*.json")):
        shutil.copy2(f, dshared / f.name)
    ledger = jl(STATE / "ledger.json", {})
    closed = jl(STATE / "closed.json", {})
    totals = {}
    for slug, (repo, city) in SITES.items():
        st = STATE / slug
        d = jl(st / "diff.json")
        if not d:
            continue
        site = jl(SB / slug / "data" / city / "site.json")
        places = jl(SB / slug / "data" / city / "places.json")
        places = places if isinstance(places, list) else places.get("places", [])
        bf, pet, lang, photo = jl(st / "bf.json"), jl(st / "pet.json"), jl(st / "lang.json"), jl(st / "photo.json")
        gone_check = jl(st / "gone_check.json", {})
        camp = camp_report(slug, site, places, camps)
        od = OUT / slug
        oc = od / "cache" / "tourapi"
        if oc.exists():
            shutil.rmtree(oc)
        files = sorted(touched(slug))
        for rel in files:
            src = CACHE / rel
            if src.exists():
                dst = oc / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        ops = Counter((r.split("/")[0] if "/" in r else "korservice2", r.rsplit("/", 1)[-1].split("-")[0]) for r in files)
        extra = {
            "barrier_free": None if not bf else {
                "list_items_in_sido": len(bf.get("list", [])),
                "published_matched_lacking_bf_facts": bf.get("matched_lacking"),
                "fetched_detailWithTour": len(bf.get("detail", {})),
                "with_values": sorted(c for c, v in bf.get("detail", {}).items() if v.get("fields_with_value")),
                "stopped": bf.get("stopped", "")},
            "pet": None if not pet else {
                "list_items_in_sido": len(pet.get("list", [])),
                "published_matched_lacking_pet_facts": pet.get("matched_lacking"),
                "fetched_detailPetTour": len(pet.get("detail", {})),
                "with_values": sorted(c for c, v in pet.get("detail", {}).items() if v.get("fields_with_value")),
                "stopped": pet.get("stopped", "")},
            "foreign_names_for_new_items": None if lang is None else {
                c: {"service": v["service"], "list_items": v["list_items"], "error": v["error"],
                    "matched": v["new_item_names"]} for c, v in lang.items()},
            "gocamping": camp,
            "photo_gallery": photo,
            "gone_check": gone_check,
            "durunubi": jl(st / "durunubi.json"),
            "photo_gallery_delta": jl(st / "photo_diff.json"),
            "other_kto_services_probe": jl(STATE / "extra_probe.json", []),
        }
        out = {**d, **extra, "raw_files": {"count": len(files), "by_folder_op": {f"{a}/{b}": n for (a, b), n in sorted(ops.items())}}}
        od.mkdir(parents=True, exist_ok=True)
        (od / "diff.json").write_text(json.dumps(out, ensure_ascii=False, indent=1) + "\n", "utf-8")
        totals[slug] = summarize(slug, out)
        (od / "README.md").write_text(readme(slug, repo, city, out, totals[slug]), "utf-8")
    (OUT / "summary.json").write_text(json.dumps({"sites": totals, "ledger": ledger, "closed": closed},
                                                 ensure_ascii=False, indent=1) + "\n", "utf-8")
    for s, v in totals.items():
        print(s, json.dumps(v, ensure_ascii=False))


def summarize(slug: str, o: dict) -> dict:
    n = lambda dct: sum(len(v) for v in dct.values())  # noqa: E731
    lang = o.get("foreign_names_for_new_items") or {}
    return {
        "new": n(o["new"]), "new_by_type": {TYPES.get(t, t): len(v) for t, v in o["new"].items()},
        "changed": n(o["changed"]), "changed_published": sum(1 for v in o["changed"].values() for r in v
                                                            if "published" in (r.get("site_status") or [])),
        "gone": n(o["gone"]),
        "gone_confirmed": sum(1 for v in (o.get("gone_check") or {}).values() if isinstance(v, dict) and str(v.get("detailCommon", "")).startswith("빈")),
        "skipped_by_overrides": len(o.get("new_overridden", [])),
        "events_new": len(o["events_new"]), "events_changed": len(o["events_changed"]),
        "bf_add": len((o.get("barrier_free") or {}).get("with_values") or []),
        "pet_add": len((o.get("pet") or {}).get("with_values") or []),
        "camps_lacking": len(o["gocamping"]["lacking"]), "camps_in_area": o["gocamping"]["in_area"],
        "foreign_names": {c: len(v["matched"]) for c, v in lang.items()},
        "gallery": (o.get("photo_gallery") or {}).get("photos"),
        "durunubi": ((o.get("durunubi") or {}).get("counts") or {}),
        "durunubi_courses": len((o.get("durunubi") or {}).get("courses") or []),
        "photo_new": (o.get("photo_gallery_delta") or {}).get("new_since_last_harvest"),
        "photo_new_after_bundle": (o.get("photo_gallery_delta") or {}).get("new_created_after_bundle"),
        "raw_files": o["raw_files"]["count"],
    }


def readme(slug: str, repo: str, city: str, o: dict, s: dict) -> str:
    gunsan = slug in FAMILY_GUNSAN
    L = []
    L.append(f"# {slug} — TourAPI 변경분 원응답 (2026-11-05 수집)\n")
    L.append(f"저장소: `{repo}` · 데이터: `data/{city}/` · 목록 기준일 {o['list_date']} · 법정동 코드 lDongRegnCd={o['regn']}"
             + (f" / lDongSignguCd={','.join(c for c, _ in o['signgu'])}" if o['scope'] != 'region' else " (시·도 전체)") + "\n")
    L.append("이 폴더는 한국관광공사 TourAPI 원응답만 담는다. 장소·행사·번역 데이터는 만들거나 고치지 않았다. "
             "값은 사이트 저장소에서 아래 병합 도구로 오프라인 반영한다(새 장소는 draft, 공개·검수 값은 사람이 정한다).\n")
    L.append("## 차이 (사이트 places.json·events.json 기준)\n")
    L.append("| 구분 | 수 |\n|---|---|")
    L.append(f"| 새 항목(places.json에 없음) | {s['new']} ({', '.join(f'{k} {v}' for k, v in s['new_by_type'].items()) or '-'}) |")
    L.append(f"| tourapi_overrides skip·hold로 빼 둔 항목 | {s['skipped_by_overrides']} |")
    L.append(f"| 바뀐 항목(목록 modifiedtime > places.json) | {s['changed']} (공개 {s['changed_published']}) |")
    L.append(f"| 사라진 항목(사이트에 있으나 지금 목록에 없음, 보고만) | {s['gone']} (detailCommon2 빈 응답으로 삭제 확인 {s['gone_confirmed']}) |")
    L.append(f"| 새 행사(1월 1일 이후, events.json에 없음) | {s['events_new']} |")
    L.append(f"| 바뀐 행사(modifiedtime > checked_at) | {s['events_changed']} |")
    L.append(f"| 무장애 정보 새로 생길 공개 장소 | {s['bf_add']} |")
    L.append(f"| 반려동물 정보 새로 생길 공개 장소 | {s['pet_add']} |")
    L.append(f"| 고캠핑 야영장(지역 {s['camps_in_area']}곳 중 사이트에 없는 곳) | {s['camps_lacking']} |")
    L.append(f"| 새 항목의 외국어 공식 이름(언어별) | {', '.join(f'{k} {v}' for k, v in s['foreign_names'].items()) or '-'} |")
    if s.get("gallery") is not None:
        L.append(f"| 관광사진 갤러리 메타데이터 | {s['gallery']}장 (이미지 파일은 받지 않음) |")
    L.append(f"| 원응답 파일 | {s['raw_files']} |\n")
    L.append("자세한 목록은 `diff.json`(new·changed·gone은 contenttypeid별, events_new·events_changed, barrier_free·pet·"
             "gocamping·foreign_names_for_new_items·photo_gallery). 외국어 이름은 그 저장소 `tools/en_content.py`의 "
             "match_en 규칙(좌표 150m·유형·이름 근거)으로 찾은 보고용 후보다 — names.json에는 새 장소가 공개된 뒤 "
             "`en_content.py names`가 넣는다.\n")
    L.append("## 원응답 위치와 이름\n")
    L.append("`cache/tourapi/` 는 저장소의 `data/cache/tourapi/` 와 같은 구조·이름이다(`pipeline/tourapi.py` "
             "`_cache_path`: 오퍼레이션-sha1(base_url·op·인자)[:16].json, 파일 날짜 = 받은 날 → checked_at). "
             "목록·행사 목록은 이 저장소 도구와 같은 호출 인자로 다시 받아 옛 묶음의 같은 이름 파일을 대신한다.\n")
    L.append("| 폴더/오퍼레이션 | 파일 |\n|---|---|")
    for k, v in o["raw_files"]["by_folder_op"].items():
        L.append(f"| {k} | {v} |")
    L.append("\n고캠핑 전국 목록(basedList 32쪽)은 한 벌만 `../_shared/cache/tourapi/gocamping/` 에 있다.\n")
    L.append("## 병합 순서 (저장소에서, 호출 0회)\n")
    L.append("```bash")
    L.append(f"cd {repo}")
    L.append("# 1) 옛 원응답 묶음을 캐시로: tourapi_recollect 먼저, 그다음 tourapi는 없는 파일만(파일 날짜 유지)")
    sparse = slug not in ("gunsan", "daegu", "haenam")
    L.append(f"python /home/user/work/tourapi_delta/scripts/apply_delta.py --repo {repo} --city {city} --slug {slug}"
             + (" --oldraw" if sparse else "") + "          # 미리보기: 1)+2)에서 몇 개가 복원·복사되는지")
    L.append(f"python /home/user/work/tourapi_delta/scripts/apply_delta.py --repo {repo} --city {city} --slug {slug}"
             + (" --oldraw" if sparse else "") + " --apply  # 쓰기")
    if sparse:
        L.append("#   (--oldraw: 이 저장소는 data/raw가 희소 체크아웃에서 빠져 있다. `git sparse-checkout add /data/raw/` 로 꺼냈으면"
                 " --oldraw 없이 저장소 묶음을 쓴다 — 외국어 묶음까지 들어 있어 더 완전하다)")
    L.append("# 2) (위 스크립트가 함) 이 폴더의 원응답을 덮어쓰기 복사 — 같은 이름이면 새 응답이 이긴다")
    L.append(f"#    cp -a /home/user/work/tourapi_delta/out/{slug}/cache/tourapi/. data/cache/tourapi/")
    L.append("#    cp -a /home/user/work/tourapi_delta/out/_shared/cache/tourapi/. data/cache/tourapi/")
    if gunsan:
        L.append(f"python tools/tourapi_bulk.py --data data/{city} --offline --events --details --add-new")
        cov = (jl(STATE / "coverage.json", {}).get(slug) or {}).get("missing", {})
        if cov.get("image", 1) == 0:
            L.append(f"python tools/tourapi_bulk.py --data data/{city} --offline --gallery   # 모든 장소의 detailImage가 캐시에 있다")
        else:
            L.append("# --gallery는 이 엔진에서 장소마다 오류를 잡지 않는다: detailImage가 없는 장소가 하나라도 있으면 멈춘다.")
            L.append(f"#   python tools/tourapi_bulk.py --data data/{city} --offline --gallery")
        L.append(f"python tools/tourapi_bulk.py --data data/{city} --offline --barrier-free")
        L.append(f"python tools/en_content.py names --data data/{city} --offline          # 공개 장소의 영어 공식 이름")
        L.append(f"python tools/en_content.py names --data data/{city} --lang ja --offline   # ja zh-hans zh-hant de fr es ru 도 같은 방식")
        L.append("# 반려동물·관광사진·고캠핑: 이 저장소에는 tools/harvest_merge.py가 없다. 원응답은 대구 계열 수집기와 같은 폴더")
        L.append("# (korpettourservice2/, photo_gallery/, gocamping/)에 있으니 harvest_merge.py를 옮긴 뒤")
        L.append(f"#   python tools/harvest_merge.py --data data/{city} --pet --photos --camping   # 미리보기, 확인 뒤 --apply")
    else:
        L.append(f"python tools/tourapi_bulk.py --data data/{city} --offline --events --details --add-new")
        L.append(f"python tools/tourapi_bulk.py --data data/{city} --offline --gallery")
        L.append(f"python tools/tourapi_bulk.py --data data/{city} --offline --barrier-free")
        L.append(f"python tools/tourapi_bulk.py --data data/{city} --offline --courses     # 여행코스 → tourapi_courses.json")
        L.append(f"python tools/harvest_merge.py --data data/{city} --pet --camping           # 미리보기(reports/harvest_merge.md)")
        L.append(f"python tools/harvest_merge.py --data data/{city} --pet --camping --apply")
        L.append(f"python tools/en_content.py names --data data/{city} --lang en --offline    # 외국어 공식 이름(언어마다)")
    L.append("```\n")
    cov = jl(STATE / "coverage.json", {}).get(slug) or {}
    bfc = jl(STATE / "bf_coverage.json", {}).get(slug) or {}
    if cov:
        m = cov.get("missing", {})
        L.append(f"- 옛 묶음 + 이 폴더로 places.json의 contentid {cov.get('places_with_cid')}곳 가운데 상세가 빠진 곳: "
                 f"detailCommon {m.get('common')} · detailIntro {m.get('intro')} · detailInfo {m.get('info')} · detailImage {m.get('image')}"
                 " (빠진 곳은 TourAPI에서 지워진 항목 — gone).")
    if bfc:
        miss = bfc.get("in_list_missing") or 0
        L.append(f"- `--barrier-free`: 공개 장소 {bfc.get('published_with_cid')}곳 가운데 무장애 목록에 있는 {bfc.get('published_in_bf_list')}곳"
                 + (" — 모두 캐시에 있다." if not miss else
                    f" 가운데 {miss}곳은 아직 detailWithTour2 캐시가 없다(이미 사이트에 무장애 사실이 있는 곳; KorWithService2 한도로 멈춤 —"
                    " RESUME.md의 bffill). 그 장소들은 오프라인 실행에서 오류 목록에 남고 기존 값은 그대로다.")
                 + " 목록에 없는 공개 장소는 캐시가 없어 오류 목록에만 남는다(무장애 정보가 없는 곳).")
    L.append("- 도구 출력의 live_calls가 0이어야 한다. 0이 아니면 캐시가 모자란 것이니 `RESUME.md`의 남은 일을 먼저 한다.")
    L.append("- 행사 목록 캐시 키에는 그해 1월 1일(`20260101`)이 들어간다. 2027년에 병합하면 행사 목록을 다시 받아야 한다.")
    L.append("- `--details`는 places.json의 모든 장소 상세를 읽는다. 캐시가 없는 장소는 오류 목록에 남을 뿐 멈추지 않는다.")
    L.append("- 사라진 항목(gone)은 보고만 한다. 내리기·보관은 사람이 정한다.")
    L += extra_section(slug, city, o, gunsan)
    return "\n".join(L) + "\n"


def extra_section(slug: str, city: str, o: dict, gunsan: bool) -> list[str]:
    """2026-11-05 오후 추가 수집: 두루누비, 관광사진 갤러리 새로 받기, 다른 한국관광공사 서비스 탐색."""
    L = ["", "## 추가 수집 (2026-11-05 오후) — 두루누비 · 관광사진 갤러리 · 다른 한국관광공사 서비스", ""]
    d = o.get("durunubi") or {}
    rows = d.get("courses") or []
    L.append(f"### 두루누비(코리아둘레길) — 코스 {len(rows)}개가 이 지역(sigun에 '{d.get('region_word', '')}')을 지난다")
    L.append(f"- 공급자 전국 목록: 코스 {d.get('nationwide', {}).get('courses')}·길 {d.get('nationwide', {}).get('routes')}"
             " (모두 걷기 DNWW; 서비스 설명의 284코스 중 지금 API가 내주는 수). 원응답은 `../_shared/cache/tourapi/durunubi/`"
             " (tools/tourapi_harvest.py --service durunubi 와 같은 이름).")
    prev = d.get("previous_bundle")
    L.append(f"- 이전 수집: {('`' + prev + '` (옛 원응답 묶음)') if prev else '없음 — 모두 처음 받는 코스'}"
             f" · 새 {d.get('counts', {}).get('new', 0)} · 바뀜 {d.get('counts', {}).get('changed', 0)} · 같음 {d.get('counts', {}).get('same', 0)}"
             f" · 공급자에서 사라짐 {len(d.get('gone_from_provider') or [])}")
    if rows:
        L.append("\n| 코스(crsIdx) | 이름 | 길 | 거리(km) | 소요(분) | 난이도 | 시·군 | 상태 |\n|---|---|---|---|---|---|---|---|")
        for r in rows:
            L.append(f"| {r['crsIdx']} | {r['crsKorNm']} | {r.get('routeNm', '')} | {r.get('crsDstnc', '')} | "
                     f"{r.get('crsTotlRqrmHour', '')} | {r.get('crsLevel', '')} | {r.get('sigun', '')} | {r['status']} |")
    L.append("- 병합 도구는 아직 없다(사이트 데이터에는 강릉 courses.json 한 코스만 두루누비 출처). 값은 원응답 그대로 쓰고, "
             "crsContents·crsSummary 같은 설명 문장은 원문이라 옮기지 않는다(링크·우리 문장).")
    pd = o.get("photo_gallery_delta") or {}
    L.append("")
    L.append(f"### 관광사진 갤러리(PhotoGalleryService1) — 지금 {pd.get('now')}장, 옛 묶음에 없던 {pd.get('new_since_last_harvest')}장")
    L.append(f"- 그중 옛 묶음 날짜({pd.get('last_bundle_day') or '-'}) 뒤에 올라온 사진 {pd.get('new_created_after_bundle')}장, "
             f"그 전 사진인데 지금 저장소 키워드가 늘어 처음 잡힌 것 {pd.get('new_older_photos_by_more_keywords')}장. "
             f"옛 묶음에만 있던 것 {pd.get('gone_since_last_harvest')}장. 이미 places.json에 붙은 사진 {pd.get('already_on_places')}장.")
    L.append("- 키워드는 이 저장소 `tools/tourapi_harvest.py` harvest_photo 그대로(군산·해남은 대구 계열 규칙). 원응답 "
             "`cache/tourapi/photo_gallery/gallerySearchList-*.json`(메타데이터만, 이미지 파일 없음). 사진마다 저작권 필드는 없고 "
             "서비스 설명이 '공공누리 제1유형, 자유 다운로드·활용'이다. 목록은 `diff.json` photo_gallery_delta.new_photos.")
    if gunsan:
        L.append("- 병합: 이 저장소에는 harvest_merge.py가 없다(대구 계열 것을 옮겨 `--photos`).")
    else:
        L.append(f"- 병합: `python tools/harvest_merge.py --data data/{city} --photos` (미리보기) → `--apply` → `python tools/image_sizes.py --data data/{city}` → `--photos --apply` 한 번 더.")
    L.append("")
    L.append("### 다른 한국관광공사 서비스(탐색 1~2회씩) — 이 키로는 쓸 수 없음")
    L.append("오디(Odii)·웰니스·의료관광·관광공모전 사진 수상작·관광 동영상·기초지자체 중심 관광지·지역별 관광 자원 수요/수요 강도/다양성 "
             "9개 서비스 모두 `HTTP 403 resultCode=30 등록되지 않은 서비스키` — data.go.kr 활용신청(개발계정 자동승인)이 먼저다. "
             "KorService2 detailPetTour2·searchStay2는 되지만 이미 쓰는 반려동물 서비스·숙박 목록과 같은 내용이라 받지 않았다. "
             "자세한 것은 /home/user/work/tourapi_delta/RESUME.md.")
    return L


if __name__ == "__main__":
    main()
