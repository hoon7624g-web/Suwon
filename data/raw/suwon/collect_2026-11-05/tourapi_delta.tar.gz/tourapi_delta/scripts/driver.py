#!/usr/bin/env python3
"""TourAPI 변경분 수집 작업자 — 한 사이트, 한 단계를 한 프로세스에서 돈다.

사이트 저장소(읽기 전용)를 sys.path 맨 앞에 두고 그 저장소의 pipeline.tourapi 클라이언트·목록 함수를 그대로 써서
캐시 파일 이름(오퍼레이션-sha1 16자리)과 호출 인자가 그 저장소 도구와 똑같게 만든다. 응답은 전역 캐시
/home/user/work/tourapi_delta/cache/tourapi/ 에 쌓이고(같은 호출은 다시 하지 않음), 이 단계가 읽거나 받은 캐시 파일
목록을 state/<slug>/touched_<phase>.txt 에 남긴다. 키는 환경 변수 TOURAPI_KEY 로만 받고 출력하지 않는다.

    python driver.py --slug gunsan --repo /home/user/gunsan --phase lists
    phases: lists | kdetail --plan FILE | bf | pet | lang | camp | photo
"""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import json
import os
import sys
import time
import traceback
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
CACHE = WORK / "cache" / "tourapi"
B = "https://apis.data.go.kr/B551011/"
TODAY = dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).date().isoformat()   # 공급자 하루 = 한국 날짜(00:00 KST 초기화)
CAP = int(os.environ.get("DELTA_CAP", "1000"))      # 서비스·오퍼레이션별 하루 상한(안전망)
LANGS = ("en", "ja", "zh-hans", "zh-hant", "de", "fr", "es", "ru")

TOUCHED: set[str] = set()
ERRORS: list[str] = []


# ------------------------------------------------------------------ ledger (calls per service.op, closed ops)
def _locked(path: Path, fn):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(str(path) + ".lock", "a+") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        try:
            data = json.loads(path.read_text("utf-8")) if path.exists() else {}
            out = fn(data)
            tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1, sort_keys=True), "utf-8")
            os.replace(tmp, path)
            return out
        finally:
            fcntl.flock(lk, fcntl.LOCK_UN)


LEDGER = STATE / "ledger.json"      # {date: {"svc.op": n}}
CLOSED = STATE / "closed.json"      # {date: {"svc.op": message}}


def ledger_add(key: str, n: int) -> None:
    def f(d):
        day = d.setdefault(TODAY, {})
        day[key] = day.get(key, 0) + n
    _locked(LEDGER, f)


def _read(path: Path) -> dict:
    for _ in range(20):
        try:
            return json.loads(path.read_text("utf-8")) if path.exists() else {}
        except (ValueError, OSError):
            time.sleep(0.1)
    return {}


def ledger_get(key: str) -> int:
    return (_read(LEDGER).get(TODAY) or {}).get(key, 0)


def closed_get(key: str) -> str:
    return (_read(CLOSED).get(TODAY) or {}).get(key, "")


def close(key: str, msg: str) -> None:
    def f(d):
        d.setdefault(TODAY, {}).setdefault(key, msg[:300])
    _locked(CLOSED, f)


# ------------------------------------------------------------------ repo import + client patch
def setup(repo: Path):
    sys.path.insert(0, str(repo))
    import pipeline.tourapi as T
    orig = T.TourAPI.call

    def svc_of(api) -> str:
        return api.base_url.rstrip("/").rsplit("/", 1)[-1]

    def call(self, op, **params):
        p = {k: v for k, v in params.items() if v not in (None, "")}
        path = self._cache_path(op, p)
        key = f"{svc_of(self)}.{op}"
        if not path.exists() or self.refresh:
            why = closed_get(key)
            if why:
                raise T.TourAPIQuotaError(f"{key}: 오늘 닫힘 — {why}")
            if ledger_get(key) >= CAP:
                close(key, f"작업 상한 {CAP}회")
                raise T.TourAPIQuotaError(f"{key}: 작업 상한 {CAP}회")
        before = self.live_calls
        try:
            return orig(self, op, **params)
        except T.TourAPIQuotaError as err:
            close(key, T.redact(str(err), self.service_key))
            raise
        except T.TourAPIError as err:
            ERRORS.append(f"{key} {json.dumps(p, ensure_ascii=False)[:120]}: {T.redact(str(err), self.service_key)[:200]}")
            raise
        finally:
            n = self.live_calls - before
            if n:
                ledger_add(key, n)
            if path.exists() and CACHE.resolve() in path.resolve().parents:
                TOUCHED.add(str(path.resolve().relative_to(CACHE.resolve())))

    T.TourAPI.call = call
    return T


def load_site(sb: Path):
    data = next(d for d in (sb / "data").iterdir() if d.is_dir() and d.name != "cache")
    site = json.loads((data / "site.json").read_text("utf-8"))
    return data, site


def family(repo: Path) -> str:
    """'daegu' (resolve_ldong·fetch_list가 있는 다도시 엔진) 또는 'gunsan'(군산·해남 엔진)."""
    src = (repo / "tools" / "tourapi_bulk.py").read_text("utf-8")
    return "daegu" if "def fetch_list(" in src else "gunsan"


def key() -> str:
    k = os.environ.get("TOURAPI_KEY", "")
    if not k:
        raise SystemExit("TOURAPI_KEY 없음")
    return k


# ------------------------------------------------------------------ region codes
def region(T, repo: Path, site: dict, api):
    """Returns dict(regn, signgu=[(code,name)], whole_region, scope, ldong=obj|None) exactly as the repo's tools do."""
    if family(repo) == "daegu":
        from pipeline.city import of as city_of
        from tools.tourapi_bulk import retry
        city = city_of(site)
        ldong = T.resolve_ldong(api, city, call=retry)
        return {"regn": ldong.regn_cd, "signgu": [list(x) for x in ldong.signgu], "whole_region": ldong.whole_region,
                "scope": T.list_scope(city), "locality_cd": getattr(ldong, "locality_cd", ""), "ldong": ldong,
                "city": city}
    from tools.tourapi_bulk import retry
    region_full = site.get("region_full") or "전북특별자치도 군산시"
    reg = site.get("region", "군산")
    regions = retry(api.ldong_code)
    regn = next(str(r["code"]) for r in regions if r.get("name") and r["name"] in region_full)
    signgu = next(str(r["code"]) for r in retry(api.ldong_code, regn)
                  if r.get("name") in (site.get("locality"), f"{reg}시", reg))
    return {"regn": regn, "signgu": [[signgu, site.get("locality") or reg]], "whole_region": False,
            "scope": "districts", "locality_cd": "", "ldong": None, "city": None}


def slim(it: dict, list_name: str = "") -> dict:
    keep = ("contentid", "contenttypeid", "title", "modifiedtime", "createdtime", "addr1", "addr2", "mapx", "mapy",
            "firstimage", "cpyrhtDivCd", "lDongRegnCd", "lDongSignguCd", "lclsSystm3", "tel", "eventstartdate",
            "eventenddate", "showflag", "ldong_signgu_cd", "ldong_signgu_name")
    out = {k: it.get(k) for k in keep if it.get(k) not in (None, "")}
    if list_name:
        out["_list"] = list_name
    return out


# ------------------------------------------------------------------ phases
def phase_lists(T, repo, sb, site, st):
    api = T.from_site_config(site, key(), sb / "data" / "cache" / "tourapi", max_calls=100000)
    r = region(T, repo, site, api)
    from tools import tourapi_bulk as TB
    out = {"date": TODAY, "regn": r["regn"], "signgu": r["signgu"], "whole_region": r["whole_region"],
           "scope": r["scope"], "locality_cd": r["locality_cd"], "items": [], "courses": [], "festivals": [],
           "complete": {}}
    try:
        if family(repo) == "daegu":
            items, info = TB.fetch_list(api, r["ldong"], r["scope"])
            out["list_info"] = info
        else:
            items = TB.fetch_region(api, r["regn"], r["signgu"][0][0])
        out["items"] = [slim(i) for i in items]
        out["complete"]["list"] = True
    except T.TourAPIError as err:
        out["complete"]["list"] = f"중단: {T.redact(str(err), api.service_key)[:200]}"
    try:  # 여행코스(25): tourapi_bulk --courses 와 같은 호출
        if family(repo) == "daegu":
            courses, _ = TB.fetch_list(api, r["ldong"], r["scope"], types=("25",))
        else:
            courses, page = [], 1
            while True:
                got = TB.retry(api.area_based, r["regn"], r["signgu"][0][0], "25", rows=200, page=page)
                courses += got
                if len(got) < 200:
                    break
                page += 1
        out["courses"] = [slim(i) for i in courses]
        out["complete"]["courses"] = True
    except T.TourAPIError as err:
        out["complete"]["courses"] = f"중단: {T.redact(str(err), api.service_key)[:200]}"
    try:  # 행사: 1월 1일부터(tools/tourapi_bulk.py --events 와 같은 호출)
        start = f"{TODAY[:4]}0101"
        if family(repo) == "daegu":
            fest = T.fetch_festivals(api, start, r["ldong"], call=TB.retry)
        else:
            fest, page, seen = [], 1, set()
            while True:   # 군산 엔진은 1쪽(100건)만 읽는다 — 1쪽은 같은 키, 넘치면 다음 쪽도 받아 둔다
                got = TB.retry(api.search_festival, start, r["regn"], r["signgu"][0][0], page=page)
                new = [g for g in got if str(g.get("contentid")) not in seen]
                seen.update(str(g.get("contentid")) for g in got)
                fest += new
                if len(got) < 100 or not new:
                    break
                page += 1
        out["festivals"] = [slim(i) for i in fest]
        out["complete"]["festivals"] = True
    except T.TourAPIError as err:
        out["complete"]["festivals"] = f"중단: {T.redact(str(err), api.service_key)[:200]}"
    (st / "lists.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), "utf-8")
    return {k: (len(out[k]) if isinstance(out[k], list) else out[k]) for k in ("items", "courses", "festivals", "complete")}


def phase_kdetail(T, repo, sb, site, st, plan_path: Path):
    """plan: [[cid, ctype, [ops...]], ...] ops ⊂ common, intro, info, image (ctype '15' for events)."""
    api = T.from_site_config(site, key(), sb / "data" / "cache" / "tourapi", max_calls=100000)
    from tools.tourapi_bulk import retry
    plan = json.loads(plan_path.read_text("utf-8"))
    done, failed, stopped = 0, 0, ""
    closed_ops = set()
    fns = {"common": lambda c, t: api.detail_common(c), "intro": lambda c, t: api.detail_intro(c, t),
           "info": lambda c, t: api.detail_info(c, t), "image": lambda c, t: api.detail_image(c)}
    opname = {"common": "detailCommon", "intro": "detailIntro", "info": "detailInfo", "image": "detailImage"}
    for cid, ctype, ops in plan:
        for op in ops:
            if op in closed_ops or (op in ("intro", "info") and not ctype):
                continue
            try:
                retry(fns[op], str(cid), str(ctype))
                done += 1
            except T.TourAPIQuotaError as err:
                closed_ops.add(op)
                stopped += f"{opname[op]}: {T.redact(str(err), api.service_key)[:160]}; "
            except T.TourAPIError:
                failed += 1
    return {"plan": len(plan), "answered": done, "failed": failed, "stopped": stopped}


def pages(api, op, rows, retry, **params):
    """tools/tourapi_harvest.py pages() 와 같은 쪽 넘김(짧은 쪽 또는 새 항목 없는 쪽에서 끝)."""
    out, seen, page = [], set(), 1
    while True:
        got = retry(api.call, op, numOfRows=rows, pageNo=page, **params)
        ids = [str(it.get("contentid") or it.get("galContentId") or it.get("contentId")
                   or json.dumps(it, sort_keys=True, ensure_ascii=False)) for it in got]
        new = [it for it, i in zip(got, ids) if i not in seen]
        seen.update(ids)
        out += new
        if len(got) < rows or not new:
            break
        page += 1
    return out


def harvest_client(T, site, svc: str, suffix: str, folder: str, sb: Path):
    return T.TourAPI(key(), base_url=B + svc, op_suffix=suffix,
                     mobile_app=(site.get("tourapi") or {}).get("mobile_app") or "TravelSite",
                     cache_dir=sb / "data" / "cache" / "tourapi" / folder, max_calls=100000)


def places_of(sb: Path):
    data, _ = load_site(sb)
    pl = json.loads((data / "places.json").read_text("utf-8"))
    return pl if isinstance(pl, list) else pl.get("places", [])


def provider_has(p: dict, word: str) -> bool:
    return word in json.dumps(p.get("fact_sources") or {}, ensure_ascii=False)


def phase_bf(T, repo, sb, site, st, regn: str):
    from tools.tourapi_bulk import retry
    lst = harvest_client(T, site, "KorWithService2", "2", "barrier_free", sb)
    res = {"list": [], "detail": {}, "stopped": ""}
    try:
        items = pages(lst, "areaBasedList", 200, retry, lDongRegnCd=regn, arrange="A")
        res["list"] = [slim(i) for i in items]
    except T.TourAPIError as err:
        res["stopped"] = f"list: {T.redact(str(err), lst.service_key)[:200]}"
        (st / "bf.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
        return {"list": 0, "stopped": res["stopped"]}
    bf_ids = {str(i["contentid"]) for i in items}
    places = places_of(sb)
    want = [p for p in places if p.get("status") == "published" and not p.get("duplicate_of")
            and str((p.get("tourapi") or {}).get("contentid") or "") in bf_ids
            and not provider_has(p, "무장애 여행 정보")]
    api = T.barrier_free_client(site, key(), sb / "data" / "cache" / "tourapi", max_calls=100000)
    for p in want:
        cid = str(p["tourapi"]["contentid"])
        try:
            with_ = retry(api.detail_with_tour, cid)
            vals = {k: v for k, v in (with_ or {}).items() if k not in ("contentid", "contenttypeid") and str(v or "").strip()}
            title = ""
            if vals:
                title = (retry(api.detail_common, cid) or {}).get("title", "")
            res["detail"][cid] = {"name": p.get("name"), "fields_with_value": sorted(vals), "bf_title": title}
        except T.TourAPIQuotaError as err:
            res["stopped"] = f"detail: {T.redact(str(err), api.service_key)[:200]}"
            break
        except T.TourAPIError as err:
            res["detail"][cid] = {"name": p.get("name"), "error": T.redact(str(err), api.service_key)[:160]}
    res["matched_lacking"] = len(want)
    (st / "bf.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
    return {"list": len(items), "matched_lacking": len(want), "fetched": len(res["detail"]), "stopped": res["stopped"]}


def phase_pet(T, repo, sb, site, st, regn: str):
    from tools.tourapi_bulk import retry
    api = harvest_client(T, site, "KorPetTourService2", "2", "korpettourservice2", sb)
    res = {"list": [], "detail": {}, "stopped": ""}
    try:
        items = pages(api, "areaBasedList", 200, retry, lDongRegnCd=regn, arrange="A")
        res["list"] = [slim(i) for i in items]
    except T.TourAPIError as err:
        res["stopped"] = f"list: {T.redact(str(err), api.service_key)[:200]}"
        (st / "pet.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
        return {"list": 0, "stopped": res["stopped"]}
    pet_ids = {str(i["contentid"]) for i in items}
    places = places_of(sb)
    want = [p for p in places if p.get("status") == "published" and not p.get("duplicate_of")
            and str((p.get("tourapi") or {}).get("contentid") or "") in pet_ids
            and not provider_has(p, "반려동물 동반여행")]
    for p in want:
        cid = str(p["tourapi"]["contentid"])
        try:
            got = retry(api.call, "detailPetTour", contentId=cid)
            it = got[0] if got else {}
            res["detail"][cid] = {"name": p.get("name"),
                                  "fields_with_value": sorted(k for k, v in it.items() if k != "contentid" and str(v or "").strip())}
        except T.TourAPIQuotaError as err:
            res["stopped"] = f"detail: {T.redact(str(err), api.service_key)[:200]}"
            break
        except T.TourAPIError as err:
            res["detail"][cid] = {"name": p.get("name"), "error": T.redact(str(err), api.service_key)[:160]}
    res["matched_lacking"] = len(want)
    (st / "pet.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
    return {"list": len(items), "matched_lacking": len(want), "fetched": len(res["detail"]), "stopped": res["stopped"]}


def phase_lang(T, repo, sb, site, st, new_items: list[dict]):
    """8개 언어 서비스 목록: 그 저장소 tools/en_content.py names 가 읽는 호출 그대로. 새 항목의 공식 이름은
    그 저장소 match_en(좌표 150m·유형·이름 근거) 규칙으로만 찾는다(보고용)."""
    import tools.en_content as EC
    from pipeline import locales as LC
    from tools.tourapi_bulk import retry
    from pipeline.tourapi import KIND_BY_TYPE
    data, _ = load_site(sb)
    res = {}
    for code in LANGS:
        loc = LC.get(code)
        service = loc.service
        stats: dict = {}
        items: list[dict] = []
        if hasattr(EC, "service_items"):
            items = EC.service_items(data, service, 100000, False, stats)
        else:  # 군산 엔진: names()/names_l() 안의 호출을 그대로(캐시 폴더는 캐시 뿌리, base_url이 서비스)
            try:
                kor = T.from_site_config(site, key(), data.parent / "cache" / "tourapi", max_calls=10)
                r = region(T, repo, site, kor)
                base = EC.EN_BASE_URL if code == "en" else f"https://apis.data.go.kr/B551011/{service}"
                api = T.TourAPI(key(), base_url=base, mobile_app=(site.get("tourapi") or {}).get("mobile_app", "WebforAI"),
                                cache_dir=data.parent / "cache" / "tourapi", max_calls=100000)
                page = 1
                while True:
                    got = retry(api.call, "areaBasedList", lDongRegnCd=r["regn"], lDongSignguCd=r["signgu"][0][0],
                                numOfRows=200, pageNo=page, arrange="A")
                    items += got
                    if len(got) < 200:
                        break
                    page += 1
            except (T.TourAPIError, StopIteration) as err:
                stats["error"] = str(err)
        # 새 항목(국문 목록에만 있고 places.json에 없는 장소)의 공식 이름
        latin = not (loc.cjk or code == "ru")
        found = {}
        for it in new_items:
            ctype = str(it.get("contenttypeid") or "")
            kind = KIND_BY_TYPE.get(ctype)
            if not kind or not it.get("mapx"):
                continue
            pseudo = {"name": it.get("title"), "kind": kind, "alternate_names": [],
                      "geo": {"lat": float(it["mapy"]), "lng": float(it["mapx"])},
                      "tourapi": {"contenttypeid": ctype, "title": it.get("title")}, "images": []}
            try:
                m, dist, basis = EC.match_en(pseudo, items, latin=latin) if items else (None, None, "")
            except Exception as err:  # noqa: BLE001 — 보고용, 한 항목 오류로 멈추지 않음
                m, dist, basis = None, None, f"error {type(err).__name__}"
            if m:
                found[str(it["contentid"])] = {"title_ko": it.get("title"), "title": m.get("title"),
                                               "lang_contentid": str(m.get("contentid", "")),
                                               "match_m": round(dist, 1), "basis": basis}
        res[code] = {"service": service, "list_items": len(items), "error": stats.get("error", ""),
                     "new_item_names": found}
    (st / "lang.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
    return {c: (v["list_items"], len(v["new_item_names"]), v["error"][:60]) for c, v in res.items()}


def phase_camp(T, repo, sb, site, st):
    from tools.tourapi_bulk import retry
    api = harvest_client(T, site, "GoCamping", "", "gocamping", sb)
    try:
        camps = pages(api, "basedList", 100, retry)
        stopped = ""
    except T.TourAPIError as err:
        camps, stopped = [], T.redact(str(err), api.service_key)[:200]
    (st / "camp_raw_count.json").write_text(json.dumps({"camps": len(camps), "stopped": stopped}), "utf-8")
    return {"camps": len(camps), "stopped": stopped}


def phase_photo(T, repo, sb, site, st):
    from tools.tourapi_bulk import retry
    api = harvest_client(T, site, "PhotoGalleryService1", "1", "photo_gallery", sb)
    words = [site.get("region")] + [d for d in (site.get("districts") or []) if d.endswith(("군", "시"))]
    words += [d[:-1] for d in (site.get("districts") or []) if d.endswith(("군", "시"))]
    res, seen, stopped = {}, set(), ""
    for w in dict.fromkeys(x for x in words if x):
        try:
            got = pages(api, "gallerySearchList", 100, retry, keyword=w, arrange="A")
        except T.TourAPIError as err:
            stopped = T.redact(str(err), api.service_key)[:200]
            break
        res[w] = len(got)
        seen.update(str(g.get("galContentId")) for g in got)
    (st / "photo.json").write_text(json.dumps({"keywords": res, "photos": len(seen), "stopped": stopped},
                                              ensure_ascii=False, indent=1), "utf-8")
    return {"keywords": res, "photos": len(seen), "stopped": stopped}


def phase_gonecheck(T, repo, sb, site, st):
    """사라진 항목(diff.json gone)마다 detailCommon2 한 번 — 응답은 사이트 캐시가 아닌 gone_check/ 에 둔다
    (사이트 캐시에 넣으면 --details 가 그 장소 overview를 비운다). 빈 응답 = 공급자에서 지워짐."""
    from tools.tourapi_bulk import retry
    diff = json.loads((st / "diff.json").read_text("utf-8"))
    api = T.from_site_config(site, key(), WORK / "gone_check" / "tourapi", max_calls=100000)
    out = {}
    for t, rows in diff.get("gone", {}).items():
        for r in rows:
            cid = r["contentid"]
            try:
                c = retry(api.detail_common, cid)
                out[cid] = {"names": r["names"], "status": r["status"], "detailCommon": "빈 응답(지워짐)" if not c else "있음",
                            "title": c.get("title", ""), "addr1": c.get("addr1", ""), "lDongSignguCd": c.get("lDongSignguCd", ""),
                            "modifiedtime": c.get("modifiedtime", "")}
            except T.TourAPIQuotaError as err:
                out["_stopped"] = T.redact(str(err), api.service_key)[:200]
                break
            except T.TourAPIError as err:
                out[cid] = {"names": r["names"], "error": T.redact(str(err), api.service_key)[:160]}
    (st / "gone_check.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), "utf-8")
    return {"checked": len(out), "deleted": sum(1 for v in out.values() if isinstance(v, dict) and v.get("detailCommon", "").startswith("빈"))}


def phase_langdetail(T, repo, sb, site, st):
    """새 항목과 짝지은 외국어 서비스 항목의 상세(detailCommon2·detailIntro2·detailInfo2·detailImage2) — 대구 계열
    tools/tourapi_harvest.py harvest_lang 과 같은 클라이언트·폴더(<service 소문자>/)·인자."""
    from tools.tourapi_bulk import retry
    from pipeline import locales as LC
    lang = json.loads((st / "lang.json").read_text("utf-8"))
    done, out = 0, {}
    for code, v in lang.items():
        if not v.get("new_item_names"):
            continue
        svc = LC.get(code).service
        api = harvest_client(T, site, svc, "2", svc.lower(), sb)
        items = {}
        for f in (CACHE / svc.lower()).glob("areaBasedList-*.json"):
            try:
                it = json.loads(f.read_text("utf-8"))["response"]["body"]["items"]
                it = it.get("item", []) if isinstance(it, dict) else []
                for i in (it if isinstance(it, list) else [it]):
                    items[str(i.get("contentid"))] = i
            except (ValueError, KeyError, TypeError):
                pass
        for kor_cid, m in v["new_item_names"].items():
            cid = m["lang_contentid"]
            ctype = str((items.get(cid) or {}).get("contenttypeid") or "")
            calls = [("detailCommon", {"contentId": cid})]
            if ctype:
                calls += [("detailIntro", {"contentId": cid, "contentTypeId": ctype}),
                          ("detailInfo", {"contentId": cid, "contentTypeId": ctype})]
            calls.append(("detailImage", {"contentId": cid, "imageYN": "Y", "numOfRows": 20, "pageNo": 1}))
            for op, params in calls:
                try:
                    retry(api.call, op, **params)
                    done += 1
                except T.TourAPIError as err:
                    out.setdefault("errors", []).append(f"{svc}.{op} {cid}: {T.redact(str(err), api.service_key)[:120]}")
    return {"answered": done, **out}


def phase_bffill(T, repo, sb, site, st, part: int, nparts: int):
    """무장애 목록에 있는 공개 장소인데 옛 묶음·이번 캐시에 detailWithTour2가 없는 곳(사이트에 이미 무장애 사실이
    있어도) — tools/tourapi_bulk.py --barrier-free 오프라인 실행이 빠짐없이 돌도록. 값이 있으면 같은 서비스 detailCommon2."""
    import hashlib
    from tools.tourapi_bulk import retry
    old = set(json.loads((st / "oldindex.json").read_text("utf-8"))["files"])
    ids = {str(i["contentid"]) for i in json.loads((st / "bf.json").read_text("utf-8"))["list"]}
    api = T.barrier_free_client(site, key(), sb / "data" / "cache" / "tourapi", max_calls=100000)
    want = []
    for p in places_of(sb):
        cid = str((p.get("tourapi") or {}).get("contentid") or "")
        if p.get("status") != "published" or p.get("duplicate_of") or cid not in ids:
            continue
        name = api._cache_path("detailWithTour", {"contentId": cid}).name
        if f"barrier_free/{name}" in old or api._cache_path("detailWithTour", {"contentId": cid}).exists():
            continue
        want.append(cid)
    want = [c for c in sorted(set(want)) if int(c) % nparts == part]   # contentid로 나눔(조각마다 시작 시점이 달라도 겹치거나 빠지지 않게)
    got, with_vals, stopped = 0, 0, ""
    for cid in want:
        try:
            w = retry(api.detail_with_tour, cid)
            got += 1
            if any(str(v or "").strip() for k, v in (w or {}).items() if k not in ("contentid", "contenttypeid")):
                with_vals += 1
                retry(api.detail_common, cid)
        except T.TourAPIQuotaError as err:
            stopped = T.redact(str(err), api.service_key)[:200]
            break
        except T.TourAPIError:
            pass
    return {"todo": len(want), "answered": got, "with_values": with_vals, "stopped": stopped}


def phase_durunubi(T, repo, sb, site, st):
    """두루누비 courseList·routeList 전국 목록(tools/tourapi_harvest.py harvest_durunubi 와 같은 클라이언트·폴더·쪽 넘김)."""
    from tools.tourapi_bulk import retry
    api = harvest_client(T, site, "Durunubi", "", "durunubi", sb)
    out = {}
    for op in ("courseList", "routeList"):
        try:
            out[op] = len(pages(api, op, 100, retry))
        except T.TourAPIError as err:
            out[op] = f"중단: {T.redact(str(err), api.service_key)[:200]}"
    return out


def phase_photo2(T, repo, sb, site, st):
    """관광사진 갤러리를 그 저장소 tools/tourapi_harvest.py harvest_photo 그대로(키워드 규칙이 저장소마다 다르다)."""
    import tools.tourapi_harvest as TH
    from pipeline.city import of as city_of
    h = TH.Harvest(site, key(), sb / "data" / "cache" / "tourapi", 100000, 1)
    try:
        res = TH.harvest_photo(h, city_of(site))
    finally:
        h.pool.shutdown()
    res["closed"] = {f"{a}.{b}": v for (a, b), v in h.closed.items()}
    res["errors"] = {f"{a}.{b}": v[:3] for (a, b), v in h.errors.items()}
    (st / "photo.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
    return res


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--slug", required=True)
    ap.add_argument("--repo", required=True, type=Path)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--plan", type=Path)
    ap.add_argument("--regn", default="")
    ap.add_argument("--tag", default="")
    a = ap.parse_args()
    sb = WORK / "sandbox" / a.slug
    st = STATE / a.slug
    st.mkdir(parents=True, exist_ok=True)
    os.chdir(sb)
    T = setup(a.repo)
    data, site = load_site(sb)
    t0 = time.time()
    try:
        if a.phase == "lists":
            res = phase_lists(T, a.repo, sb, site, st)
        elif a.phase == "kdetail":
            res = phase_kdetail(T, a.repo, sb, site, st, a.plan)
        elif a.phase == "bf":
            res = phase_bf(T, a.repo, sb, site, st, a.regn)
        elif a.phase == "pet":
            res = phase_pet(T, a.repo, sb, site, st, a.regn)
        elif a.phase == "lang":
            new_items = json.loads((st / "new_items.json").read_text("utf-8")) if (st / "new_items.json").exists() else []
            res = phase_lang(T, a.repo, sb, site, st, new_items)
        elif a.phase == "camp":
            res = phase_camp(T, a.repo, sb, site, st)
        elif a.phase == "photo2":
            res = phase_photo2(T, a.repo, sb, site, st)
        elif a.phase == "durunubi":
            res = phase_durunubi(T, a.repo, sb, site, st)
        elif a.phase == "bffill":
            pi, pn = (int(x) for x in (a.tag.split("of") if "of" in a.tag else ("0", "1")))
            res = phase_bffill(T, a.repo, sb, site, st, pi, pn)
        elif a.phase == "langdetail":
            res = phase_langdetail(T, a.repo, sb, site, st)
        elif a.phase == "gonecheck":
            res = phase_gonecheck(T, a.repo, sb, site, st)
        elif a.phase == "photo":
            res = phase_photo(T, a.repo, sb, site, st)
        else:
            raise SystemExit(f"unknown phase {a.phase}")
    except Exception as err:  # noqa: BLE001
        k = os.environ.get("TOURAPI_KEY", "")
        msg = T.redact(f"{type(err).__name__}: {err}\n{traceback.format_exc()[-1500:]}", k)
        res = {"crash": msg}
    tag = a.phase + (f"_{a.tag}" if a.tag else "")
    with open(st / f"touched_{tag}.txt", "a", encoding="utf-8") as fh:
        for t in sorted(TOUCHED):
            fh.write(t + "\n")
    if ERRORS:
        with open(st / "errors.txt", "a", encoding="utf-8") as fh:
            for e in ERRORS:
                fh.write(f"[{time.strftime('%H:%M:%S')}] {tag} {e}\n")
    print(json.dumps({"slug": a.slug, "phase": tag, "sec": round(time.time() - t0), "result": res,
                      "touched": len(TOUCHED), "errors": len(ERRORS)}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
