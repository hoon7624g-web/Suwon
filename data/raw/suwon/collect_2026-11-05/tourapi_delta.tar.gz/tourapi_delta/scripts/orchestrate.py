#!/usr/bin/env python3
"""TourAPI 변경분 수집 — 20개 사이트를 단계별로 돌린다(사이트마다 driver.py 하위 프로세스).

    python orchestrate.py setup                       # sandbox/<slug>/data/<city>/ 에 site·places·events 사본, cache 링크
    python orchestrate.py run lists [--sites a,b] [--jobs 4]
    python orchestrate.py diff                        # state/<slug>/lists.json + 저장소 places/events -> 차이·계획
    python orchestrate.py run kdetail --level events|new|changed_pub|rest
    python orchestrate.py run bf|pet|lang|photo
    python orchestrate.py camp                        # 고캠핑(전국 목록 한 벌) + 사이트별 보고
    python orchestrate.py export                      # out/<slug>/ diff.json·README.md·cache/tourapi/...

키는 TOURAPI_KEY 환경 변수(같은 명령 안에서 넣는다)로만 하위 프로세스에 넘긴다. 저장소는 읽기만 한다.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
CACHE = WORK / "cache" / "tourapi"
SB = WORK / "sandbox"
OUT = WORK / "out"
DRIVER = WORK / "scripts" / "driver.py"

SITES = {  # slug: (repo, data dir name)
    "gunsan": ("/home/user/gunsan", "gunsan"), "daegu": ("/home/user/Daegu", "daegu"),
    "haenam": ("/home/user/haenam", "haenam"), "sejong": ("/home/user/sejong", "sejong"),
    "yeongju": ("/home/user/yeougju", "yeongju"), "gangneung": ("/home/user/gangneung", "gangneung"),
    "jeju": ("/home/user/jeju", "jeju"), "yeosu": ("/home/user/yeosu", "yeosu"),
    "jeonju": ("/home/user/jeonju", "jeonju"), "chuncheon": ("/home/user/chuncheon", "chuncheon"),
    "yongin": ("/home/user/yongin", "yongin"), "gyeongju": ("/home/user/gyeongju", "gyeongju"),
    "busan": ("/home/user/busan", "busan"), "suwon": ("/home/user/hoon7624g-web/suwon", "suwon"),
    "sokcho": ("/home/user/sokcho", "sokcho"), "danyang": ("/home/user/danyang", "danyang"),
    "mokpo": ("/home/user/mokpo", "mokpo"), "incheon": ("/home/user/incheon", "incheon"),
    "gapyeong": ("/home/user/gapyeong", "gapyeong"), "jongno": ("/home/user/jongno", "jongno"),
}
COPY = ("site.json", "places.json", "events.json", "tourapi_courses.json", "tourapi_overrides.json")


def setup() -> None:
    for slug, (repo, city) in SITES.items():
        d = SB / slug / "data" / city
        d.mkdir(parents=True, exist_ok=True)
        for f in COPY:
            src = Path(repo) / "data" / city / f
            if src.exists():
                shutil.copy2(src, d / f)
        link = SB / slug / "data" / "cache"
        if not link.exists():
            link.symlink_to(WORK / "cache")
        (STATE / slug).mkdir(parents=True, exist_ok=True)
    print("sandbox ready:", len(SITES))


def run_one(slug: str, phase: str, extra: list[str]) -> str:
    repo = SITES[slug][0]
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    cmd = [sys.executable, str(DRIVER), "--slug", slug, "--repo", repo, "--phase", phase, *extra]
    p = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=7200)
    out = (p.stdout.strip().splitlines() or [""])[-1]
    if p.returncode or not out.startswith("{"):
        out = f'{{"slug": "{slug}", "phase": "{phase}", "rc": {p.returncode}, "stderr": {json.dumps(p.stderr[-800:])}}}'
    with open(STATE / "runs.log", "a", encoding="utf-8") as fh:
        fh.write(out + "\n")
    return out


def run(phase: str, sites: list[str], jobs: int, extra_by_site=None) -> None:
    extra_by_site = extra_by_site or {}
    todo = [s for s in sites if s in extra_by_site or not extra_by_site]
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        for res in ex.map(lambda s: run_one(s, phase, extra_by_site.get(s, [])), todo):
            print(res[:600], flush=True)


if __name__ == "__main__":
    args = sys.argv[1:]
    cmd = args[0]
    sites = list(SITES)
    jobs = 4
    level = ""
    if "--sites" in args:
        sites = args[args.index("--sites") + 1].split(",")
    if "--jobs" in args:
        jobs = int(args[args.index("--jobs") + 1])
    if "--level" in args:
        level = args[args.index("--level") + 1]
    if cmd == "setup":
        setup()
    elif cmd == "run":
        phase = args[1]
        extra = {}
        if phase == "kdetail":
            for s in sites:
                plan = STATE / s / f"plan_{level}.json"
                if plan.exists() and json.loads(plan.read_text("utf-8")):
                    extra[s] = ["--plan", str(plan), "--tag", level]
            if not extra:
                print("no plans for", level)
                sys.exit(0)
        elif phase in ("bf", "pet"):
            for s in sites:
                lst = json.loads((STATE / s / "lists.json").read_text("utf-8"))
                extra[s] = ["--regn", lst["regn"]]
        run(phase, sites, jobs, extra)
    else:
        raise SystemExit(f"unknown command {cmd}")
