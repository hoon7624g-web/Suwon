#!/usr/bin/env python3
"""계획(state/<slug>/plan_<level>.json) 가운데 아직 캐시에 없는 상세 호출 수(사이트·단계·오퍼레이션별). 호출 없음.
결과: state/remaining.json, 표준 출력에 요약."""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from diffplan import cache_name, op_params  # noqa: E402

WORK = Path("/home/user/work/tourapi_delta")
STATE = WORK / "state"
CACHE = WORK / "cache" / "tourapi"
LEVELS = ("events", "new", "changed_pub", "rest_pub", "rest_draft", "rest_misc")
OPN = {"common": "detailCommon", "intro": "detailIntro", "info": "detailInfo", "image": "detailImage"}


def main() -> None:
    out, tot = {}, Counter()
    for st in sorted(STATE.iterdir()):
        if not st.is_dir():
            continue
        row = {}
        for lv in LEVELS:
            p = st / f"plan_{lv}.json"
            if not p.exists():
                continue
            c = Counter()
            for cid, ctype, ops in json.loads(p.read_text("utf-8")):
                for op in ops:
                    if not (CACHE / cache_name(*op_params(op, str(cid), str(ctype)))).exists():
                        c[OPN[op]] += 1
            if c:
                row[lv] = dict(c)
                for k, v in c.items():
                    tot[(lv, k)] += v
        if row:
            out[st.name] = row
    (STATE / "remaining.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), "utf-8")
    for s, r in out.items():
        print(s, json.dumps(r, ensure_ascii=False))
    print("total", {f"{a}.{b}": n for (a, b), n in sorted(tot.items())})


if __name__ == "__main__":
    main()
