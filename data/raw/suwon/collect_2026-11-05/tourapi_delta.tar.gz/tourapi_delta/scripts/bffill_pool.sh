#!/bin/bash
# 무장애 상세 채우기: (사이트 조각) 4개씩. 키는 호출하는 쪽이 TOURAPI_KEY로 넣는다.
W=/home/user/work/tourapi_delta
run() { DELTA_CAP=100000 PYTHONDONTWRITEBYTECODE=1 python3 $W/scripts/driver.py --slug $1 --repo $2 --phase bffill --tag ${3}of${4} >> $W/state/run_bffill.log 2>&1; }
export -f run; export W
printf "%s\n" "gangneung /home/user/gangneung 0 3" "gangneung /home/user/gangneung 1 3" "gangneung /home/user/gangneung 2 3" \
  "jeju /home/user/jeju 0 2" "jeju /home/user/jeju 1 2" "gunsan /home/user/gunsan 0 1" "sejong /home/user/sejong 0 1" \
  | xargs -P 4 -L 1 bash -c 'run "$@"' _
