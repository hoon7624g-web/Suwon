#!/usr/bin/env python3
"""사이트 저장소의 data/cache/tourapi/ 를 '옛 원응답 묶음 + 이번 변경분'으로 채운다(호출 0회). 기본은 미리보기.

    python /home/user/work/tourapi_delta/scripts/apply_delta.py --repo /home/user/busan --city busan --slug busan          # 미리보기
    python /home/user/work/tourapi_delta/scripts/apply_delta.py --repo /home/user/busan --city busan --slug busan --apply  # 쓰기

1. 옛 묶음: <repo>/data/raw/<city>/tourapi_recollect/*.tar.gz 먼저, 그다음 tourapi/*.tar.gz — 캐시에 이미 있는 파일은 두고,
   파일 날짜(받은 날 = checked_at)는 묶음 안의 날짜 그대로. 저장소에 data/raw가 없으면(희소 체크아웃)
   `git sparse-checkout add /data/raw/` 로 먼저 꺼내거나, --oldraw 로 /home/user/work/tourapi_delta/oldraw/<slug>/
   (KorService2·무장애·반려동물·고캠핑·관광사진 묶음만 있음, 외국어 묶음 없음)를 쓴다.
2. 변경분: /home/user/work/tourapi_delta/out/<slug>/cache/tourapi/ 와 out/_shared/cache/tourapi/ 를 덮어쓰기 복사(날짜 유지).
   같은 이름이면 새 응답이 이긴다(목록·행사 목록·바뀐 장소의 상세).
캐시(data/cache/)는 커밋하지 않는다. 이 스크립트는 장소·행사 데이터를 건드리지 않는다.
"""
from __future__ import annotations

import argparse
import os
import shutil
import tarfile
from pathlib import Path

WORK = Path("/home/user/work/tourapi_delta")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--city", required=True)
    ap.add_argument("--slug", required=True)
    ap.add_argument("--oldraw", action="store_true", help="저장소 data/raw 대신 작업 폴더 oldraw/<slug> 사용")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    cache = a.repo / "data" / "cache" / "tourapi"
    raw = (WORK / "oldraw" / a.slug) if a.oldraw else (a.repo / "data" / "raw" / a.city)
    if not raw.exists():
        print(f"옛 묶음 폴더 없음: {raw} — 저장소에서 `git sparse-checkout add /data/raw/` 하거나 --oldraw")
        return 2
    restored = kept = 0
    names: set[str] = set()
    for variant in ("tourapi_recollect", "tourapi"):
        for arc in sorted((raw / variant).glob("*.tar.gz")) if (raw / variant).exists() else []:
            with tarfile.open(arc, "r:gz") as tar:
                for m in tar.getmembers():
                    if not m.isfile() or not m.name.endswith(".json") or ".." in m.name or m.name.startswith("/"):
                        continue
                    target = cache / m.name
                    if target.exists():
                        kept += 1
                        continue
                    restored += 1
                    names.add(m.name)
                    if a.apply:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with tar.extractfile(m) as fh:
                            target.write_bytes(fh.read())
                        os.utime(target, (m.mtime, m.mtime))
    copied = replaced = 0
    for src_root in (WORK / "out" / a.slug / "cache" / "tourapi", WORK / "out" / "_shared" / "cache" / "tourapi"):
        for f in sorted(src_root.rglob("*.json")):
            target = cache / f.relative_to(src_root)
            replaced += target.exists() or str(f.relative_to(src_root)) in names
            copied += 1
            if a.apply:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, target)
    mode = "썼다" if a.apply else "미리보기(--apply로 쓴다)"
    print(f"{mode}: 옛 묶음에서 {restored}개 복원(이미 있던 {kept}개 유지), 변경분 {copied}개 복사(그중 {replaced}개 덮어씀) → {cache}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
