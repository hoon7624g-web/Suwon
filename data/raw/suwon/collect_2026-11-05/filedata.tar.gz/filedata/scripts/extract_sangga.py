"""Stream the 상가(상권)정보 zip once: rows within EXTRACT_M of each site's linked market places → out/<slug>/raw/markets/."""
import csv, io, json, math, sys, zipfile, collections
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, data_dir
from pathlib import Path
EXTRACT_M = 400
ZIP = Path("/home/user/work/filedata/downloads/markets/sangga_15083033.zip")
SIDO_FILE = {"daegu": "대구", "haenam": "전남광주", "sejong": "세종", "yeongju": "경북", "gangneung": "강원", "jeju": "제주",
             "yeosu": "전남광주", "jeonju": "전북", "chuncheon": "강원", "yongin": "경기", "gyeongju": "경북", "busan": "부산",
             "suwon": "경기", "sokcho": "강원", "danyang": "충북", "mokpo": "전남광주", "incheon": "인천", "gapyeong": "경기",
             "jongno": "서울"}

def metres(a, b):
    k = math.pi / 180
    x = (b[1] - a[1]) * k * math.cos((a[0] + b[0]) / 2 * k)
    return 6371000 * math.hypot(x, (b[0] - a[0]) * k)

points = collections.defaultdict(list)   # sido -> [(slug, (lat,lng))]
for slug in SITES:
    f = ROOT / "out" / slug / "raw" / "markets" / "market_links.json"
    links = json.loads(f.read_text("utf-8"))["links"] if f.is_file() else []
    places = {p["id"]: p for p in json.loads((data_dir(slug) / "places.json").read_text("utf-8"))}
    for r in links:
        g = places[r["id"]]["geo"]
        points[SIDO_FILE[slug]].append((slug, (float(g["lat"]), float(g["lng"]))))
z = zipfile.ZipFile(ZIP)
names = {}
for n in z.infolist():
    nm = n.filename if n.flag_bits & 0x800 else n.filename.encode("cp437").decode("cp949", "replace")
    names[nm] = n
out = collections.defaultdict(list)
header = None
for sido, pts in points.items():
    fn = next(k for k in names if k.endswith(f"_{sido}_202609.csv"))
    with z.open(names[fn]) as fh:
        rd = csv.DictReader(io.TextIOWrapper(fh, encoding="utf-8-sig", newline=""))
        header = rd.fieldnames
        n = 0
        for r in rd:
            n += 1
            try:
                ll = (float(r["위도"]), float(r["경도"]))
            except (KeyError, ValueError):
                continue
            for slug in {s for s, p in pts if abs(p[0] - ll[0]) < 0.006 and abs(p[1] - ll[1]) < 0.007 and metres(p, ll) <= EXTRACT_M}:
                out[slug].append(r)
    print(sido, fn, "rows", n, {s: len(out[s]) for s in {s for s, _ in pts}})
for slug, rows in out.items():
    d = ROOT / "out" / slug / "raw" / "markets"
    with open(d / f"sangga_{slug}_markets_202609.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header)
        w.writeheader()
        w.writerows(rows)
print("header", header)
