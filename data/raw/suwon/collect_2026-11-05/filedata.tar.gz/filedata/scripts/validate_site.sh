#!/bin/bash
# build + validate a temp copy from the repo directory (the repo is only read)
slug=$1; repo=$2; v=/home/user/work/filedata/validate/$slug
cd "$repo" || exit 1
( time python3 -m pipeline.build --data $v/data/$slug --out $v/out --mode preview ) > $v/build.log 2>&1
echo "build exit $?" >> $v/build.log
( time python3 -m pipeline.validate --data $v/data/$slug --out $v/out --mode preview ) > $v/validate.log 2>&1
echo "validate exit $?" >> $v/validate.log
