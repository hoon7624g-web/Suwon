"""Designation candidates (백년가게·착한가격업소·향토음식점·모범음식점 …) and 식품안심업소(위생등급) matches per site.

Matching is Daegu's tools/import_designations_daegu.py (imported read-only; its high-confidence rule: name + road+number,
name + local phone, (name-suffix|branch) + address, any name relation + address + phone; a row with high matches to two
places goes to neither). Rows are filtered to the site first (address in the site, or the list's 시군 column).
Existing designations are kept; a new one is added only when the place has no designation of that type yet.

Output per site: out/<slug>/patch_designations.json {place_id: {"designations": [...]}},
out/<slug>/patch_hygiene.json {place_id: {"hygiene": {...}}}, raw/designations/*.csv + sources.json, a summary json.
"""
from __future__ import annotations
import csv, io, json, re, sys, importlib.util, collections
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, data_dir, in_region, CITY_LABEL
import stdfiles

sys.path.insert(0, "/home/user/Daegu")
spec = importlib.util.spec_from_file_location("imd", "/home/user/Daegu/tools/import_designations_daegu.py")
imd = importlib.util.module_from_spec(spec)
sys.modules["imd"] = imd
spec.loader.exec_module(imd)

D = Path("/home/user/work/filedata/downloads/designations")
TODAY = "2026-11-05"
FOOD = ["한식", "기타요식업", "중식", "일식", "양식", "베이커리"]


def rows_of(pk):
    return list(csv.DictReader(io.StringIO(stdfiles.decode((D / f"{pk}.bin").read_bytes()))))


def meta(pk):
    return json.loads((D / f"{pk}.json").read_text("utf-8"))


def base_date(pk):
    m = re.search(r"_(\d{8})$", meta(pk)["name"])
    return f"{m.group(1)[:4]}-{m.group(1)[4:6]}-{m.group(1)[6:]}" if m else meta(pk)["modified"]


def clean_title(title: str, provider: str) -> str:
    """The portal title without the provider's words in front ('부산광역시_서구_모범음식점 현황' → '모범음식점 현황')."""
    words = set(provider.replace("_", " ").split()) | {provider.replace(" ", "")}
    t = title.replace("_", " ").split()
    while len(t) > 1 and (t[0] in words or t[0].replace(" ", "") in words):
        t = t[1:]
    return " ".join(t)


def L(key, pk, type_, label, cols, *, keep=None, kinds=None, place_kinds=("food",), row_kind=None, year="base",
      use="write", hygiene=None, addr_fix=None):
    m = meta(pk)
    bd = base_date(pk)
    title = re.sub(r"_\d{8}$", "", m["name"])
    prov = m["provider"]
    src = {"key": key, "pk": pk, "use": use, "type": type_, "label": label,
           "source_name": f"{prov} · 공공데이터포털 {clean_title(title, prov)}({bd})",
           "url": f"https://www.data.go.kr/data/{pk}/fileData.do", "dataset_id": pk, "base_date": bd,
           "dataset": m["name"], "provider": prov, "license": m["license"], "modified": m["modified"],
           "columns": cols, "place_kinds": list(place_kinds)}
    if year != "base":
        src["year"] = year
    if kinds:
        src["kinds"] = kinds
    if row_kind:
        src["row_kind"] = row_kind
    if hygiene:
        src["hygiene"] = hygiene
    src["_keep"] = keep
    src["_addr_fix"] = addr_fix
    return src


def lists_for(slug):
    city = CITY_LABEL[slug]
    out = [
        L("baeknyeon", "15132695", "baeknyeon", "백년가게(중소벤처기업부)", {"name": "업체명", "address": "업체주소", "phone": "연락처"},
          keep=lambda r: in_region(slug, r["업체주소"]), place_kinds=("food", "stay", "attraction"), row_kind="any", year=None),
        L("goodprice_mois", "3045247", "goodprice", f"착한가격업소({city})", {"name": "업소명", "address": "주소"},
          keep=lambda r: in_region(slug, r["주소"]), kinds={"col": "업종", "food": FOOD, "stay": ["숙박업"]},
          place_kinds=("food", "stay")),
    ]
    if slug == "jeonju":
        out.append(L("hyangto_jeonbuk_2024", "15175190", "hyangto", "향토음식점(전북, 2024)",
                     {"name": "업소명", "address": "도로명주소"}, keep=lambda r: r["시군명"].strip() == "전주시", year=2024))
        out.append(L("mobeom_jeonju", "3079790", "mobeom", "모범음식점(전주시 지정)",
                     {"name": "업소명", "address": "도로명주소", "phone": "전화번호"},
                     keep=lambda r: r.get("영업상태명", "").strip() in ("", "영업", "영업/정상")))
    if slug == "jeju":
        out.append(L("hyangto_jeju_2024", "15043695", "hyangto", "향토음식점(제주, 2024)",
                     {"name": "업소명", "address": "소재지", "phone": "연락처"}, year=2024))
        out.append(L("mobeom_jeju", "15043694", "mobeom", "모범음식점(제주특별자치도 지정)",
                     {"name": "업소명", "address": "소재지(도로명)"}))
        out.append(L("hygiene_seogwipo", "15055970", "hygiene", "식품안심업소", {"name": "업소명", "address": "소재지"},
                     use="hygiene", hygiene={"level": "지정등급", "no": "지정번호", "from": "지정일자"}))
    if slug == "suwon":
        out.append(L("mobeom_suwon", "3044660", "mobeom", "모범음식점(수원시 지정)",
                     {"name": "모범업소명", "address": "소재지도로명주소", "phone": "전화번호"}))
    if slug == "mokpo":
        out.append(L("mobeom_mokpo", "3079048", "mobeom", "모범음식점(목포시 지정)",
                     {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}))
    if slug == "chuncheon":
        out.append(L("mobeom_chuncheon", "15050522", "mobeom", "모범음식점(춘천시 지정)",
                     {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}))
    if slug == "jongno":
        out.append(L("mobeom_jongno", "3054122", "mobeom", "모범음식점(종로구 지정)", {"name": "업소명", "address": "소재지(도로명)"}))
    if slug == "yongin":
        out.append(L("mobeom_yongin", "3078133", "mobeom", "모범음식점(용인시 지정)",
                     {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}))
    if slug == "gyeongju":
        out.append(L("mobeom_gyeongju", "15052320", "mobeom", "모범음식점(경주시 지정)",
                     {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}))
    if slug == "sokcho":
        out.append(L("mobeom_sokcho", "3070969", "mobeom", "모범음식점(속초시 지정)",
                     {"name": "업소명", "address": "소재지(도로명)", "phone": "전화번호"}))
    if slug == "haenam":
        out.append(L("mobeom_haenam", "15043619", "mobeom", "모범음식점(해남군 지정)",
                     {"name": "음식점명", "address": "주소", "phone": "연락처"}))
        out.append(L("haenam8mi", "15059735", "haenam8mi", "해남8미 음식점(해남군 지정)",
                     {"name": "음식점명", "address": "도로명주소", "phone": "연락처"}, year=None))
    if slug == "gangneung":
        out.append(L("mobeom_gangneung", "15042858", "mobeom", "모범음식점(강릉시 지정)",
                     {"name": "업소명 ", "address": "도로명주소", "phone": "전화번호"}, keep=lambda r: r["인증"].strip() == "모범"))
        out.append(L("mobeom_gangwon", "15033691", "mobeom", "모범음식점(강원특별자치도 현황)", {"name": "업소명", "address": "도로명주소"},
                     keep=lambda r: in_region(slug, r["도로명주소"]), use="crosscheck"))
    if slug == "yeosu":
        out.append(L("mobeom_jeonnam_yeosu", "3068464", "mobeom", "모범음식점(여수시 지정)",
                     {"name": "업소명", "address": "주소", "phone": "전화번호"}, keep=lambda r: r["시군"].strip() == "여수시"))
    if slug == "incheon":
        out.append(L("mobeom_incheon", "15065207", "mobeom", "모범음식점(인천광역시 현황)", {"name": "업소명", "address": "주소"}))
        for key, pk, cols in (("mobeom_bupyeong", "15103776", {"name": "업소명", "address": "소재지(도로명)", "phone": "전화번호"}),
                              ("mobeom_namdong", "15067441", {"name": "업소명", "address": "도로명주소", "phone": "소재지전화번호"}),
                              ("mobeom_seohae", "15068674", {"name": "업소명", "address": "소재지", "phone": "전화번호"}),
                              ("mobeom_yeonsu", "15055933", {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"})):
            gu = meta(pk)["provider"].split()[-1]
            out.append(L(key, pk, "mobeom", f"모범음식점(인천 {gu} 지정)", cols))
        out.append(L("hygiene_yeongjong", "15075091", "hygiene", "식품안심업소", {"name": "업소명", "address": "소재지 주소"},
                     use="hygiene", hygiene={"from": "지정시작일", "to": "지정종료일", "kind": "업종명"}))
        out.append(L("hygiene_bupyeong", "15104147", "hygiene", "식품안심업소", {"name": "업소명", "address": "소재지(도로명)", "phone": "전화번호"},
                     use="hygiene", hygiene={"level": "지정등급", "from": "지정일자", "kind": "업종"}))
        out.append(L("hygiene_yeonsu", "15116604", "hygiene", "식품안심업소", {"name": "업소명", "address": "소재지"},
                     use="hygiene", hygiene={"level": "위생등급", "from": "지정일자"}))
    if slug == "busan":
        for key, pk, cols in (("mobeom_dongnae", "3081196", {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}),
                              ("mobeom_geumjeong", "3045754", {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}),
                              ("mobeom_suyeong", "15026432", {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}),
                              ("mobeom_busanjin", "15055847", {"name": "업소명", "address": "소재지(도로명)", "phone": "전화번호"}),
                              ("mobeom_seo", "15051963", {"name": "업소명", "address": "소재지(도로명)", "phone": "전화번호"}),
                              ("mobeom_gangseo", "3045893", {"name": "업소명", "address": "소재지(도로명)", "phone": "소재지전화번호"}),
                              ("mobeom_jung", "15099747", {"name": "업소명", "address": "소재지(도로명)", "phone": "전화번호"}),
                              ("mobeom_nam", "3044766", {"name": "업소명", "address": "소재지(도로명)", "phone": "전화번호"})):
            gu = meta(pk)["provider"].replace("_", " ").split()[-1]
            out.append(L(key, pk, "mobeom", f"모범음식점(부산 {gu} 지정)", cols))
        out.append(L("hygiene_busan", "15077429", "hygiene", "식품안심업소", {"name": "업소명(상호)", "address": "영업장소재지"},
                     use="hygiene", hygiene={"from": "지정일자", "kind": "업종"}))
    return out


def ymd(s):
    s = re.sub(r"[^\d]", "", str(s or ""))
    return f"{s[:4]}-{s[4:6]}-{s[6:8]}" if len(s) == 8 else ""


def run(slug):
    d = data_dir(slug)
    raw = ROOT / "out" / slug / "raw" / "designations"
    raw.mkdir(parents=True, exist_ok=True)
    lists = lists_for(slug)
    manifest = {"checked_at": TODAY, "lists": []}
    for src in lists:
        rows = rows_of(src["pk"])
        keep = src.pop("_keep")
        src.pop("_addr_fix")
        rows = [r for r in rows if keep is None or keep(r)]
        src["file"] = f"{src['key']}_{src['pk']}.csv"
        src["rows_in_site"] = len(rows)
        with open(raw / src["file"], "w", encoding="utf-8", newline="") as f:
            if rows:
                w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
                w.writeheader()
                w.writerows(rows)
            else:
                f.write(",".join(src["columns"].values()) + "\n")
        mlist = dict(src)
        mlist["use"] = "write" if src["use"] in ("write", "hygiene") else src["use"]
        manifest["lists"].append(mlist)
    (raw / "sources.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), "utf-8")
    res = imd.run(d, raw)
    places = {e["id"]: e for e in res["records"]}
    by_key = {s["key"]: s for s in lists}
    patch, hyg_patch, stats = {}, {}, {}
    new_by_pid = collections.defaultdict(list)
    for key, (src, rows, r) in res["results"].items():
        st = res["stats"][key]
        s = by_key[key]
        stats[key] = {"type": s["type"], "use": s["use"], "rows": sum(st["rows"].values()), "high": sum(st["high"].values()),
                      "near": sum(st["near"].values()), "ambiguous": sum(st["ambiguous"].values()),
                      "other_kind": st["other_kind"], "dataset": s["dataset"], "url": s["url"], "base_date": s["base_date"],
                      "license": s["license"], "provider": s["provider"], "added": 0, "already_had_type": 0}
    for pid, ds in res["written"].items():
        for dsg in ds:
            key = dsg["match"]["row_ref"].split("#")[0]
            s = by_key[key]
            if s["use"] == "hygiene":
                row = next(x for x in res["results"][key][2] if f"{key}#{x['row'].n}" == dsg["match"]["row_ref"])["row"]
                h = s["hygiene"]
                c = row.cells
                obj = {"level": (c.get(h.get("level", "")) or "").strip(), "valid_from": ymd(c.get(h.get("from", ""))),
                       "valid_to": ymd(c.get(h.get("to", ""))) or None, "no": (c.get(h.get("no", "")) or "").strip(),
                       "designated_by": "", "kind": (c.get(h.get("kind", "")) or "").strip(), "name": row.name,
                       "source": {"provider": s["provider"], "dataset": s["dataset"], "url": s["url"], "base_date": s["base_date"],
                                  "license": s["license"], "checked_at": TODAY},
                       "match": dsg["match"]}
                if obj["valid_to"] and obj["valid_to"] < TODAY:
                    continue   # an expired designation is not shown (Gunsan hygiene_valid)
                if pid not in hyg_patch:
                    hyg_patch[pid] = {"hygiene": obj}
                    stats[key]["added"] += 1
                continue
            new_by_pid[pid].append(dsg)
    for pid, new in new_by_pid.items():
        e = places[pid]
        have = {x.get("type") for x in e.get("designations") or []}
        add = []
        for dsg in new:
            key = dsg["match"]["row_ref"].split("#")[0]
            if dsg["type"] in have or dsg["type"] in {a["type"] for a in add}:
                stats[key]["already_had_type"] += 1
                continue
            add.append(dsg)
            stats[key]["added"] += 1
        if add:
            merged = list(e.get("designations") or []) + add
            merged.sort(key=lambda x: res["city"].designation_rank(x.get("type")))
            patch[pid] = {"designations": merged}
    o = ROOT / "out" / slug
    (o / "patch_designations.json").write_text(json.dumps({"_about": "places.json 장소 id → designations(기존 지정 + 새 지정, 같은 type이 이미 있으면 더하지 않음). "
                                                           "build_designations.py(대구 import_designations_daegu 매칭 규칙: high만).",
                                                           "places": patch}, ensure_ascii=False, indent=1) + "\n", "utf-8")
    if hyg_patch:
        (o / "patch_hygiene.json").write_text(json.dumps({"_about": "licenses.json places[id].hygiene 후보(식품안심업소 시·구 지정 현황 파일). "
                                                          "이름+주소(도로명·건물번호) 또는 이름+전화가 맞는 음식점만. valid_to가 없는 행은 파일에 지정 종료일이 없어서다(계산하지 않음).",
                                                          "places": hyg_patch}, ensure_ascii=False, indent=1) + "\n", "utf-8")
    (o / "designations_summary.json").write_text(json.dumps(stats, ensure_ascii=False, indent=1), "utf-8")
    print(slug, {k: (v["rows"], v["high"], v["added"], v["already_had_type"]) for k, v in stats.items()})


if __name__ == "__main__":
    for s in (sys.argv[1:] or list(SITES)):
        run(s)
