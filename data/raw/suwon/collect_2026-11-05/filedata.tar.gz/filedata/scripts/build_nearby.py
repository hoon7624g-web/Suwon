"""Candidate parking_lots.json + nearby.json per site (engine schema of Daegu/Gunsan: pipeline/build.py parking_lots,
present.lot_row / access_vm) from 전국주차장정보표준데이터 per-provider files and bus stop files.

    python3 build_nearby.py [slug ...]

Rules (Daegu tools/import_parking_daegu.py + import_nearby_daegu.py, Gunsan nearby.json):
- lots: every row with coordinates whose address is in the site (sites.in_region; a row without address only inside the
  places' box). Values as written. Rows that may not appear in '근처 공영주차장' stay with nearby=false and the reason:
  민영, 화물·관광버스 전용(이름), 면수 없음, a point shared by 3+ lots with different names (PLACEHOLDER), a duplicate of a
  lot in another file (same name core within DUP_M, or same 관리번호+name) — the 구·군/시 file row is kept.
- nearby: for every place with geo (published and draft): usable lots within 500 m nearest 3; bus stops within 500 m,
  the nearest stop of each of the 2 nearest names (Gunsan); routes [] (the stop files give none — not 'no bus').
  Distances haversine R=6371008.8 m, whole metres; measured_from = the place's point.
Nothing is written into a repo; out/<slug>/parking_lots.json, out/<slug>/nearby.json and out/<slug>/nearby_diff.json.
"""
from __future__ import annotations

import csv, io, json, math, re, sys, collections, hashlib
from pathlib import Path

sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, data_dir, in_region, REGION, CITY_LABEL
import stdfiles

sys.path.insert(0, "/home/user/Daegu")
from pipeline.romanize import romanize  # noqa: E402  (read-only import)

TODAY = "2026-11-05"
EARTH_R = 6371008.8
PARKING_R, PARKING_MAX, BUS_R, BUS_MAX = 500, 3, 500, 2
PLACEHOLDER_M, DUP_M = 2.0, 100
DATASET, DATASET_URL = "전국주차장정보표준데이터", "https://www.data.go.kr/data/15012896/standard.do"
DAYS = (("평일", "weekday", "평일운영시작시각", "평일운영종료시각"),
        ("토요일", "saturday", "토요일운영시작시각", "토요일운영종료시각"),
        ("공휴일", "holiday", "공휴일운영시작시각", "공휴일운영종료시각"))
NATIONAL_BUS = Path("/home/user/work/filedata/downloads/bus/national_bus_stops_15067528.csv")
BUS_NATIONAL_SRC = {"name": "국토교통부 · 공공데이터포털 전국 버스정류장 위치정보", "provider": "국토교통부(국가대중교통정보센터 TAGO 연계 BIS)",
                    "url": "https://www.data.go.kr/data/15067528/fileData.do", "file": "국토교통부_전국 버스정류장 위치정보_20261020.csv",
                    "data_reference_date": "2026-10-20", "license": "공공데이터포털 이용허락범위 '제한 없음'(2026-11-05 확인) — 출처 표시"}
# the national file's 도시명 per site (rows of other cities are never used)
BUS_CITY = {"haenam": ["전남광주통합특별시 해남군"], "sejong": ["세종특별자치시"], "yeongju": ["경상북도 영주시"],
            "gangneung": ["강원특별자치도 강릉시"], "jeju": ["제주특별자치도"], "yeosu": ["전남광주통합특별시 여수시"],
            "jeonju": ["전남광주통합특별시 전주시"], "chuncheon": ["강원특별자치도 춘천시"], "yongin": ["경기도 용인시"],
            "gyeongju": ["경상북도 경주시"], "busan": ["부산광역시"], "suwon": ["경기도 수원시"], "sokcho": ["강원특별자치도 속초시"],
            "danyang": ["충청북도 단양군"], "mokpo": ["전남광주통합특별시 목포시"], "incheon": ["인천광역시"],
            "gapyeong": ["경기도 가평군"], "jongno": ["서울특별시"], "daegu": ["대구광역시", "대구광역시 군위군"]}
EXTRA_BUS = {   # city files where the national file has (almost) none
    "jongno": {"kind": "seoul", "path": Path("/home/user/work/filedata/downloads/bus/seoul_stops_20260902.xlsx"),
               "name": "서울특별시 · 서울 열린데이터광장 서울시 버스정류소 위치정보", "provider": "서울특별시 교통정보과",
               "url": "https://data.seoul.go.kr/dataList/OA-15067/S/1/datasetView.do", "file": "서울시버스정류소위치정보(20260902).xlsx",
               "data_reference_date": "2026-09-02", "license": "공공누리 제1유형(출처표시) — 공공데이터포털 15051741 페이지 표기"},
    "sokcho": {"kind": "sokcho", "path": Path("/home/user/work/filedata/downloads/bus/sokcho_15118217.csv"),
               "name": "강원특별자치도 속초시 · 공공데이터포털 버스정류장", "provider": "강원특별자치도 속초시",
               "url": "https://www.data.go.kr/data/15118217/fileData.do", "file": "강원특별자치도 속초시_버스정류장_20230809.csv",
               "data_reference_date": "2023-08-09", "license": "공공데이터포털 이용허락범위 '제한 없음'(2026-11-05 확인)"},
}


def sq(v) -> str:
    return " ".join(str(v or "").split())


def hav(a_lat, a_lng, b_lat, b_lng) -> float:
    p1, p2 = math.radians(a_lat), math.radians(b_lat)
    dp, dl = p2 - p1, math.radians(b_lng - a_lng)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_R * math.asin(math.sqrt(h))


def num(v):
    v = sq(v).replace(",", "")
    if not v:
        return None
    try:
        f = float(v)
    except ValueError:
        return None
    return int(f) if f == int(f) else f


def name_core(name: str) -> str:
    n = re.sub(r"\([^)]*\)?", "", name)
    return re.sub(r"주차장|공영|노상|노외|임시|인근|도로|[0-9A-Za-z\s\-·.,]", "", n)


def file_key(provider: str, slug: str) -> str:
    pre, _ = REGION[slug]
    p = sq(provider)
    for x in sorted(pre, key=len, reverse=True):
        if p.startswith(x) and p != x:
            p = p[len(x):].strip()
            break
    k = re.sub(r"[^a-z0-9]", "", romanize(p).lower())
    return k or hashlib.sha1(provider.encode()).hexdigest()[:6]


def places_box(places):
    pts = [(float(p["geo"]["lat"]), float(p["geo"]["lng"])) for p in places if (p.get("geo") or {}).get("lat")]
    lats, lngs = [a for a, _ in pts], [b for _, b in pts]
    return (min(lats) - 0.05, max(lats) + 0.05, min(lngs) - 0.05, max(lngs) + 0.05)


def fee_version(r, provider, fname):
    basic_m, basic_w = num(r["주차기본시간"]), num(r["주차기본요금"])
    extra_m, extra_w = num(r["추가단위시간"]), num(r["추가단위요금"])
    day_w, month_w = num(r["1일주차권요금"]), num(r["월정기권요금"])
    v = {"source": "standard", "label": "요금", "source_name": f"공공데이터포털 {DATASET} · {fname}", "url": DATASET_URL,
         "checked_at": TODAY}
    if basic_m and basic_w is not None:
        v["basic"] = {"minutes": basic_m, "won": basic_w}
    if extra_m and extra_w:
        v["extra"] = {"minutes": extra_m, "won": extra_w}
    if day_w:
        v["day"] = {"won": day_w, "applies_raw": sq(r["1일주차권요금적용시간"])}
    if month_w:
        v["month"] = {"won": month_w}
    return v if any(k in v for k in ("basic", "extra", "day")) else None


def hours(r):
    days = [d for d in sq(r["운영요일"]).split("+") if d]
    h = {"days": "+".join(days)}
    for label, key, s, e in DAYS:
        if label in days and sq(r[s]) and sq(r[e]):
            h[key] = [sq(r[s]), sq(r[e])]
    return h


def load_lots(slug, prefix, box):
    man = json.loads((ROOT / "out" / slug / "raw" / "parking" / "manifest.json").read_text("utf-8"))
    lots, dropped, files = [], collections.Counter(), []
    for f in man["files"]:
        if f.get("error"):
            continue
        key = file_key(f["provider"], slug)
        fname = sq(f["name"]).replace("파일데이터 ", "")
        text = stdfiles.decode((ROOT / "out" / slug / f["file"]).read_bytes())
        n = 0
        for r in csv.DictReader(io.StringIO(text)):
            n += 1
            try:
                lat, lng = float(r["위도"]), float(r["경도"])
            except (ValueError, TypeError):
                dropped["좌표 없음"] += 1
                continue
            addr = sq(r["소재지도로명주소"]) or sq(r["소재지지번주소"])
            if addr and not in_region(slug, addr):
                dropped["주소가 사이트 밖"] += 1
                continue
            if not (box[0] <= lat <= box[1] and box[2] <= lng <= box[3]):
                dropped["좌표가 사이트 범위 밖"] += 1
                continue
            mgmt = sq(r["주차장관리번호"])
            paid = sq(r["요금정보"])
            lot = {"id": f"{prefix}-prk-{key}-{mgmt}", "management_no": mgmt, "name": sq(r["주차장명"]),
                   "operation": sq(r["주차장구분"]), "type": sq(r["주차장유형"]),
                   "address": sq(r["소재지도로명주소"]) or None, "address_jibun": sq(r["소재지지번주소"]) or None,
                   "lat": lat, "lng": lng, "spaces": num(r["주차구획수"]), "paid": paid, "hours": hours(r),
                   "phone": sq(r["전화번호"]) or None, "manager": sq(r["관리기관명"]) or None,
                   "payment": sq(r["결제방법"]) or None, "grade": sq(r["급지구분"]) or None,
                   "provider": sq(f["provider"]), "file": key,
                   "reference_date": sq(r["데이터기준일자"]) or f.get("modified")}
            if paid != "무료":
                v = fee_version(r, f["provider"], fname)
                if v:
                    lot["fee"] = {"versions": [v], "differs": False}
            lots.append(lot)
        files.append({"provider": sq(f["provider"]), "file": fname, "key": key, "rows": n, "modified": f.get("modified"),
                      "download": f.get("download"), "raw": f["file"], "license": f.get("license")})
    # ids: a 관리번호 repeated inside one file gets a name suffix
    ids = collections.Counter(l["id"] for l in lots)
    for l in lots:
        if ids[l["id"]] > 1:
            l["id"] += "-" + hashlib.sha1(l["name"].encode()).hexdigest()[:6]
    seen = set()
    uniq = []
    for l in lots:   # exact duplicate rows (same id after suffix) once
        if l["id"] in seen:
            dropped["같은 행 중복"] += 1
            continue
        seen.add(l["id"])
        uniq.append(l)
    return uniq, dropped, files


def mark_excluded(lots):
    def ex(l, why):
        if l.get("nearby") is not False:
            l["nearby"] = False
            l["nearby_excluded"] = why
    # placeholder points
    for l in lots:
        near = [x for x in lots if hav(l["lat"], l["lng"], x["lat"], x["lng"]) <= PLACEHOLDER_M]
        if len(near) >= 3 and len({name_core(x["name"]) for x in near}) >= 2:
            for x in near:
                ex(x, f"좌표 공유(같은 좌표에 이름이 다른 주차장 {len(near)}곳 — 주차장마다의 위치가 아님)")
    for l in lots:
        if l["operation"] != "공영":
            ex(l, f"{l['operation'] or '구분 없음'} 주차장(근처 목록은 공영만)")
        elif re.search(r"화물|관광버스|전세버스|대형차 ?전용", l["name"]):
            ex(l, "화물·버스 전용(이름)")
        elif not isinstance(l.get("spaces"), int) or l["spaces"] <= 0:
            ex(l, "면수 없음")
    # duplicates across files: same name core (2+ letters) within DUP_M, or same 관리번호 and name
    order = sorted(range(len(lots)), key=lambda i: ("공단" in lots[i]["provider"], lots[i]["provider"].count(" ") == 0, i))
    kept = []
    for i in order:
        l = lots[i]
        if l.get("nearby") is False:
            continue
        dup = next((k for k in kept if k["file"] != l["file"] and (
            (k["management_no"] == l["management_no"] and k["name"] == l["name"]) or
            (len(name_core(k["name"])) >= 2 and name_core(k["name"]) == name_core(l["name"])
             and hav(k["lat"], k["lng"], l["lat"], l["lng"]) <= DUP_M))), None)
        if dup:
            ex(l, f"중복 행({dup['id']}와 같은 주차장으로 봄 — 이름·위치)")
            l["duplicate_of"] = dup["id"]
        else:
            kept.append(l)


def load_stops(slug):
    stops, src = [], []
    cities = set(BUS_CITY.get(slug) or [])
    if slug in EXTRA_BUS and EXTRA_BUS[slug]["kind"] == "seoul":
        cities = set()   # 서울: the national file has only 경기BIS stops there
    if cities:
        text = stdfiles.decode(NATIONAL_BUS.read_bytes())
        n = 0
        for r in csv.DictReader(io.StringIO(text)):
            # 경기BIS rows outside 경기도 are the stops of Gyeonggi intercity buses only, not the city's network:
            # they are left out there (강릉 has nothing else, so no bus rows)
            if r["도시명"] in cities and not (r["관리도시명"].strip() == "경기BIS" and not r["도시명"].startswith("경기도")):
                try:
                    stops.append({"name": sq(r["정류장명"]), "lat": float(r["위도"]), "lng": float(r["경도"]),
                                  "node_id": sq(r["정류장번호"]), "src": "national", "bis": sq(r["관리도시명"])})
                    n += 1
                except ValueError:
                    pass
        if n:
            src.append({**BUS_NATIONAL_SRC, "rows": n, "cities": sorted(cities)})
    x = EXTRA_BUS.get(slug)
    if x:
        n = 0
        if x["kind"] == "seoul":
            import openpyxl
            ws = openpyxl.load_workbook(x["path"], read_only=True).active
            head = None
            for row in ws.iter_rows(values_only=True):
                if head is None:
                    head = list(row)
                    continue
                r = dict(zip(head, row))
                if sq(r.get("정류소타입")) == "한강선착장":
                    continue
                try:
                    stops.append({"name": sq(r["정류소명"]), "lat": float(r["Y좌표"]), "lng": float(r["X좌표"]),
                                  "node_id": sq(r["NODE_ID"]), "ars_id": sq(r["ARS_ID"]), "src": "seoul"})
                    n += 1
                except (TypeError, ValueError):
                    pass
        else:
            for r in csv.DictReader(io.StringIO(stdfiles.decode(x["path"].read_bytes()))):
                try:
                    stops.append({"name": sq(r["정류소명"]), "lat": float(r["위도"]), "lng": float(r["경도"]),
                                  "node_id": sq(r["정류소ID"]), "src": "city"})
                    n += 1
                except ValueError:
                    pass
        src.append({k: v for k, v in x.items() if k not in ("kind", "path")} | {"rows": n})
    # placeholder: 3+ stops with different names at one point are not where each stop is
    bad = set()
    grid = collections.defaultdict(list)
    for i, s in enumerate(stops):
        grid[(round(s["lat"], 4), round(s["lng"], 4))].append(i)
    for i, s in enumerate(stops):
        k = (round(s["lat"], 4), round(s["lng"], 4))
        near = [j for a in (-1, 0, 1) for b in (-1, 0, 1)
                for j in grid.get((round(k[0] + a / 1e4, 4), round(k[1] + b / 1e4, 4)), [])
                if hav(s["lat"], s["lng"], stops[j]["lat"], stops[j]["lng"]) <= PLACEHOLDER_M]
        if len(near) >= 3 and len({stops[j]["name"] for j in near}) >= 2:
            bad |= set(near)
    return [s for i, s in enumerate(stops) if i not in bad and s["name"]], src, len(bad)


def nearby_entries(places, lots, stops):
    usable = [l for l in lots if l.get("nearby") is not False]
    sg = collections.defaultdict(list)
    for s in stops:
        sg[(int(s["lat"] * 100), int(s["lng"] * 100))].append(s)
    lg = collections.defaultdict(list)
    for l in usable:
        lg[(int(l["lat"] * 100), int(l["lng"] * 100))].append(l)

    def around(grid, lat, lng):
        a, b = int(lat * 100), int(lng * 100)
        for i in (-1, 0, 1):
            for j in (-1, 0, 1):
                yield from grid.get((a + i, b + j), [])
    out = {}
    for p in places:
        g = p.get("geo") or {}
        if g.get("lat") is None or g.get("lng") is None:
            continue
        lat, lng = float(g["lat"]), float(g["lng"])
        pk = sorted(((round(hav(lat, lng, l["lat"], l["lng"])), l["id"]) for l in around(lg, lat, lng)))
        pk = [{"lot_id": i, "meters": m} for m, i in pk if m <= PARKING_R][:PARKING_MAX]
        best = {}
        for s in around(sg, lat, lng):
            m = round(hav(lat, lng, s["lat"], s["lng"]))
            if m <= BUS_R and (s["name"] not in best or m < best[s["name"]][0]):
                best[s["name"]] = (m, s)
        bus = []
        for name, (m, s) in sorted(best.items(), key=lambda kv: (kv[1][0], kv[0]))[:BUS_MAX]:
            row = {"stop_name": name, "meters": m, "routes": []}
            if s.get("node_id"):
                row["node_id"] = s["node_id"]
            bus.append(row)
        out[p["id"]] = {"parking": pk, "bus": bus, "measured_from": {"lat": lat, "lng": lng}}
    return out


def coverage(places, nb):
    pub = [p for p in places if p.get("status") == "published" and (p.get("geo") or {}).get("lat") is not None]
    n = len([p for p in places if p.get("status") == "published"])
    pk = sum(1 for p in pub if (nb.get(p["id"]) or {}).get("parking"))
    bs = sum(1 for p in pub if (nb.get(p["id"]) or {}).get("bus"))
    return {"published": n, "published_geo": len(pub), "parking": pk, "bus": bs,
            "parking_pct": round(100 * pk / n, 1) if n else 0, "bus_pct": round(100 * bs / n, 1) if n else 0}


def run(slug):
    d = data_dir(slug)
    site = json.loads((d / "site.json").read_text("utf-8"))
    prefix = site.get("id_prefix") or slug
    places = json.loads((d / "places.json").read_text("utf-8"))
    box = places_box(places)
    lots, dropped, files = load_lots(slug, prefix, box)
    mark_excluded(lots)
    stops, bus_src, bad_stops = load_stops(slug)
    nb = nearby_entries(places, lots, stops)
    row_providers = "·".join(dict.fromkeys(f["provider"] for f in files))
    parking = {
        "_about": (f"{CITY_LABEL[slug]}의 주차장(공공데이터포털 {DATASET} {len(files)}개 제공기관 파일, 좌표가 있고 주소가 이 지역인 행 전부). "
                   "장소 페이지의 '근처 공영주차장'은 nearby가 false가 아닌 공영 주차장만 쓴다. 장소 자체의 주차 정보(places.json "
                   "facts.parking)가 아니며 색인 기준(필수 정보 묶음)에 들어가지 않는다. /home/user/work/filedata/scripts/"
                   "build_nearby.py가 원본 파일에서 만든 후보다 — 손으로 고치지 않는다."),
        "source": {"standard": {
            "name": f"{row_providers} · 공공데이터포털 {DATASET}", "provider": "공공데이터포털", "row_provider": row_providers,
            "url": DATASET_URL, "checked_at": TODAY,
            "files": {f["key"]: {"provider": f["provider"], "file": f["file"], "data_reference_date": f["modified"],
                                 "download": f["download"], "raw": "raw/" + f["raw"].split("raw/", 1)[-1],
                                 "license": f["license"]} for f in files},
            "license": "공공데이터포털 이용허락범위: " + " / ".join(sorted({f"{f['provider']} '{f['license']}'" for f in files})) +
                       " (2026-11-05 확인) · 공공데이터법 제3조에 따른 자유 이용, 출처 표시",
            "fields": "주차기본시간·추가단위시간은 분. 1일주차권요금적용시간은 applies_raw로만 둔다. 월정기권요금은 화면에 쓰지 않는다."}},
        "contacts": [],
        "lots": lots,
    }
    bus_meta = {"radius_m": BUS_R, "max": BUS_MAX,
                "source_name": " · ".join(s["name"] for s in bus_src) if bus_src else "",
                "provider": " · ".join(s["provider"] for s in bus_src), "url": bus_src[0]["url"] if bus_src else "",
                "files": bus_src, "checked_at": TODAY,
                "distance": "straight_line_m(haversine R=6371008.8m, 정수 m)",
                "routes_rule": "노선 번호는 넣지 않는다(빈 목록). 버스가 없다는 뜻이 아니다 — 정류장 파일에 경유 노선이 없다.",
                "same_name": "같은 이름 정류장은 가장 가까운 하나(Gunsan·Haenam 방식)",
                "excluded": f"같은 좌표에 이름이 다른 정류장 3곳 이상인 점의 {bad_stops}행 제외(좌표 공유)"}
    nearby = {"_meta": {
        "about": "장소 좌표에서 직선거리(하버사인)로 잰 근처 공영주차장과 버스 정류장. 걷는 거리가 아니다. 장소 자체의 주차·교통 "
                 "정보가 아니며 색인 기준에 들어가지 않는다. build_nearby.py 후보.",
        "places": "places.json에서 좌표(geo)가 있는 모든 장소(공개·draft). measured_from은 잰 때의 장소 좌표",
        "parking": {"radius_m": PARKING_R, "max": PARKING_MAX, "lots_file": "parking_lots.json",
                    "method": "haversine R=6371008.8m, 정수 m 반올림, 가까운 순(같으면 id 순). nearby=false인 행 제외",
                    "provider": "공공데이터포털 전국주차장정보표준데이터", "url": DATASET_URL, "checked_at": TODAY,
                    "data_reference_date": "~".join(sorted({f['modified'] for f in files if f.get('modified')})[::max(1, len(files) - 1)])},
        "bus": bus_meta}}
    nearby.update(dict(sorted(nb.items())))
    if not stops:
        nearby["_meta"].pop("bus")
        for v in nb.values():
            v.pop("bus", None)
    # existing
    old_nb = json.loads((d / "nearby.json").read_text("utf-8")) if (d / "nearby.json").is_file() else {}
    old_pl = json.loads((d / "parking_lots.json").read_text("utf-8")) if (d / "parking_lots.json").is_file() else {}
    before, after = coverage(places, old_nb), coverage(places, nb)
    usable = [l for l in lots if l.get("nearby") is not False]
    diff = {"slug": slug, "before": before, "after": after,
            "lots": {"rows_kept": len(lots), "usable": len(usable), "dropped": dict(dropped),
                     "excluded": dict(collections.Counter(re.sub(r"\(.*", "", l["nearby_excluded"]) for l in lots
                                                          if l.get("nearby") is False))},
            "stops": {"rows": len(stops), "placeholder_dropped": bad_stops, "sources": [s["name"] for s in bus_src]},
            "files": files}
    if old_pl:
        old = {(l.get("management_no"), l.get("name")) for l in old_pl.get("lots") or []}
        new = {(l["management_no"], l["name"]) for l in lots}
        diff["vs_existing_lots"] = {"existing": len(old), "candidate": len(new), "only_candidate": len(new - old),
                                    "only_existing": len(old - new),
                                    "only_candidate_examples": sorted(new - old)[:10],
                                    "only_existing_examples": sorted(old - new)[:10]}
    o = ROOT / "out" / slug
    o.mkdir(parents=True, exist_ok=True)
    good = before["parking_pct"] >= 40 or before["bus_pct"] >= 60
    target = o / ("candidate_existing_good" if good else ".")
    target.mkdir(parents=True, exist_ok=True)
    (target / "parking_lots.json").write_text(json.dumps(parking, ensure_ascii=False, indent=1) + "\n", "utf-8")
    (target / "nearby.json").write_text(json.dumps(nearby, ensure_ascii=False, indent=1) + "\n", "utf-8")
    diff["written_to"] = str(target.relative_to(ROOT / "out"))
    diff["existing_good"] = good
    (o / "nearby_diff.json").write_text(json.dumps(diff, ensure_ascii=False, indent=1) + "\n", "utf-8")
    print(slug, "before", before, "after", after, "lots", len(lots), "usable", len(usable), "stops", len(stops),
          "->", diff["written_to"])


if __name__ == "__main__":
    for s in (sys.argv[1:] or list(SITES)):
        run(s)
