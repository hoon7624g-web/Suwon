"""place.market patches per site — Gunsan tools/market_data_gunsan.py logic (imported read-only, its constants set per
site): 온누리 가맹점(3060079) rows of the linked market names → shop groups; 상가(상권)정보(15083033) stores within 300 m
give a shop its address only when one store of that name is there; STORE_KINDS (떡/한과) stores near the market.
행정안전부 인허가 식품 3종: not available (the key is not registered for those three services — 403
SERVICE_KEY_IS_NOT_REGISTERED_ERROR, 2026-11-05), so no licensed cards.

Output: out/<slug>/patch_market.json {place_id: {"market": {...}}} and raw/markets/onnuri_<slug>_20260731.csv.
"""
from __future__ import annotations
import csv, io, json, re, sys, importlib.util
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, data_dir, REGION
import stdfiles

spec = importlib.util.spec_from_file_location("mdg", "/home/user/gunsan/tools/market_data_gunsan.py")
mdg = importlib.util.module_from_spec(spec)
sys.argv_backup = sys.argv
spec.loader.exec_module(mdg)

ONNURI_SRC = Path("/home/user/work/filedata/downloads/markets/onnuri_3060079.csv")
TODAY = "2026-11-05"


def city_rx(slug: str) -> str:
    pre, city = REGION[slug]
    sido = "|".join(sorted(map(re.escape, pre), key=len, reverse=True))
    if city:
        return rf"^(?:(?:{sido})\s+)?{re.escape(city)}\s+"
    return rf"^(?:{sido})\s+(?:\S+(?:구|군)\s+)?"


def run():
    onn_all = list(csv.DictReader(io.StringIO(stdfiles.decode(ONNURI_SRC.read_bytes()))))
    summary = {}
    for slug in SITES:
        root = ROOT / "out" / slug / "raw" / "markets"
        lf = root / "market_links.json"
        links = json.loads(lf.read_text("utf-8"))["links"] if lf.is_file() else []
        if not links:
            summary[slug] = None
            continue
        names = {n for r in links for n in r["onnuri"]}
        from sites import SIDO_SHORT
        sido = {"전남": "전남광주"}.get(SIDO_SHORT[slug], SIDO_SHORT[slug])
        rows = [r for r in onn_all if r["소속 시장명(또는 상점가)"] in names and r["소재지"].strip() == sido]
        # rows of exactly the site's 시·도 (the linking used it)
        sidos = {r["소재지"] for r in rows}
        onn_file = f"onnuri_{slug}_20260731.csv"
        mdg.write(root / onn_file, rows)
        mdg.ONNURI["file"] = onn_file
        sg = f"sangga_{slug}_markets_202609.csv"
        mdg.SANGGA["file"] = sg
        mdg.STD["file"] = "__none__.csv"
        mdg.MARKETS = {r["id"]: {"onnuri": r["onnuri"]} for r in links}
        mdg.CITY_RX = city_rx(slug)
        places = json.loads((data_dir(slug) / "places.json").read_text("utf-8"))
        by = {p["id"]: p for p in places}
        points = {pid: (float(by[pid]["geo"]["lat"]), float(by[pid]["geo"]["lng"])) for pid in mdg.MARKETS}
        got = mdg.market_rows(root, TODAY, points, by)
        patch = {}
        for pid, g in got.items():
            if not g:
                continue
            existing = by[pid].get("market") or {}
            m = {k: v for k, v in existing.items() if k not in mdg.KEYS}
            for k in mdg.KEYS:
                keep = [r for r in existing.get(k) or [] if r.get("provider") != mdg.PROVIDER]
                if keep + g.get(k, []):
                    m[k] = keep + g.get(k, [])
            patch[pid] = {"market": m}
        out = ROOT / "out" / slug / "patch_market.json"
        out.write_text(json.dumps({"_about": "places.json 장소 id → market(온누리 가맹점·상가정보 주소). 기존 market의 다른 출처 값은 그대로 두고 "
                                             "소상공인시장진흥공단 값만 바꾼다(market_data_gunsan.apply_rows와 같음).",
                                   "places": patch}, ensure_ascii=False, indent=1) + "\n", "utf-8")
        shops = sum(len({s["name"] for gg in (v["market"].get("shops") or [{}])[0].get("groups") or [] for s in gg["shops"]})
                    for v in patch.values())
        with_addr = sum(((v["market"].get("shops") or [{}])[0].get("addr_source") or {}).get("with_addr", 0) for v in patch.values())
        store_cards = sum(len(lc["rows"]) for v in patch.values() for lc in (v["market"].get("shops") or [{}])[0].get("licensed") or [])
        summary[slug] = {"markets": len(patch), "onnuri_rows": len(rows), "sido": sorted(sidos), "shops": shops,
                         "with_addr": with_addr, "store_cards": store_cards,
                         "markets_list": {by[k]["name"]: v["market"]["onnuri"][0]["value"] for k, v in patch.items()}}
        print(slug, json.dumps({k: v for k, v in summary[slug].items() if k != "markets_list"}, ensure_ascii=False))
    (ROOT / "cache" / "markets_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    run()
