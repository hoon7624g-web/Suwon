import sys, json, csv, io; sys.path.insert(0, "/home/user/work/filedata/scripts")
import filedata, stdfiles
from pathlib import Path
D = Path("/home/user/work/filedata/downloads/toilets")
PKS = sys.argv[1:]
for pk in PKS:
    try:
        p, info = filedata.download(pk, D / f"{pk}.bin")
        b = p.read_bytes()
        if b[:2] == b"PK":
            print(pk, info["name"], "ZIP/XLSX", len(b)); continue
        t = stdfiles.decode(b)
        rd = csv.DictReader(io.StringIO(t)); rows = list(rd)
        (D / f"{pk}.json").write_text(json.dumps({k: info.get(k) for k in ("pk","name","provider","rows","modified","registered","license","url","file_name")}, ensure_ascii=False), "utf-8")
        print(pk, info["name"], "|", info["modified"], "|", info["license"], "| rows", len(rows), "|", rd.fieldnames)
    except Exception as e:
        print(pk, "ERR", str(e)[:200])
