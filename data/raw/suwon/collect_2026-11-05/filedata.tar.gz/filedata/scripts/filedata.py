"""data.go.kr fileData pages: page info (name, provider, 기준일, rows, licence) and the file download (no key)."""
from __future__ import annotations
import json, re, sys, urllib.parse, urllib.request
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
import net

BASE = "https://www.data.go.kr"


def page(pk: str) -> dict:
    t = net.get(f"{BASE}/data/{pk}/fileData.do", cache_ns="pages", cache_name=f"fileData_{pk}.html")
    txt = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", re.sub(r"<script.*?</script>", " ", t, flags=re.S)))
    def f(label, stop=r"(?=\s(?:분류체계|제공기관|관리부서명|관리부서 전화번호|보유근거|수집방법|업데이트 주기|차기 등록 예정일|매체유형|전체 행|확장자|키워드|데이터 한계|다운로드|등록일|수정일|제공형태|설명|기타 유의사항|비용부과유무|비용부과기준|이용허락범위|URL|$))"):
        m = re.search(re.escape(label) + r"\s+(.*?)" + stop, txt)
        return m.group(1).strip() if m else ""
    downs = re.findall(r"fn_fileDataDown\('(\d+)',\s*'([^']*)',\s*'([^']*)',\s*'([^']*)',\s*'([^']*)'\)", t)
    return {"pk": pk, "name": f("파일데이터명"), "provider": f("제공기관"), "rows": f("전체 행"), "ext": f("확장자"),
            "registered": f("등록일"), "modified": f("수정일"), "license": re.split(r" 이 페이지| 추천데이터| 목록으로", f("이용허락범위"))[0].strip(), "cycle": f("업데이트 주기"),
            "downloads": downs, "url": f"{BASE}/data/{pk}/fileData.do"}


def download(pk: str, dest: Path, which: int = 0) -> tuple[Path, dict]:
    info = page(pk)
    if dest.is_file() and dest.stat().st_size > 0:
        return dest, info
    if not info["downloads"]:
        raise RuntimeError(f"{pk}: 다운로드 버튼 없음")
    ppk, dpk, atch, sn, hist = info["downloads"][which]
    data = urllib.parse.urlencode({"publicDataDetailPk": dpk, "publicDataPk": ppk, "atchFileId": atch,
                                   "fileDetailSn": sn, "publicDataTyCode": "PR0051"}).encode()
    req = urllib.request.Request(f"{BASE}/tcs/dss/selectFileDataDownload.do", data=data,
                                 headers={"User-Agent": "Mozilla/5.0", "X-Requested-With": "XMLHttpRequest"})
    with urllib.request.urlopen(req, timeout=120) as r:
        j = json.loads(r.read().decode("utf-8"))
    if not j.get("status"):
        raise RuntimeError(f"{pk}: {j.get('error') or j}")
    info["atchFileId"], info["fileDetailSn"] = j.get("atchFileId"), j.get("fileDetailSn")
    info["file_name"] = (j.get("dataSetFileDetailInfo") or {}).get("dataNm") or (j.get("dataSetFileDetailInfo") or {}).get("publicDataSj")
    body = net.get(f"{BASE}/cmm/cmm/fileDownload.do", {"atchFileId": j["atchFileId"], "fileDetailSn": j["fileDetailSn"]},
                   cache_ns="filedata", binary=True, cache_name=f"{pk}_{j['atchFileId']}_{j['fileDetailSn']}", timeout=600)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(body)
    return dest, info


def search(keyword: str, max_pages: int = 3, per_page: int = 40) -> list[dict]:
    """Portal dataset search (fileData only): [{pk, title, provider}]"""
    out, seen = [], set()
    for pg in range(1, max_pages + 1):
        t = net.get(f"{BASE}/tcs/dss/selectDataSetList.do", {"dType": "FILE", "keyword": keyword, "currentPage": pg,
                    "perPage": per_page, "sort": "", "conditionType": "search"}, cache_ns="search")
        items = re.findall(r'href="/data/(\d+)/fileData\.do[^"]*"[^>]*>(.*?)</a>', t, re.S)
        got = 0
        for pk, inner in items:
            if pk in seen:
                continue
            seen.add(pk)
            title = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", inner)).strip()
            out.append({"pk": pk, "title": title})
            got += 1
        if got < 5:
            break
    return out


if __name__ == "__main__":
    if sys.argv[1] == "search":
        for r in search(" ".join(sys.argv[2:])):
            print(r["pk"], r["title"])
    else:
        print(json.dumps(page(sys.argv[1]), ensure_ascii=False, indent=1))
