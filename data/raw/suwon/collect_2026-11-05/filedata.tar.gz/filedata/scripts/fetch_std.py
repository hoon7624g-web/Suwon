"""Download the per-provider files of a standard dataset for every site: out/<slug>/raw/<sub>/ + manifest json."""
import json, sys, re
sys.path.insert(0, "/home/user/work/filedata/scripts")
from pathlib import Path
from sites import SITES, ROOT, provider_match
import stdfiles

def run(pk: str, sub: str, title: str, only=None):
    fs = stdfiles.list_files(pk)
    for slug in SITES:
        if only and slug not in only:
            continue
        m = [f for f in fs if provider_match(slug, f["provider"])]
        man = []
        for f in m:
            d = stdfiles.detail(f["dpk"])
            if not d.get("atchFileId"):
                man.append({**f, **d, "error": "다운로드 링크 없음"})
                continue
            key = re.sub(r"\s+", "_", f["provider"])
            dest = ROOT / "out" / slug / "raw" / sub / f"{pk}_{key}_{d['atchFileId']}.{(d.get('ext') or 'csv').lower()}"
            try:
                stdfiles.download(d["atchFileId"], d["fileDetailSn"] or "1", dest)
                man.append({**f, **d, "file": str(dest.relative_to(ROOT / "out" / slug)),
                            "download": f"https://www.data.go.kr/cmm/cmm/fileDownload.do?atchFileId={d['atchFileId']}&fileDetailSn={d['fileDetailSn'] or '1'}"})
            except Exception as e:
                man.append({**f, **d, "error": str(e)[:300]})
        out = ROOT / "out" / slug / "raw" / sub / "manifest.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps({"dataset": title, "pk": pk, "page": f"https://www.data.go.kr/data/{pk}/standard.do",
                                   "files": man}, ensure_ascii=False, indent=1), "utf-8")
        print(slug, [(x["provider"], x.get("rows"), x.get("modified"), x.get("license"), x.get("error", "ok")) for x in man])

if __name__ == "__main__":
    pk, sub, title = sys.argv[1], sys.argv[2], sys.argv[3]
    run(pk, sub, title, set(sys.argv[4:]) or None)
