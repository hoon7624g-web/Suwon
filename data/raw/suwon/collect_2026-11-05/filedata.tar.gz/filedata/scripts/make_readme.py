"""out/<slug>/README.md (one line per dataset) and out/README.md (all sites) from the collection's own records."""
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, CITY_LABEL

O = ROOT / "out"


def j(p, default=None):
    p = Path(p)
    return json.loads(p.read_text("utf-8")) if p.is_file() else default


def main():
    msum = j(ROOT / "cache" / "markets_summary.json", {})
    vsum = j(ROOT / "cache" / "visitors_summary.json", {})
    table = []
    for slug in SITES:
        o = O / slug
        L = [f"# {CITY_LABEL[slug]} ({slug}) — 파일·표준 공공데이터 모음 (2026-11-05)", "",
             "저장소에는 아무것도 쓰지 않았다. 아래 파일을 그 사이트 데이터 폴더에 옮기거나(patch_*는 places.json 해당 id의 필드를 바꿈) 버린다.",
             "형식: 데이터 — 출처 페이지 · 제공기관 · 기준일 · 이용허락(포털 표기) · 행 · 맞춘 수 · 못 맞춘 수 · 결과 파일", ""]
        row = {"slug": slug}
        # 1 parking
        nd = j(o / "nearby_diff.json", {})
        if nd:
            files = nd.get("files") or []
            dates = sorted({f.get("modified") or "" for f in files})
            lic = sorted({f.get("license") or "" for f in files})
            b, a = nd["before"], nd["after"]
            where = "candidate_existing_good/" if nd.get("existing_good") else ""
            L.append(f"- 전국주차장정보표준데이터 — https://www.data.go.kr/data/15012896/standard.do · "
                     f"{', '.join(f['provider'] for f in files) or '제공 파일 없음'} · 기준일(파일 수정일) {', '.join(dates) or '-'} · "
                     f"{', '.join(lic) or '-'} · 원본 {sum(f.get('rows') or 0 for f in files)}행 → 좌표·지역 맞는 {nd['lots']['rows_kept']}행, 근처 목록용 공영 {nd['lots']['usable']}곳 "
                     f"(제외 {nd['lots']['excluded']}, 버림 {nd['lots']['dropped']}) · 공개 장소 근처 주차 {b['parking']}→{a['parking']}곳 "
                     f"({b['parking_pct']}%→{a['parking_pct']}%) · 근처 주차장 없는 공개 장소 {a['published'] - a['parking']}곳 · "
                     f"{where}parking_lots.json, {where}nearby.json, nearby_diff.json")
            st = nd["stops"]
            L.append(f"- 버스 정류장 — {' · '.join(st['sources']) or '없음'} · 기준일 "
                     f"{', '.join(str(x.get('data_reference_date')) for x in (j(o / (where or '.') / 'nearby.json', {}).get('_meta', {}).get('bus', {}).get('files') or []))} · "
                     f"이용허락범위 제한 없음(서울은 공공누리 제1유형) · 정류장 {st['rows']}행(좌표 공유 {st['placeholder_dropped']}행 제외) · "
                     f"공개 장소 근처 정류장 {b['bus']}→{a['bus']}곳 ({b['bus_pct']}%→{a['bus_pct']}%) · 없는 곳 {a['published'] - a['bus']}곳 · "
                     f"{where}nearby.json(bus, 노선 번호 없음)")
            if nd.get("vs_existing_lots"):
                v = nd["vs_existing_lots"]
                L.append(f"  - 기존 parking_lots.json과 비교: 기존 {v['existing']} · 후보 {v['candidate']} · 후보에만 {v['only_candidate']} · 기존에만 {v['only_existing']}")
            row["parking"] = f"{b['parking_pct']}→{a['parking_pct']}%"
            row["bus"] = f"{b['bus_pct']}→{a['bus_pct']}%"
        # 3 markets
        ml = j(o / "raw" / "markets" / "market_links.json", {"links": [], "unlinked": []})
        ms = msum.get(slug)
        if ms:
            L.append(f"- 온누리상품권 가맹점(3060079) — https://www.data.go.kr/data/3060079/fileData.do · 소상공인시장진흥공단 · 기준일 2026-07-31 · "
                     f"이용허락범위 제한 없음 · 이 지역 시장 가맹점 {ms['onnuri_rows']}행 · 시장 장소 {ms['markets']}곳에 연결(가게 {ms['shops']}곳) · "
                     f"못 맞춘 시장 모양 장소 {len(ml['unlinked'])}곳 · patch_market.json, raw/markets/onnuri_{slug}_20260731.csv, raw/markets/market_links.json")
            L.append(f"- 상가(상권)정보(15083033) — https://www.data.go.kr/data/15083033/fileData.do · 소상공인시장진흥공단 · 기준일 2026-09-30 · "
                     f"이용허락범위 제한 없음 · 시장 400m 안 행만 raw/markets/sangga_{slug}_markets_202609.csv · 주소가 붙은 가게 {ms['with_addr']}곳 · "
                     f"떡·한과 점포 카드 {ms['store_cards']}장")
            row["market"] = f"{ms['markets']}곳/가게 {ms['shops']}"
        else:
            L.append(f"- 온누리 가맹점·상가정보 — 시장 이름 장소가 없거나 온누리 명부와 맞는 시장 없음(시장 모양 장소 {len(ml['unlinked'])}곳) — 결과 없음")
            row["market"] = "0"
        L.append("- 행정안전부 인허가 식품 3종(즉석판매제조가공업·식품제조가공업·축산판매업) — 이 키는 세 서비스에 등록되지 않음 "
                 "(HTTP 403 SERVICE_KEY_IS_NOT_REGISTERED_ERROR, 2026-11-05) — 활용신청 뒤 다시 받는다(호출 0)")
        # 4/5 designations + hygiene
        ds = j(o / "designations_summary.json", {})
        hy = {k: v for k, v in ds.items() if v["use"] == "hygiene"}
        if hy:
            for k, v in hy.items():
                L.append(f"- 식품안심업소(위생등급) 시·구 파일 {k} — {v['url']} · {v['provider']} · 기준일 {v['base_date']} · {v['license']} · "
                         f"{v['rows']}행 · 음식점 {v['high']}곳 맞춤 · 넣은 곳 {v['added']} · patch_hygiene.json (지정 종료일이 없는 행은 엔진이 표시하지 않음)")
        L.append("- 식품안심업소 전국(15060883, 식품안전나라 C004) — 포털 API 유형 LINK(식품안전나라 키 필요), data.go.kr 키로 HTTP 503, "
                 "www.foodsafetykorea.go.kr 연결 끊김 — 전국 파일을 받지 못함" + (" (이 지역은 시·구 파일만)" if hy else ""))
        for k, v in ds.items():
            if v["use"] == "hygiene":
                continue
            L.append(f"- 지정 {v['type']} ({k}) — {v['url']} · {v['provider']} · 기준일 {v['base_date']} · {v['license']} · "
                     f"이 지역 {v['rows']}행 · high {v['high']} · 새로 넣음 {v['added']} · 같은 지정 이미 있음 {v['already_had_type']} · "
                     f"못 맞춤 {v['rows'] - v['high']}(그중 비슷한 후보 {v['near']}·두 곳에 걸림 {v['ambiguous']}) · "
                     f"{'대조만(crosscheck) · ' if v['use'] == 'crosscheck' else ''}patch_designations.json")
        row["designations"] = sum(v["added"] for v in ds.values() if v["use"] != "hygiene")
        row["hygiene"] = sum(v["added"] for v in ds.values() if v["use"] == "hygiene")
        # 6 visitors
        vs = vsum.get(slug)
        if vs:
            L.append(f"- 관광지점 월별 관광객 — " + ", ".join(sorted({x['visitors']['source']['url'] for x in j(o / 'patch_visitors.json', {'places': {}})['places'].values()} |
                                                           {s['visitors']['source']['url'] for s in j(o / 'patch_visitors_review.json', {'spots': []})['spots']})) +
                     f" · 관광지점 {vs['spots']} · 맞춤 {vs['matched']} · 이름이 달라 사람 확인 {vs['review']} · patch_visitors.json, patch_visitors_review.json")
            row["visitors"] = vs["matched"]
        else:
            L.append("- 관광지점 월별 관광객 — 이 시·군의 월별·지점별 파일을 찾지 못함(연별·시 전체 합계뿐이거나 없음)")
            row["visitors"] = 0
        # 7 report only
        sr = j(o / "std_report.json")
        if sr:
            t, f, w = sr["tourist"], sr["festival"], sr["toilet"]
            L.append(f"- (분석) 전국관광지정보표준데이터 15021141 — 제공 {len(t['files'])}파일 · {t['rows']}행 · 장소에 없는 이름 {t['names_not_in_places']} (예: {', '.join(x[0] for x in t['examples'][:4])})")
            L.append(f"- (분석) 전국문화축제표준데이터 15013104 — 제공 {len(f['files'])}파일 · {f['rows']}행 · 2026-11-05 이후 끝나는 축제 {f['upcoming']} · 그중 events.json에 없는 이름 {f['upcoming_not_in_events']} "
                     f"(예: {', '.join(f'{x[0]}({x[1]})' for x in f['examples'][:4])})")
            L.append("- (분석) 전국공중화장실표준데이터 15012892 — 포털 표준데이터 목록에 제공기관 파일이 없음(자료가 지방행정 인허가 데이터 "
                     "localdata.go.kr/file/public_restroom_info로 옮겨짐, 행정안전부_공중화장실정보 15075531은 링크형 52,255행 2025-11-27). "
                     "localdata.go.kr 연결이 이 환경에서 끊겨 받지 못함 — 받으면 화장실명·개방시간·장애인 변기·기저귀 교환대·비상벨·좌표로 "
                     "'근처 공중화장실'을 만들 수 있다")
            row["std"] = f"관광지 {t['rows']}/{t['names_not_in_places']} · 축제 {f['rows']}/{f['upcoming_not_in_events']} "
        ss = j(o / "staged_summary.json")
        if ss:
            t, f, w, g = ss["tourist"], ss["festival"], ss["toilet"], ss["goodprice"]
            tr = j(o / "staged_tourist_spots.json", {"files": []})
            fr = j(o / "staged_festivals.json", {"files": []})
            wr = j(o / "staged_toilets.json", {"files": []})
            L.append("")
            L.append("## 모아 둔 자료(staged — 엔진 형식 아님, 행마다 provider·base_date)")
            L.append(f"- 전국관광지정보표준데이터 15021141 — https://www.data.go.kr/data/15021141/standard.do · "
                     f"{', '.join(x['provider'] + '(' + str(x['modified']) + ')' for x in tr['files']) or '이 지역 제공 파일 없음'} · "
                     f"{', '.join(sorted({x['license'] or '' for x in tr['files']})) or '-'} · {t['rows']}행 · 장소에 맞춤 {t['linked']} · 못 맞춤 {t['rows'] - t['linked']} · "
                     "staged_tourist_spots.json (표준데이터 API tn_pubr_public_trrsrt_api는 이 키로 HTTP 403 SERVICE_KEY_IS_NOT_REGISTERED_ERROR → 파일)")
            L.append(f"- 전국문화축제표준데이터 15013104 — https://www.data.go.kr/data/15013104/standard.do · "
                     f"{', '.join(x['provider'] + '(' + str(x['modified']) + ')' for x in fr['files']) or '이 지역 제공 파일 없음'} · "
                     f"{', '.join(sorted({x['license'] or '' for x in fr['files']})) or '-'} · {f['rows']}행 · events.json에 맞춤 {f['linked']} · 못 맞춤 {f['rows'] - f['linked']} · "
                     f"2026-11-05 이후 끝나는 축제 {f['upcoming']}(그중 events.json에 없음 {f['upcoming_unlinked']}) · staged_festivals.json (API tn_pubr_public_cltur_fstvl_api 403 → 파일)")
            if wr["files"]:
                L.append("- 공중화장실 — " + "; ".join(f"{x['dataset']} {x['page']} · {x['provider']} · 기준일 {x['base_date']} · {x['license']} · 이 지역 {x['rows_in_site']}행"
                                                     for x in wr["files"]) +
                         f" · 합계 {w['rows']}행(좌표 {w['with_point']}) · 300m 안에 화장실이 있는 공개 장소 {w['places_with_toilet_300m']}곳 · staged_toilets.json")
            else:
                L.append("- 공중화장실 — 이 지역 시·구 파일 없음(서울 15146086·강원 15160229는 링크형, 전국은 localdata.go.kr 연결 끊김, 표준데이터 API 403)")
            L.append(f"- 행정안전부 착한가격업소 메뉴·가격 — https://www.data.go.kr/data/3045247/fileData.do · 행정안전부 · 기준일 2026-09-30 · 이용허락범위 제한 없음 · "
                     f"이 지역 {g['rows']}행(메뉴 있는 행 {g['with_menu']}) · 장소에 맞춤 {g['linked']} · 못 맞춤 {g['rows'] - g['linked']}(미용·세탁 등 비음식 업종 포함) · "
                     "staged_goodprice_menus.json (자동변환 API api.odcloud.kr: HTTP 401 {\"code\":-4,\"msg\":\"등록되지 않은 인증키 입니다.\"} → 파일)")
        (o / "README.md").write_text("\n".join(L) + "\n", "utf-8")
        table.append(row)
    keys = ["slug", "parking", "bus", "market", "designations", "hygiene", "visitors", "std"]
    T = ["# 파일·표준 공공데이터 모음 (19곳, 2026-11-05)", "",
         "사이트마다 out/<slug>/README.md에 데이터별 한 줄(출처·기준일·이용허락·행·맞춘 수). 만든 도구는 /home/user/work/filedata/scripts/.",
         "", "| " + " | ".join(["사이트", "근처 주차(공개 장소)", "근처 정류장", "시장(온누리)", "새 지정", "위생(시·구 파일)", "월별 관광객", "보고만(관광지 행/장소에 없는 이름 · 축제 행/예정인데 events.json에 없음)"]) + " |",
         "|" + "---|" * len(keys)]
    for r in table:
        T.append("| " + " | ".join(str(r.get(k, "")) for k in keys) + " |")
    val = j(ROOT / "cache" / "validation.json", {})
    T += ["", "## 검증(임시 사본에 적용 → 그 저장소 폴더에서 pipeline.build/validate --mode preview, 저장소는 읽기만)"]
    for s, v in val.items():
        T.append(f"- {s}: 적용 {v['applied']} · build {v['build']} · validate {v['validate']} · 번역표 단위 {v['intl']}")
    T += ["- 주의: pipeline.validate가 기본값으로 그 저장소의 reports/qa_report.md(.gitignore 대상)를 덮어쓴다 — 사본은 validate/<slug>/qa_report.md",
          "", "## 다시 돌리기", "- `bash /home/user/work/filedata/scripts/run_all.sh` — 모두 cache/에서 이어 감(키는 scratchpad .datakey를 net.py가 읽고 가림)",
          "- 행정안전부 인허가 식품 3종·표준데이터 API·착한가격업소 자동변환 API는 이 키에 활용신청이 없어 403/401 — 신청하면 같은 스크립트로 받는다",
          "- 식품안심업소 전국(C004)·공중화장실 전국(localdata.go.kr)·서울 공영주차장(OA-13122, 시트형)·강릉 시내버스 정류장은 받지 못함"]
    (O / "README.md").write_text("\n".join(T) + "\n", "utf-8")
    print("\n".join(T))


if __name__ == "__main__":
    main()
