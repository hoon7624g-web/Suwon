"""Copy a site's data dir to /home/user/work/filedata/validate/<slug>/data/<slug> and apply this collection's outputs
(never touches the repo). Usage: apply_to_copy.py <slug> [--nearby]"""
import json, shutil, sys
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import ROOT, data_dir

slug = sys.argv[1]
use_nearby = "--nearby" in sys.argv
src = data_dir(slug)
base = ROOT / "validate" / slug
dst = base / "data" / slug
if base.exists():
    shutil.rmtree(base)
shutil.copytree(src, dst, ignore=shutil.ignore_patterns("cache"))
o = ROOT / "out" / slug
places = json.loads((dst / "places.json").read_text("utf-8"))
by = {p["id"]: p for p in places}
done = {}
for name, field in (("patch_designations.json", "designations"), ("patch_market.json", "market"),
                    ("patch_visitors.json", "visitors")):
    f = o / name
    if not f.is_file():
        continue
    patch = json.loads(f.read_text("utf-8"))["places"]
    n = 0
    for pid, v in patch.items():
        if pid in by:
            by[pid][field] = v[field]
            n += 1
    done[field] = n
(dst / "places.json").write_text(json.dumps(places, ensure_ascii=False, indent=2) + "\n", "utf-8")
if use_nearby and (o / "nearby.json").is_file():
    shutil.copy(o / "parking_lots.json", dst / "parking_lots.json")
    shutil.copy(o / "nearby.json", dst / "nearby.json")
    done["nearby"] = True
print(json.dumps({"slug": slug, "copy": str(dst), "applied": done}, ensure_ascii=False))
