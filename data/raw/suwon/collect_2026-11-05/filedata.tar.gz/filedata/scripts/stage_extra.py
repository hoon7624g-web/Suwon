"""Staged data (operator 2026-11-05 '최대한 다 긁어모아'): 전국관광지정보표준데이터, 전국문화축제표준데이터, 공중화장실 files and
행정안전부 착한가격업소 menus/prices for every site — every row with its provider and 기준일, linked to a place id (or an
events.json id) only when the link is unique and exact. Nothing here is in an engine format; it is staged for a person.

    python3 -I stage_extra.py [slug ...]

Links
- tourist spot → place: the normalized name (brackets, spaces, the city word and a trailing '관광지' dropped) equals one
  place's name the same way, and when both have points they are within 2 km. Else no link.
- festival → events.json: the normalized name (제n회, years, brackets, spaces dropped) equals one event's; else none.
- toilet → places: the published places within 300 m (nearest 5, straight line) — a toilet is not a place.
- 착한가격업소 row → place: Daegu tools/import_designations_daegu.py high match (same rule as the designations).
"""
from __future__ import annotations
import csv, io, json, math, re, sys, shutil, importlib.util, collections
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, data_dir, in_region, REGION, CITY_LABEL
import stdfiles

sys.path.insert(0, "/home/user/Daegu")
spec = importlib.util.spec_from_file_location("imd", "/home/user/Daegu/tools/import_designations_daegu.py")
imd = importlib.util.module_from_spec(spec)
sys.modules["imd"] = imd
spec.loader.exec_module(imd)

TODAY = "2026-11-05"
KTO_FESTIVAL = Path("/home/user/work/filedata/downloads/festival_kto_15013104.csv")
T = Path("/home/user/work/filedata/downloads/toilets")
CITY_WORDS = {"daegu": ["대구"], "haenam": ["해남"], "sejong": ["세종"], "yeongju": ["영주"], "gangneung": ["강릉"],
              "jeju": ["제주", "서귀포"], "yeosu": ["여수"], "jeonju": ["전주"], "chuncheon": ["춘천"], "yongin": ["용인"],
              "gyeongju": ["경주"], "busan": ["부산"], "suwon": ["수원"], "sokcho": ["속초"], "danyang": ["단양"],
              "mokpo": ["목포"], "incheon": ["인천"], "gapyeong": ["가평"], "jongno": ["서울", "종로"]}
# toilet files: (pk, sites, columns {name, addr, lat, lng, hours, phone, kind})
TOILETS = [
    ("15110521", ["jeju"], {"name": "화장실 명", "addr": "도로명 주소", "addr2": "지번 주소", "lat": "위도 좌표", "lng": "경도 좌표",
                            "hours": "개방 시간 정보", "phone": "전화번호", "kind": "구분 명"}),
    ("15134318", ["jeonju"], {"name": "화장실명", "addr": "소재지주소", "lat": "위도", "lng": "경도", "hours": "개방시간", "kind": "구분"}),
    ("15071405", ["incheon"], {"name": "명칭", "addr": "도로명주소", "addr2": "지번주소", "lat": "위도", "lng": "경도", "kind": "구분"}),
    ("15102495", ["incheon"], {"name": "화장실명", "addr": "소재지도로명주소", "addr2": "소재지지번주소", "hours": "개방시간", "phone": "전화번호"}),
    ("15090817", ["incheon"], {"name": "화장실명", "addr": "소재지도로명주소", "addr2": "소재지지번주소", "lat": "위도", "lng": "경도",
                               "hours": "개방시간", "phone": "전화번호", "kind": "구분"}),
    ("15087382", ["incheon"], {"name": "화장실명", "addr2": "지번주소", "lat": "위도", "lng": "경도", "kind": "구분"}),
    ("15060017", ["yongin"], {"name": "시설명", "addr": "시설주소", "kind": "시설유형명"}),
    ("15039413", ["yeongju", "gyeongju"], {"name": "화장실명", "addr2": "소재지지번주소"}),
]


def sq(v):
    return " ".join(str(v or "").split())


def metres(a, b):
    k = math.pi / 180
    x = (b[1] - a[1]) * k * math.cos((a[0] + b[0]) / 2 * k)
    return 6371000 * math.hypot(x, (b[0] - a[0]) * k)


def pt(r, lat, lng):
    try:
        a, b = float(r.get(lat) or ""), float(r.get(lng) or "")
        return (a, b) if 30 < a < 40 and 120 < b < 135 else None
    except ValueError:
        return None


def norm_place(s, words):
    s = re.sub(r"\(.*?\)|\[.*?\]", "", s or "")
    s = re.sub(r"[\s\W_]+", "", s)
    for w in sorted(words, key=len, reverse=True):
        for pre in (w + "시", w + "군", w):
            if s.startswith(pre) and len(s) - len(pre) >= 2:
                s = s[len(pre):]
                break
    return re.sub(r"(국민)?관광지$", "", s) or s


def norm_event(s):
    s = re.sub(r"\(.*?\)|\[.*?\]|제\s*\d+\s*회|\d{4}\s*년?|\d+\s*회", "", s or "")
    return re.sub(r"[\s\W_]+", "", s)


def std_rows(slug, sub):
    f = ROOT / "out" / slug / "raw" / sub / "manifest.json"
    out, files = [], []
    if f.is_file():
        man = json.loads(f.read_text("utf-8"))
        for x in man["files"]:
            if x.get("error"):
                continue
            files.append({"provider": x["provider"], "modified": x.get("modified"), "license": x.get("license"),
                          "rows": x.get("rows"), "download": x.get("download"), "raw": x["file"]})
            for r in csv.DictReader(io.StringIO(stdfiles.decode((ROOT / "out" / slug / x["file"]).read_bytes()))):
                out.append({**{k: sq(v) for k, v in r.items()}, "_provider": x["provider"], "_file_modified": x.get("modified")})
    return out, files


def addr_of(r):
    return r.get("소재지도로명주소") or r.get("소재지지번주소") or ""


def tourist(slug, places):
    rows, files = std_rows(slug, "std_tourist")
    words = CITY_WORDS[slug]
    idx = collections.defaultdict(list)
    for p in places:
        if p.get("kind") == "attraction":
            idx[norm_place(p["name"], words)].append(p)
    out = []
    for r in rows:
        a = addr_of(r)
        if a and not in_region(slug, a):
            continue
        hits = idx.get(norm_place(r.get("관광지명"), words)) or []
        link, basis = None, ""
        rp = pt(r, "위도", "경도")
        if len(hits) == 1:
            g = hits[0].get("geo") or {}
            pp = (float(g["lat"]), float(g["lng"])) if g.get("lat") else None
            if rp and pp:
                d = round(metres(rp, pp))
                if d <= 2000:
                    link, basis = hits[0]["id"], f"name+{d}m"
            elif a:
                link, basis = hits[0]["id"], "name+address in site"
        out.append({"row": r, "place_id": link, "basis": basis, "base_date": r.get("데이터기준일자") or r["_file_modified"],
                    "provider": r["_provider"]})
    return {"dataset": "전국관광지정보표준데이터", "page": "https://www.data.go.kr/data/15021141/standard.do",
            "license_note": "포털 표기 그대로(파일마다): " + "; ".join(sorted({f"{f['provider']} '{f['license']}'" for f in files})),
            "files": files, "rows": out}


def festival(slug, events):
    rows, files = std_rows(slug, "std_festival")
    kto = [{**{k: sq(v) for k, v in r.items()}, "_provider": "한국관광공사", "_file_modified": "2026-09-30"}
           for r in csv.DictReader(io.StringIO(stdfiles.decode(KTO_FESTIVAL.read_bytes())))]
    kto = [r for r in kto if in_region(slug, addr_of(r))]
    if kto:
        files.append({"provider": "한국관광공사", "modified": "2026-09-30", "license": "이용허락범위 제한 없음", "rows": len(kto),
                      "download": "https://www.data.go.kr/cmm/cmm/fileDownload.do?atchFileId=FILE_000000007688466&fileDetailSn=1",
                      "raw": "downloads/festival_kto_15013104.csv (이 지역 행만 아래 rows에)"})
    idx = collections.defaultdict(list)
    for e in events:
        n = norm_event(e.get("name") or e.get("title") or "")
        if n:
            idx[n].append(e)
    out = []
    for r in rows + kto:
        a = addr_of(r)
        if a and not in_region(slug, a):
            continue
        hits = idx.get(norm_event(r.get("축제명"))) or []
        out.append({"row": r, "event_id": hits[0].get("id") if len({h.get("id") for h in hits}) == 1 else None,
                    "event_ids_same_name": [h.get("id") for h in hits] if len(hits) > 1 else [],
                    "base_date": r.get("데이터기준일자") or r["_file_modified"], "provider": r["_provider"],
                    "upcoming": (r.get("축제종료일자") or "") >= TODAY})
    return {"dataset": "전국문화축제표준데이터", "page": "https://www.data.go.kr/data/15013104/standard.do",
            "license_note": "포털 표기 그대로(파일마다): " + "; ".join(sorted({f"{f['provider']} '{f['license']}'" for f in files})),
            "files": files, "rows": out}


def toilets(slug, places):
    pub = [(p["id"], (float(p["geo"]["lat"]), float(p["geo"]["lng"]))) for p in places
           if p.get("status") == "published" and (p.get("geo") or {}).get("lat")]
    files, out = [], []
    for pk, sites, c in TOILETS:
        if slug not in sites:
            continue
        meta = json.loads((T / f"{pk}.json").read_text("utf-8"))
        rows = list(csv.DictReader(io.StringIO(stdfiles.decode((T / f"{pk}.bin").read_bytes()))))
        bd = re.search(r"_(\d{8})$", meta["name"])
        base = f"{bd.group(1)[:4]}-{bd.group(1)[4:6]}-{bd.group(1)[6:]}" if bd else meta["modified"]
        n = 0
        for r in rows:
            a = sq(r.get(c.get("addr", ""))) or sq(r.get(c.get("addr2", "")))
            if pk in ("15134318", "15039413") and not (in_region(slug, a) or REGION[slug][1] and REGION[slug][1] in a):
                continue
            p = pt(r, c.get("lat", ""), c.get("lng", ""))
            near = sorted(((round(metres(p, q)), pid) for pid, q in pub if abs(p[0] - q[0]) < 0.004 and abs(p[1] - q[1]) < 0.005), key=lambda x: x[0]) if p else []
            near = [{"place_id": pid, "meters": m} for m, pid in near if m <= 300][:5]
            out.append({"name": sq(r.get(c["name"])), "kind": sq(r.get(c.get("kind", ""))), "address": a,
                        "lat": p[0] if p else None, "lng": p[1] if p else None, "hours": sq(r.get(c.get("hours", ""))),
                        "phone": sq(r.get(c.get("phone", ""))), "near_places": near,
                        "provider": meta["provider"], "base_date": base, "row": {k: sq(v) for k, v in r.items()}})
            n += 1
        files.append({"pk": pk, "dataset": meta["name"], "provider": meta["provider"], "base_date": base,
                      "license": meta["license"], "page": f"https://www.data.go.kr/data/{pk}/fileData.do", "rows_in_site": n})
        raw = ROOT / "out" / slug / "raw" / "toilets"
        raw.mkdir(parents=True, exist_ok=True)
        shutil.copy(T / f"{pk}.bin", raw / f"{pk}.csv")
    return {"dataset": "공중화장실(시·구·도 파일 — 전국공중화장실표준데이터는 localdata.go.kr로 옮겨져 받지 못함)", "files": files, "rows": out}


def goodprice(slug):
    raw = ROOT / "out" / slug / "raw" / "designations"
    man = json.loads((raw / "sources.json").read_text("utf-8"))
    lists = [l for l in man["lists"] if l["key"] == "goodprice_mois"]
    tmp = ROOT / "cache" / "gp_tmp" / slug
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    shutil.copy(raw / lists[0]["file"], tmp / lists[0]["file"])
    (tmp / "sources.json").write_text(json.dumps({"checked_at": TODAY, "lists": lists}, ensure_ascii=False), "utf-8")
    res = imd.run(data_dir(slug), tmp)
    src, rows, matches = res["results"]["goodprice_mois"]
    out = []
    for m in matches:
        c = m["row"].cells
        menus = [{"menu": sq(c.get(f"메뉴{i}")), "price": sq(c.get(f"가격{i}"))} for i in range(1, 5) if sq(c.get(f"메뉴{i}"))]
        pid = m["high"][0][0].e["id"] if len(m["high"]) == 1 else None
        out.append({"name": m["row"].name, "kind": sq(c.get("업종")), "address": m["row"].raw_address,
                    "sido": sq(c.get("시도")), "sigun": sq(c.get("시군")), "menus": menus, "place_id": pid,
                    "basis": m["high"][0][1] if pid else "", "near_candidates": [x[0].e["id"] for x in m["near"]][:3],
                    "ambiguous": len(m["high"]) > 1})
    return {"dataset": "행정안전부_착한가격업소 현황_20260930 (파일 — 메뉴1~4·가격1~4)", "page": "https://www.data.go.kr/data/3045247/fileData.do",
            "provider": "행정안전부", "base_date": "2026-09-30", "license": "이용허락범위 제한 없음",
            "api_note": "자동변환 OpenAPI(api.odcloud.kr/api/3045247/v1/…)는 이 키로 HTTP 401 {\"code\":-4,\"msg\":\"등록되지 않은 인증키 입니다.\"} "
                        "(2026-11-05) — 같은 값이 든 파일을 썼다", "rows": out}


def run(slug):
    d = data_dir(slug)
    places = json.loads((d / "places.json").read_text("utf-8"))
    evf = d / "events.json"
    ev = json.loads(evf.read_text("utf-8")) if evf.is_file() else []
    ev = ev if isinstance(ev, list) else ev.get("events") or []
    o = ROOT / "out" / slug
    res = {"tourist": tourist(slug, places), "festival": festival(slug, ev), "toilet": toilets(slug, places),
           "goodprice": goodprice(slug)}
    names = {"tourist": "staged_tourist_spots.json", "festival": "staged_festivals.json", "toilet": "staged_toilets.json",
             "goodprice": "staged_goodprice_menus.json"}
    summ = {}
    for k, v in res.items():
        (o / names[k]).write_text(json.dumps(v, ensure_ascii=False, indent=1) + "\n", "utf-8")
        rows = v["rows"]
        if k == "tourist":
            summ[k] = {"rows": len(rows), "linked": sum(1 for r in rows if r["place_id"])}
        elif k == "festival":
            summ[k] = {"rows": len(rows), "linked": sum(1 for r in rows if r["event_id"]), "upcoming": sum(1 for r in rows if r["upcoming"]),
                       "upcoming_unlinked": sum(1 for r in rows if r["upcoming"] and not r["event_id"])}
        elif k == "toilet":
            summ[k] = {"rows": len(rows), "with_point": sum(1 for r in rows if r["lat"]),
                       "places_with_toilet_300m": len({x["place_id"] for r in rows for x in r["near_places"]}),
                       "files": [f["pk"] for f in v["files"]]}
        else:
            summ[k] = {"rows": len(rows), "with_menu": sum(1 for r in rows if r["menus"]), "linked": sum(1 for r in rows if r["place_id"])}
    (o / "staged_summary.json").write_text(json.dumps(summ, ensure_ascii=False, indent=1), "utf-8")
    print(slug, json.dumps(summ, ensure_ascii=False))
    return summ


if __name__ == "__main__":
    allsum = {}
    for s in (sys.argv[1:] or list(SITES)):
        allsum[s] = run(s)
    if not sys.argv[1:]:
        (ROOT / "cache" / "staged_summary.json").write_text(json.dumps(allsum, ensure_ascii=False, indent=1), "utf-8")
