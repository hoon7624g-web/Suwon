"""Network helpers: key from the scratchpad file (never printed), cached GETs under cache/, key masked in errors."""
from __future__ import annotations
import hashlib, json, os, time, urllib.parse, urllib.request, urllib.error
from pathlib import Path

KEYFILE = Path("/tmp/claude-0/-home-user/ff6555e3-ee41-5b25-8f10-42343f844468/scratchpad/.datakey")
CACHE = Path("/home/user/work/filedata/cache")
CALLS = {"n": 0}


def key() -> str:
    k = os.environ.get("DATA_GO_KR_KEY", "").strip()
    if not k and KEYFILE.is_file():
        k = KEYFILE.read_text("utf-8").strip()
    k = k.strip('"').strip("'")
    if "%" in k:
        k = urllib.parse.unquote(k)
    return k.split("=", 1)[1] if k.startswith(("DATA_GO_KR_KEY=", "TOURAPI_KEY=")) else k


def mask(s: str) -> str:
    k = key()
    if not k:
        return s
    for v in (k, urllib.parse.quote(k, safe=""), urllib.parse.quote_plus(k)):
        s = s.replace(v, "«KEY»")
    return s


def get(url: str, params: dict | None = None, *, cache_ns: str, use_key: bool = False, timeout: int = 120,
        retries: int = 4, binary: bool = False, cache_name: str | None = None, headers: dict | None = None):
    """GET with on-disk cache (cache/<ns>/<hash or name>); the key is added at call time only and never stored."""
    params = dict(params or {})
    ident = url + "?" + urllib.parse.urlencode(sorted(params.items()))
    name = cache_name or hashlib.sha1(ident.encode()).hexdigest()[:20]
    f = CACHE / cache_ns / name
    if f.is_file():
        return f.read_bytes() if binary else f.read_text("utf-8")
    q = dict(params)
    if use_key:
        q["serviceKey"] = key()
    full = url + ("?" + urllib.parse.urlencode(q) if q else "")
    req = urllib.request.Request(full, headers={"User-Agent": "Mozilla/5.0 (filedata collector)", **(headers or {})})
    err = ""
    for i in range(retries):
        try:
            CALLS["n"] += 1
            with urllib.request.urlopen(req, timeout=timeout) as r:
                body = r.read()
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_bytes(body)
            return body if binary else body.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", "replace")[:400]
            err = mask(f"HTTP {e.code} {raw}")
            if e.code in (400, 401, 403, 404):
                break
        except Exception as e:  # noqa: BLE001
            err = mask(f"{type(e).__name__}: {e}")
        time.sleep(2 + 3 * i)
    raise RuntimeError(mask(f"{url}: {err}"))
