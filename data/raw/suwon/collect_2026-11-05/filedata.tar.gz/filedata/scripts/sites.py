"""Site table for file-data collection (read-only access to repos)."""
from pathlib import Path
SITES = {
 "daegu": "/home/user/Daegu", "haenam": "/home/user/haenam", "sejong": "/home/user/sejong",
 "yeongju": "/home/user/yeougju", "gangneung": "/home/user/gangneung", "jeju": "/home/user/jeju",
 "yeosu": "/home/user/yeosu", "jeonju": "/home/user/jeonju", "chuncheon": "/home/user/chuncheon",
 "yongin": "/home/user/yongin", "gyeongju": "/home/user/gyeongju", "busan": "/home/user/busan",
 "suwon": "/home/user/hoon7624g-web/suwon", "sokcho": "/home/user/sokcho", "danyang": "/home/user/danyang",
 "mokpo": "/home/user/mokpo", "incheon": "/home/user/incheon", "gapyeong": "/home/user/gapyeong",
 "jongno": "/home/user/jongno",
}
def data_dir(slug): return Path(SITES[slug]) / "data" / slug
ROOT = Path("/home/user/work/filedata")

# address filter per site: sido prefixes (old and new names) and the city/구 name (None = the whole 시·도)
REGION = {
 "daegu":    (("대구광역시", "대구시", "대구", "경상북도 군위군"), None),
 "haenam":   (("전남광주통합특별시", "전라남도", "전남"), "해남군"),
 "sejong":   (("세종특별자치시", "세종시", "세종"), None),
 "yeongju":  (("경상북도", "경북"), "영주시"),
 "gangneung":(("강원특별자치도", "강원도", "강원"), "강릉시"),
 "jeju":     (("제주특별자치도", "제주도", "제주"), None),
 "yeosu":    (("전남광주통합특별시", "전라남도", "전남"), "여수시"),
 "jeonju":   (("전북특별자치도", "전라북도", "전북"), "전주시"),
 "chuncheon":(("강원특별자치도", "강원도", "강원"), "춘천시"),
 "yongin":   (("경기도", "경기"), "용인시"),
 "gyeongju": (("경상북도", "경북"), "경주시"),
 "busan":    (("부산광역시", "부산시", "부산"), None),
 "suwon":    (("경기도", "경기"), "수원시"),
 "sokcho":   (("강원특별자치도", "강원도", "강원"), "속초시"),
 "danyang":  (("충청북도", "충북"), "단양군"),
 "mokpo":    (("전남광주통합특별시", "전라남도", "전남"), "목포시"),
 "incheon":  (("인천광역시", "인천시", "인천"), None),
 "gapyeong": (("경기도", "경기"), "가평군"),
 "jongno":   (("서울특별시", "서울시", "서울"), "종로구"),
}
# short sido label as used in 온누리 '소재지' and MFDS INSTT_CD_NM ('전북', '경북' …)
SIDO_SHORT = {"daegu": "대구", "haenam": "전남", "sejong": "세종", "yeongju": "경북", "gangneung": "강원", "jeju": "제주",
              "yeosu": "전남", "jeonju": "전북", "chuncheon": "강원", "yongin": "경기", "gyeongju": "경북", "busan": "부산",
              "suwon": "경기", "sokcho": "강원", "danyang": "충북", "mokpo": "전남", "incheon": "인천", "gapyeong": "경기",
              "jongno": "서울"}
CITY_LABEL = {"daegu": "대구광역시", "haenam": "해남군", "sejong": "세종특별자치시", "yeongju": "영주시", "gangneung": "강릉시",
              "jeju": "제주특별자치도", "yeosu": "여수시", "jeonju": "전주시", "chuncheon": "춘천시", "yongin": "용인시",
              "gyeongju": "경주시", "busan": "부산광역시", "suwon": "수원시", "sokcho": "속초시", "danyang": "단양군",
              "mokpo": "목포시", "incheon": "인천광역시", "gapyeong": "가평군", "jongno": "종로구"}
import re as _re
def in_region(slug: str, addr: str) -> bool:
    """True when an address is in the site's area (sido prefix, and the city/구 when the site is one city)."""
    a = " ".join(str(addr or "").split())
    pre, city = REGION[slug]
    if slug == "daegu" and ("군위군" in a and (a.startswith("경상북도") or a.startswith("경북") or a.startswith("대구"))):
        return True
    if not any(a.startswith(p) for p in pre):
        # some files write the city alone ('강릉시 …')
        return bool(city) and a.startswith(city + " ")
    if city is None:
        return True
    rest = a
    for p in sorted(pre, key=len, reverse=True):
        if rest.startswith(p):
            rest = rest[len(p):].strip()
            break
    return rest.startswith(city)

def provider_match(slug: str, provider: str) -> bool:
    """A standard-data file provider that may hold rows of the site: the city (or a 구·군 of it), or the 시·도."""
    p = " ".join(provider.split())
    pre, city = REGION[slug]
    sido = [x for x in pre if len(x) > 3]
    if city is None:
        return any(p.startswith(s) for s in sido) or (slug == "daegu" and "군위군" in p)
    return city in p or p in sido
