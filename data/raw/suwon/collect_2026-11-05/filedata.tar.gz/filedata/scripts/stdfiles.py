"""List and download per-provider files of a data.go.kr standard dataset (no key needed; public file downloads)."""
from __future__ import annotations
import json, re, sys, urllib.parse
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
import net

BASE = "https://www.data.go.kr"


def list_files(pk: str, keyword: str = "", max_pages: int = 80) -> list[dict]:
    out, seen = [], set()
    for page in range(1, max_pages + 1):
        t = net.get(f"{BASE}/tcs/dss/stdFileList.do", {"publicDataPk": pk, "searchKeyword2": keyword, "pageIndex": page},
                    cache_ns=f"stdlist/{pk}")
        rows = re.findall(r'<tr>(.*?)</tr>', t, re.S)
        got = 0
        for r in rows:
            cells = [re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", c)).strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", r, re.S)]
            m = re.search(r'data-public-pk="([^"]+)"', r)
            if not m or m.group(1) in seen:
                continue
            seen.add(m.group(1))
            got += 1
            out.append({"name": cells[0] if cells else "", "provider": cells[1] if len(cells) > 1 else "",
                        "registered": cells[2] if len(cells) > 2 else "", "dpk": m.group(1)})
        nxt = re.findall(r"fn_page\((\d+)\)", t)
        if not got or not nxt or max(int(x) for x in nxt) <= page:
            break
    return out


def detail(dpk: str) -> dict:
    t = net.get(f"{BASE}/tcs/dss/selectDpkDetailInfo.do", {"publicDataDetailPk": dpk}, cache_ns="stddetail")
    txt = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", t))
    m = re.search(r"fn_fileDataDown\('(\d+)',\s*'([^']+)',\s*'([^']+)',\s*'(\d+)',\s*'(\w+)'\)", t)
    def field(label):
        mm = re.search(label + r"\s+(.+?)\s{1,3}(?=[가-힣]+(?:\s[가-힣]+)?\s)", txt)
        return mm.group(1).strip() if mm else ""
    info = {"atchFileId": m.group(3) if m else "", "fileDetailSn": m.group(4) if m else "", "ext": m.group(5) if m else ""}
    for lab, key in (("제공기관", "provider"), ("수정일", "modified"), ("등록일", "registered"), ("전체 행 수", "rows"),
                     ("이용허락범위", "license"), ("업데이트 주기", "cycle")):
        mm = re.search(re.escape(lab) + r"\s+([^ ].*?)(?=\s(?:관리부서명|관리부서|업데이트 주기|차기|매체유형|전체 행 수|확장자|다운로드|등록일|수정일|데이터 다운로드|비용부과|이용허락범위|닫기))", txt)
        info[key] = mm.group(1).strip() if mm else ""
    return info


def download(atch: str, sn: str, dest: Path) -> Path:
    if dest.is_file() and dest.stat().st_size > 0:
        return dest
    body = net.get(f"{BASE}/cmm/cmm/fileDownload.do", {"atchFileId": atch, "fileDetailSn": sn}, cache_ns="stdfile",
                   binary=True, cache_name=f"{atch}_{sn}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(body)
    return dest


def decode(b: bytes) -> str:
    for enc in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("cp949", "replace")


if __name__ == "__main__":
    pk = sys.argv[1]
    kw = sys.argv[2] if len(sys.argv) > 2 else ""
    fs = list_files(pk, kw)
    print(len(fs))
    for f in fs[:400]:
        print(f["provider"], "|", f["name"], "|", f["registered"])
