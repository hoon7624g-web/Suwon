import json, sys, collections
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, data_dir
for slug in SITES:
    d = data_dir(slug)
    places = json.loads((d/"places.json").read_text("utf-8"))
    files = sorted(p.name for p in d.iterdir() if p.is_file())
    pub = [p for p in places if p.get("status") == "published"]
    geo = [p for p in pub if (p.get("geo") or {}).get("lat")]
    nb = {}
    if (d/"nearby.json").is_file():
        nb = json.loads((d/"nearby.json").read_text("utf-8"))
    nbp = sum(1 for p in pub if (nb.get(p["id"]) or {}).get("parking"))
    nbb = sum(1 for p in pub if (nb.get(p["id"]) or {}).get("bus"))
    inpl = sum(1 for p in pub if p.get("nearby"))
    lots = None
    if (d/"parking_lots.json").is_file():
        pl = json.loads((d/"parking_lots.json").read_text("utf-8"))
        lots = len(pl["lots"]) if isinstance(pl, dict) and "lots" in pl else (len(pl) if isinstance(pl, list) else "?")
    des = collections.Counter()
    for p in places:
        for x in p.get("designations") or []:
            des[(x.get("type") or x.get("key") or x.get("kind") or x.get("name") or str(x)[:20]) if isinstance(x, dict) else str(x)] += 1
    mk = sum(1 for p in places if p.get("market"))
    vis = sum(1 for p in places if p.get("visitors"))
    kinds = collections.Counter(p.get("kind") for p in pub)
    print(f"{slug}: places {len(places)} pub {len(pub)} geo {len(geo)} | nearby.json parking {nbp} bus {nbb} place.nearby {inpl} | lots {lots} | market {mk} visitors {vis}")
    print("   designations:", dict(des.most_common(12)))
    print("   files:", [f for f in files if any(k in f for k in ("nearby","parking","licen","transit","bus","stop","visit","market","designation"))])
