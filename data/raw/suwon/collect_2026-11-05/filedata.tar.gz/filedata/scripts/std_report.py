"""Report only (no data): 전국관광지정보표준데이터·전국문화축제표준데이터·전국공중화장실표준데이터 rows per site and what they
would add (tourist spots whose name no place has, festivals whose name no events.json record has, places with a public
toilet within 300 m). Output: out/<slug>/std_report.json and cache/std_report_summary.json."""
from __future__ import annotations
import csv, io, json, math, re, sys, collections
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, data_dir, in_region
import stdfiles

TODAY = "2026-11-05"


def norm(s):
    s = re.sub(r"\(.*?\)|\[.*?\]|제\s*\d+\s*회|\d{4}\s*년?", "", s or "")
    return re.sub(r"[\s\W_]+", "", s)


def metres(a, b):
    k = math.pi / 180
    x = (b[1] - a[1]) * k * math.cos((a[0] + b[0]) / 2 * k)
    return 6371000 * math.hypot(x, (b[0] - a[0]) * k)


def load(slug, sub):
    f = ROOT / "out" / slug / "raw" / sub / "manifest.json"
    if not f.is_file():
        return None, []
    man = json.loads(f.read_text("utf-8"))
    rows = []
    for x in man["files"]:
        if x.get("error"):
            continue
        t = stdfiles.decode((ROOT / "out" / slug / x["file"]).read_bytes())
        for r in csv.DictReader(io.StringIO(t)):
            r["_provider"] = x["provider"]
            r["_modified"] = x.get("modified")
            rows.append(r)
    return man, rows


def addr(r):
    for c in ("소재지도로명주소", "소재지지번주소", "개최장소"):
        if (r.get(c) or "").strip():
            return r[c]
    return ""


def run():
    summary = {}
    for slug in SITES:
        places = json.loads((data_dir(slug) / "places.json").read_text("utf-8"))
        evf = data_dir(slug) / "events.json"
        events = json.loads(evf.read_text("utf-8")) if evf.is_file() else []
        events = events if isinstance(events, list) else events.get("events") or []
        pnames = {norm(p["name"]) for p in places} | {norm(a) for p in places for a in p.get("alternate_names") or []}
        enames = {norm(e.get("name") or e.get("title") or "") for e in events}
        rep = {}
        man, rows = load(slug, "std_tourist")
        rows = [r for r in rows if not addr(r) or in_region(slug, addr(r)) or not r.get("소재지도로명주소")]
        new = [r for r in rows if norm(r.get("관광지명")) and norm(r.get("관광지명")) not in pnames
               and not any(norm(r.get("관광지명")) in pn or pn in norm(r.get("관광지명")) for pn in pnames if len(pn) >= 3)]
        rep["tourist"] = {"files": [(x["provider"], x.get("rows"), x.get("modified"), x.get("license")) for x in (man or {}).get("files", [])],
                          "rows": len(rows), "names_not_in_places": len(new),
                          "examples": [(r.get("관광지명"), r.get("관광지구분"), addr(r)) for r in new[:8]],
                          "fields": "관광지명·구분·주소·좌표·면적·공공편익시설·숙박·운동오락·휴양문화·접객시설·지원시설·지정일자·수용인원·주차가능수·관광지소개·관리기관 전화"}
        man, rows = load(slug, "std_festival")
        rows = [r for r in rows if in_region(slug, r.get("소재지도로명주소") or r.get("소재지지번주소") or "") or
                not (r.get("소재지도로명주소") or r.get("소재지지번주소"))]
        upcoming = [r for r in rows if (r.get("축제종료일자") or "") >= TODAY]
        miss = [r for r in rows if norm(r.get("축제명")) not in enames and not any(
            norm(r.get("축제명")) in en or en in norm(r.get("축제명")) for en in enames if len(en) >= 4)]
        miss_up = [r for r in miss if (r.get("축제종료일자") or "") >= TODAY]
        rep["festival"] = {"files": [(x["provider"], x.get("rows"), x.get("modified"), x.get("license")) for x in (man or {}).get("files", [])],
                           "rows": len(rows), "upcoming": len(upcoming), "not_in_events": len(miss),
                           "upcoming_not_in_events": len(miss_up),
                           "examples": [(r.get("축제명"), r.get("축제시작일자"), r.get("축제종료일자"), r.get("개최장소")) for r in
                                        (miss_up or miss)[:8]],
                           "latest_start": max((r.get("축제시작일자") or "" for r in rows), default="")}
        man, rows = load(slug, "std_toilet")
        pts = []
        for r in rows:
            try:
                ll = (float(r.get("WGS84위도") or r.get("위도")), float(r.get("WGS84경도") or r.get("경도")))
            except (TypeError, ValueError):
                continue
            a = r.get("소재지도로명주소") or r.get("소재지지번주소") or ""
            if a and not in_region(slug, a):
                continue
            pts.append(ll)
        grid = collections.defaultdict(list)
        for p in pts:
            grid[(int(p[0] * 200), int(p[1] * 200))].append(p)
        near = 0
        pub = [p for p in places if p.get("status") == "published" and (p.get("geo") or {}).get("lat")]
        for p in pub:
            ll = (float(p["geo"]["lat"]), float(p["geo"]["lng"]))
            a, b = int(ll[0] * 200), int(ll[1] * 200)
            if any(metres(ll, q) <= 300 for i in (-1, 0, 1) for j in (-1, 0, 1) for q in grid.get((a + i, b + j), [])):
                near += 1
        rep["toilet"] = {"files": [(x["provider"], x.get("rows"), x.get("modified"), x.get("license")) for x in (man or {}).get("files", [])],
                         "rows_with_point": len(pts), "published_places_with_toilet_300m": near, "published_with_geo": len(pub),
                         "fields": "화장실명·구분·주소·좌표·개방시간·남녀 변기 수·장애인 변기·기저귀 교환대·비상벨·CCTV·관리기관 전화"}
        (ROOT / "out" / slug / "std_report.json").write_text(json.dumps(rep, ensure_ascii=False, indent=1), "utf-8")
        summary[slug] = {"tourist": (rep["tourist"]["rows"], rep["tourist"]["names_not_in_places"]),
                         "festival": (rep["festival"]["rows"], rep["festival"]["upcoming"], rep["festival"]["upcoming_not_in_events"]),
                         "toilet": (rep["toilet"]["rows_with_point"], rep["toilet"]["published_places_with_toilet_300m"])}
        print(slug, summary[slug])
    (ROOT / "cache" / "std_report_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    run()
