"""place.visitors patches (Gunsan tools/visitors_gunsan.py format: {year, months[12], total, recent, source}) from city
files of monthly visitor counts. A spot joins a place only when the file's name, without brackets, spaces and the city
word in front, is the place's name the same way and only one place has it (exact); a near name ('교촌한옥마을' / '경주
교촌마을') goes to patch_visitors_review.json for a person, never into the patch.

Files: 인천 15119916 (monthly 2023–2024, 내국인·외국인 rows → summed per month), 경주 15162528 (monthly 2024-01~),
영주 15036430 소수서원 (daily → monthly sums of 무료+유료), 제주시 15048389 우도해양도립공원 ('입장객' rows),
서귀포시 15036619 천지연폭포 (monthly, the sum of the 입장객 kinds).
"""
from __future__ import annotations
import csv, io, json, re, sys, collections
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import ROOT, data_dir
import stdfiles

V = Path("/home/user/work/filedata/downloads/visitors")
TODAY = "2026-11-05"


def rows(pk):
    return list(csv.DictReader(io.StringIO(stdfiles.decode((V / f"{pk}.bin").read_bytes()))))


def meta(pk):
    return json.loads((V / f"{pk}.json").read_text("utf-8"))


def n(v):
    v = str(v or "").replace(",", "").strip()
    return int(float(v)) if re.fullmatch(r"\d+(\.0+)?", v) else None


def norm(s, city=()):
    s = re.sub(r"\(.*?\)", "", s or "")
    s = re.sub(r"[\s\W_]+", "", s)
    for c in city:
        if s.startswith(c) and len(s) > len(c) + 1:
            s = s[len(c):]
    return s


def series(by_year: dict[int, list]) -> dict | None:
    full = [y for y, ms in by_year.items() if all(x is not None for x in ms)]
    if not full:
        return None
    year = max(full)
    later = [y for y in by_year if y > year]
    recent = None
    if later:
        ry = max(later)
        got = [x for x in by_year[ry] if x is not None]
        through = max(i + 1 for i, x in enumerate(by_year[ry]) if x is not None) if got else 0
        recent = {"year": ry, "through": through, "total": sum(got)} if got else None
    return {"year": year, "months": by_year[year], "total": sum(by_year[year]), "recent": recent}


def source(pk, note=""):
    m = meta(pk)
    bd = re.search(r"_(\d{8})$", m["name"])
    s = {"provider": m["provider"], "dataset": m["name"], "url": f"https://www.data.go.kr/data/{pk}/fileData.do",
         "base_date": f"{bd.group(1)[:4]}-{bd.group(1)[4:6]}-{bd.group(1)[6:]}" if bd else m["modified"],
         "license": m["license"], "checked_at": TODAY}
    if note:
        s["note"] = note
    return s


def spots():
    """{slug: [(spot name, {year: [12]}, source, extra)]}"""
    out = collections.defaultdict(list)
    # 인천: 내국인·외국인 rows summed
    acc = collections.defaultdict(lambda: collections.defaultdict(lambda: [None] * 12))
    kinds = collections.defaultdict(set)
    for r in rows("15119916"):
        name = " ".join((r.get("관광지") or "").split())
        if not name:
            continue
        kinds[name].add(r["내외국인"])
        for k, v in r.items():
            m = re.match(r"(\d{4})년 (\d{2})월$", k or "")
            if m and n(v) is not None:
                y, mo = int(m.group(1)), int(m.group(2)) - 1
                cur = acc[name][y][mo]
                acc[name][y][mo] = (cur or 0) + n(v)
    for name, by in acc.items():
        out["incheon"].append((name, dict(by), source("15119916", "월별 값은 파일의 " + "·".join(sorted(kinds[name])) + " 행 합"),
                               {"series": "+".join(sorted(kinds[name]))}))
    # 경주
    by = collections.defaultdict(lambda: collections.defaultdict(lambda: [None] * 12))
    for r in rows("15162528"):
        y, mo = int(r["연월"][:4]), int(r["연월"][5:7]) - 1
        for spot in ("대릉원", "교촌한옥마을", "황리단길 권역"):
            if n(r.get(spot)) is not None:
                by[spot][y][mo] = n(r[spot])
    for spot, b in by.items():
        out["gyeongju"].append((spot, dict(b), source("15162528"), {}))
    # 영주 소수서원 (daily)
    b = collections.defaultdict(lambda: [None] * 12)
    days = collections.defaultdict(set)
    for r in rows("15036430"):
        y, mo = int(r["일자"][:4]), int(r["일자"][5:7]) - 1
        v = (n(r["입장객(무료)"]) or 0) + (n(r["입장객(유료)"]) or 0)
        b[y][mo] = (b[y][mo] or 0) + v
        days[(y, mo)].add(r["일자"])
    last = max(days)
    import calendar
    if len(days[last]) < calendar.monthrange(last[0], last[1] + 1)[1]:
        b[last[0]][last[1]] = None   # a month the file has not finished (2026-06: one day) is left out
    out["yeongju"].append(("소수서원", dict(b), source("15036430", "월별 값은 일별 입장객(무료+유료)의 월 합계"), {}))
    # 제주 우도
    b = {}
    for r in rows("15048389"):
        if r["구분"].strip() == "입장객":
            b[int(r["년도"])] = [n(r[f"{m}월"]) for m in range(1, 13)]
    out["jeju"].append(("우도해양도립공원", b, source("15048389", "'입장객' 행(차량 행 제외)"), {}))
    # 서귀포 천지연폭포
    b = collections.defaultdict(lambda: [None] * 12)
    cols = ["성인입장객", "청소년입장객", "어린이입장객", "경로입장객", "공문협조입장객", "국가유공자입장객", "도민입장객",
            "유아입장객", "장애인입장객", "기타"]
    for r in rows("15036619"):
        y, mo = int(r["년도"]), int(r["월별"]) - 1
        b[y][mo] = sum(n(r[c]) or 0 for c in cols)
    out["jeju"].append(("천지연폭포", dict(b), source("15036619", "월별 값은 입장객 구분(성인·청소년·어린이·경로·도민 등) 값의 합"), {}))
    return out


CITY = {"incheon": ("인천",), "gyeongju": ("경주",), "yeongju": ("영주",), "jeju": ("제주", "서귀포")}


def run():
    summary = {}
    for slug, items in spots().items():
        places = [p for p in json.loads((data_dir(slug) / "places.json").read_text("utf-8")) if p.get("kind") != "food"
                  and p.get("kind") != "stay"]
        idx = collections.defaultdict(list)
        for p in places:
            idx[norm(p["name"], CITY[slug])].append(p)
        patch, review, skipped = {}, [], []
        for name, by, src, extra in items:
            v = series(by)
            if not v:
                skipped.append({"spot": name, "why": "열두 달이 모두 적힌 해가 없음"})
                continue
            v = {**v, "source": src, **extra}
            hits = idx.get(norm(name, CITY[slug])) or []
            if len(hits) == 1:
                v["source"] = {**v["source"], "spot": name}
                patch[hits[0]["id"]] = {"visitors": v}
                continue
            near = [p for p in places if len(norm(name, CITY[slug])) >= 2 and (norm(name, CITY[slug]) in norm(p["name"], CITY[slug])
                    or norm(p["name"], CITY[slug]) in norm(name, CITY[slug])) and len(norm(p["name"], CITY[slug])) >= 2]
            review.append({"spot": name, "exact_hits": [(p["id"], p["name"]) for p in hits],
                           "near_names": [(p["id"], p["name"], p.get("status")) for p in near[:6]], "visitors": v})
        o = ROOT / "out" / slug
        (o / "patch_visitors.json").write_text(json.dumps({"_about": "places.json 장소 id → visitors(군산 visitors_gunsan.py 형식). 이름이 정확히 하나의 장소와 같을 때만.",
                                                           "places": patch}, ensure_ascii=False, indent=1) + "\n", "utf-8")
        (o / "patch_visitors_review.json").write_text(json.dumps({"_about": "이름이 정확히 맞지 않아 넣지 않은 관광지점 — 사람이 대응표로 정할 것",
                                                                  "spots": review, "skipped": skipped}, ensure_ascii=False, indent=1) + "\n", "utf-8")
        raw = o / "raw" / "visitors"
        raw.mkdir(parents=True, exist_ok=True)
        for pk in {s[2]["url"].split("/data/")[1].split("/")[0] for s in items}:
            (raw / f"{pk}.csv").write_bytes((V / f"{pk}.bin").read_bytes())
        summary[slug] = {"spots": len(items), "matched": len(patch), "review": len(review), "skipped": len(skipped),
                         "matched_names": [v["visitors"]["source"]["spot"] for v in patch.values()]}
        print(slug, summary[slug])
    (ROOT / "cache" / "visitors_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    run()
