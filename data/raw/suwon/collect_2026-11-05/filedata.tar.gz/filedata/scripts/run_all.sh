#!/bin/bash
# 다시 돌리기 — 모두 캐시(cache/)에서 이어 간다. 키는 net.py가 scratchpad의 .datakey에서 읽고 출력하지 않는다.
set -e
cd /home/user/work/filedata/scripts
python3 fetch_std.py 15012896 parking 전국주차장정보표준데이터        # 1. 주차장 제공기관 파일
python3 build_nearby.py                                              # 1·2. parking_lots.json + nearby.json 후보(정류장: 전국 파일·서울·속초 파일)
python3 market_match.py && python3 extract_sangga.py && python3 -I build_markets.py   # 3. 시장(상가정보 zip은 지웠음 — 다시 받으려면 filedata.download('15083033', …))
python3 -I build_designations.py                                     # 4·5. 지정·식품안심업소(시·구 파일)
python3 -I build_visitors.py                                         # 6. 월별 관광객
python3 fetch_std.py 15021141 std_tourist 전국관광지정보표준데이터 && python3 fetch_std.py 15013104 std_festival 전국문화축제표준데이터
python3 -I std_report.py                                             # 7. 분석
python3 -I stage_extra.py                                            # 7+. 관광지·축제·화장실·착한가격 메뉴 staged
python3 -I make_readme.py
