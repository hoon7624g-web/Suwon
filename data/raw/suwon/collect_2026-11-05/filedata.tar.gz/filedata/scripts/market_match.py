"""Which places of each site are traditional markets in the 온누리 list (conservative).

A market-like place (name with 시장/상점가, not a food place, not a branch shop '…점') is linked to a 전국전통시장표준데이터
market when the normalized names agree (city prefix dropped on both sides) and the two points are within ANCHOR_M; the
온누리 '소속 시장명' of the same 시·도 is linked when its normalized name equals the place's or the standard market's
(with or without the city short name in front) and the name is not shared by standard markets in two cities of the
시·도 (the 온누리 list gives only the 시·도). Ambiguous → not linked. Output: out/<slug>/raw/markets/market_links.json
"""
from __future__ import annotations
import csv, io, json, math, re, sys, collections
from pathlib import Path
sys.path.insert(0, "/home/user/work/filedata/scripts")
from sites import SITES, ROOT, data_dir, in_region, SIDO_SHORT, REGION, CITY_LABEL
import stdfiles

ANCHOR_M = 700
ONNURI = Path("/home/user/work/filedata/downloads/markets/onnuri_3060079.csv")
STD = Path("/home/user/work/filedata/downloads/markets/trad_markets_15012894.csv")
CITY_SHORT = {"daegu": ["대구"], "haenam": ["해남"], "sejong": ["세종"], "yeongju": ["영주"], "gangneung": ["강릉"],
              "jeju": ["제주", "서귀포"], "yeosu": ["여수"], "jeonju": ["전주"], "chuncheon": ["춘천"], "yongin": ["용인"],
              "gyeongju": ["경주"], "busan": ["부산"], "suwon": ["수원"], "sokcho": ["속초"], "danyang": ["단양"],
              "mokpo": ["목포"], "incheon": ["인천"], "gapyeong": ["가평"], "jongno": ["서울", "종로"]}
STD_SIDO = {"전남": ("전남광주통합특별시", "전라남도", "광주광역시"), "전북": ("전북특별자치도", "전라북도"), "강원": ("강원특별자치도", "강원도"),
            "경기": ("경기도",), "경북": ("경상북도",), "충북": ("충청북도",), "대구": ("대구광역시",), "부산": ("부산광역시",),
            "인천": ("인천광역시",), "서울": ("서울특별시",), "세종": ("세종특별자치시",), "제주": ("제주특별자치도",)}


def metres(a, b):
    k = math.pi / 180
    x = (b[1] - a[1]) * k * math.cos((a[0] + b[0]) / 2 * k)
    return 6371000 * math.hypot(x, (b[0] - a[0]) * k)


def norm(s: str) -> str:
    s = re.sub(r"\(.*?\)|\[.*?\]", "", s or "")
    return re.sub(r"[\s\W_]+", "", s)


GENERIC = re.compile(r"공설|전통|재래")


def gen(n: str) -> str:
    g = GENERIC.sub("", n)
    return g if len(g) >= 3 else n


def bracket_names(s: str) -> set[str]:
    out = set()
    for inner in re.findall(r"\(([^()]*)\)", s or ""):
        inner = re.sub(r"^\s*(?:구|舊)\s*\.?\s*", "", inner)
        n = norm(inner)
        if len(n) >= 3 and re.search(r"시장|상가|상점가", n):
            out.add(n)
    return out


def strip_city(n: str, shorts) -> str:
    for c in sorted(shorts, key=len, reverse=True):
        for pre in (c + "시", c + "군", c):
            if n.startswith(pre) and len(n) - len(pre) >= 2:
                return n[len(pre):]
    return n


def components(name: str) -> list[str]:
    parts = re.split(r"\s*(?:&|/|·|,)\s*", re.sub(r"\(\s*\d+\s*,\s*\d+\s*일\s*\)|\(\s*\d+일\s*,\s*\d+일\s*\)", "", name))
    out = []
    for p in parts:
        p = re.sub(r"\s*(야시장|먹자골목|젊음의거리|365일장|한복매장|회센터)$", "", p).strip()
        if re.search(r"시장|상점가", p):
            out.append(p)
    return out


def market_places(places):
    out = []
    for p in places:
        n = p.get("name") or ""
        if p.get("kind") == "food" or not re.search(r"시장|상점가", n):
            continue
        if re.search(r"\S점$", n.split()[-1]) and not n.endswith("시장"):
            continue   # '다이소 제주동문시장점' — a branch shop in a market
        if re.search(r"도매시장|공판장|어시장$|축산물도매|공동어시장|지하도?상가|전자|악기|조명|가방|문구|벼룩", n):
            pass       # kept as candidates; they simply rarely have 온누리 rows
        if not (p.get("geo") or {}).get("lat"):
            continue
        out.append(p)
    return out


def run():
    onn = list(csv.DictReader(io.StringIO(stdfiles.decode(ONNURI.read_bytes()))))
    std = list(csv.DictReader(io.StringIO(stdfiles.decode(STD.read_bytes()))))
    by_sido = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in onn:
        by_sido[r["소재지"].strip()][r["소속 시장명(또는 상점가)"].strip()].append(r)
    summary = {}
    for slug in SITES:
        sido = {"전남": "전남광주"}.get(SIDO_SHORT[slug], SIDO_SHORT[slug])
        shorts = CITY_SHORT[slug]
        places = json.loads((data_dir(slug) / "places.json").read_text("utf-8"))
        cand = market_places(places)
        sido_std = [s for s in std if any((s["소재지도로명주소"] or s["소재지지번주소"]).startswith(x) for x in STD_SIDO[SIDO_SHORT[slug]])]
        # standard markets by normalized name (city prefix stripped by its own city word)
        def std_city(s):
            a = (s["소재지도로명주소"] or s["소재지지번주소"]).split()
            return a[1] if len(a) > 1 else ""
        std_names = collections.defaultdict(set)   # norm name -> {city}
        std_count = collections.defaultdict(list)  # norm name -> [market@city]
        for s in sido_std:
            c = std_city(s)
            nn = norm(s["시장명"])
            std_names[nn].add(c)
            std_names[strip_city(nn, [c[:-1]] if len(c) > 2 else [c])].add(c)
            for k in {nn, strip_city(nn, [c[:-1]] if len(c) > 2 else [c])}:
                std_count[k].append(s["시장명"] + "@" + c)
        onn_names = by_sido.get(sido, {})
        onn_norm = collections.defaultdict(list)
        for o in onn_names:
            onn_norm[norm(o)].append(o)
        links, unlinked = [], []
        used = collections.defaultdict(list)
        for p in cand:
            pt = (float(p["geo"]["lat"]), float(p["geo"]["lng"]))
            comps = components(p["name"])
            keys = set()
            for c in comps:
                n = norm(c)
                keys |= {n, strip_city(n, shorts)}
            # standard anchor
            anchors = []
            for s in sido_std:
                addr = s["소재지도로명주소"] or s["소재지지번주소"]
                if not in_region(slug, addr):
                    continue
                sn = norm(s["시장명"])
                if {sn, strip_city(sn, shorts)} & keys:
                    try:
                        sp = (float(s["위도"]), float(s["경도"]))
                    except ValueError:
                        continue
                    if metres(pt, sp) <= ANCHOR_M:
                        anchors.append((s, round(metres(pt, sp))))
            anchor = anchors[0] if len(anchors) == 1 else None
            names = set(keys)
            if anchor:
                sn = norm(anchor[0]["시장명"])
                names |= {sn, strip_city(sn, shorts)} | bracket_names(anchor[0]["시장명"])
            names |= {gen(x) for x in names}
            want = set()
            for k in names:
                want |= {k} | {c + k for c in shorts} | {c + "시" + k for c in shorts} | {c + "군" + k for c in shorts}
            found = sorted({o for k in want for o in onn_norm.get(k, [])} |
                           {o for o in onn_names if (gen(norm(o)) in want or gen(strip_city(norm(o), shorts)) in want
                                                     or bracket_names(o) & want)})
            ok, why = [], []
            for o in found:
                on = norm(o)
                has_city = any(on.startswith(c) for c in shorts)
                cities = std_names.get(strip_city(on, shorts), set()) | std_names.get(on, set())
                city_lbl = REGION[slug][1]
                other = {c for c in cities if c and city_lbl and c != city_lbl and not (slug == "jeju" and c in ("제주시", "서귀포시"))}
                if REGION[slug][1] is None:   # whole 시·도 site: the 시·도 is the site
                    same = sorted(set(std_count.get(strip_city(on, shorts), []) + std_count.get(on, [])))
                    if len(same) >= 2 and not has_city:
                        why.append(f"{o}: 같은 이름 시장이 표준데이터에 {len(same)}곳({', '.join(same[:4])}) — 온누리 행을 가를 수 없음")
                    else:
                        ok.append(o)
                elif has_city:
                    ok.append(o)
                elif other:
                    why.append(f"{o}: 같은 이름 시장이 {sorted(other)}에도 있음(온누리 명부는 시·도만 적음)")
                elif cities:
                    ok.append(o)
                elif anchor:
                    ok.append(o)
                else:
                    why.append(f"{o}: 표준데이터에서 위치를 확인할 수 없음")
            rec = {"id": p["id"], "name": p["name"], "status": p.get("status"),
                   "anchor": ({"name": anchor[0]["시장명"], "address": anchor[0]["소재지도로명주소"] or anchor[0]["소재지지번주소"],
                               "meters": anchor[1], "stores": anchor[0]["점포수"], "opened": anchor[0]["개설연도"],
                               "base_date": anchor[0]["데이터기준일자"]} if anchor else None),
                   "anchors_found": len(anchors), "onnuri": ok, "onnuri_rows": sum(len(onn_names[o]) for o in ok),
                   "rejected": why}
            (links if ok else unlinked).append(rec)
            for o in ok:
                used[o].append(p["id"])
        # an 온누리 name linked to two places: keep it only on the place whose name is closest (exact component)
        for o, pids in used.items():
            if len(pids) > 1:
                full = lambda r: strip_city(norm(r["name"]), shorts)  # noqa: E731
                exact = [r for r in links if r["id"] in pids and full(r) in (norm(o), strip_city(norm(o), shorts))]
                keep = exact[0]["id"] if len(exact) == 1 else None
                for r in links:
                    if r["id"] in pids and r["id"] != keep:
                        r["onnuri"] = [x for x in r["onnuri"] if x != o]
                        r["rejected"].append(f"{o}: 장소 {len(pids)}곳에 걸림 — 이 장소에 붙이지 않음")
        moved = [r for r in links if not r["onnuri"]]
        links = [r for r in links if r["onnuri"]]
        for r in links:
            r["onnuri_rows"] = sum(len(onn_names[o]) for o in r["onnuri"])
        unlinked += moved
        o = ROOT / "out" / slug / "raw" / "markets"
        o.mkdir(parents=True, exist_ok=True)
        (o / "market_links.json").write_text(json.dumps({"links": links, "unlinked": unlinked}, ensure_ascii=False, indent=1), "utf-8")
        summary[slug] = (len(cand), len(links), sum(r["onnuri_rows"] for r in links))
        print(slug, "candidates", len(cand), "linked", len(links), "rows", summary[slug][2],
              [(r["name"], r["onnuri"]) for r in links][:12])
    return summary


if __name__ == "__main__":
    run()
